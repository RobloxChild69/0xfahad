(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  13637,
  (e) => {
    "use strict";
    let s = (0, e.i(10965).default)("Download", [
      [
        "path",
        { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
      ],
      ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
      ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }],
    ]);
    e.s(["Download", () => s], 13637);
  },
  81947,
  (e) => {
    "use strict";
    var s = e.i(93046),
      t = e.i(94237),
      r = e.i(47163);
    let l = (0, t.cva)(
      "relative w-full rounded-lg border px-4 py-3 text-sm grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current",
      {
        variants: {
          variant: {
            default: "bg-card text-card-foreground",
            destructive:
              "text-destructive bg-card [&>svg]:text-current *:data-[slot=alert-description]:text-destructive/90",
          },
        },
        defaultVariants: { variant: "default" },
      }
    );
    function a({ className: e, variant: t, ...a }) {
      return (0, s.jsx)("div", {
        "data-slot": "alert",
        role: "alert",
        className: (0, r.cn)(l({ variant: t }), e),
        ...a,
      });
    }
    function n({ className: e, ...t }) {
      return (0, s.jsx)("div", {
        "data-slot": "alert-description",
        className: (0, r.cn)(
          "text-muted-foreground col-start-2 grid justify-items-start gap-1 text-sm [&_p]:leading-relaxed",
          e
        ),
        ...t,
      });
    }
    e.s(["Alert", () => a, "AlertDescription", () => n]);
  },
  64877,
  (e) => {
    "use strict";
    let s = (0, e.i(10965).default)("TriangleAlert", [
      [
        "path",
        {
          d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
          key: "wmoenq",
        },
      ],
      ["path", { d: "M12 9v4", key: "juzpu7" }],
      ["path", { d: "M12 17h.01", key: "p32p05" }],
    ]);
    e.s(["AlertTriangle", () => s], 64877);
  },
  60835,
  (e, s, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", { value: !0 }),
      Object.defineProperty(t, "warnOnce", {
        enumerable: !0,
        get: function () {
          return r;
        },
      });
    let r = (e) => {};
  },
  85260,
  (e, s, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", { value: !0 });
    var r = {
      assign: function () {
        return o;
      },
      searchParamsToUrlQuery: function () {
        return a;
      },
      urlQueryToSearchParams: function () {
        return i;
      },
    };
    for (var l in r) Object.defineProperty(t, l, { enumerable: !0, get: r[l] });
    function a(e) {
      let s = {};
      for (let [t, r] of e.entries()) {
        let e = s[t];
        void 0 === e
          ? (s[t] = r)
          : Array.isArray(e)
          ? e.push(r)
          : (s[t] = [e, r]);
      }
      return s;
    }
    function n(e) {
      return "string" == typeof e
        ? e
        : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e
        ? ""
        : String(e);
    }
    function i(e) {
      let s = new URLSearchParams();
      for (let [t, r] of Object.entries(e))
        if (Array.isArray(r)) for (let e of r) s.append(t, n(e));
        else s.set(t, n(r));
      return s;
    }
    function o(e, ...s) {
      for (let t of s) {
        for (let s of t.keys()) e.delete(s);
        for (let [s, r] of t.entries()) e.append(s, r);
      }
      return e;
    }
  },
  91552,
  (e, s, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", { value: !0 });
    var r = {
      formatUrl: function () {
        return i;
      },
      formatWithValidation: function () {
        return c;
      },
      urlObjectKeys: function () {
        return o;
      },
    };
    for (var l in r) Object.defineProperty(t, l, { enumerable: !0, get: r[l] });
    let a = e.r(44066)._(e.r(85260)),
      n = /https?|ftp|gopher|file/;
    function i(e) {
      let { auth: s, hostname: t } = e,
        r = e.protocol || "",
        l = e.pathname || "",
        i = e.hash || "",
        o = e.query || "",
        c = !1;
      (s = s ? encodeURIComponent(s).replace(/%3A/i, ":") + "@" : ""),
        e.host
          ? (c = s + e.host)
          : t &&
            ((c = s + (~t.indexOf(":") ? `[${t}]` : t)),
            e.port && (c += ":" + e.port)),
        o && "object" == typeof o && (o = String(a.urlQueryToSearchParams(o)));
      let d = e.search || (o && `?${o}`) || "";
      return (
        r && !r.endsWith(":") && (r += ":"),
        e.slashes || ((!r || n.test(r)) && !1 !== c)
          ? ((c = "//" + (c || "")), l && "/" !== l[0] && (l = "/" + l))
          : c || (c = ""),
        i && "#" !== i[0] && (i = "#" + i),
        d && "?" !== d[0] && (d = "?" + d),
        (l = l.replace(/[?#]/g, encodeURIComponent)),
        (d = d.replace("#", "%23")),
        `${r}${c}${l}${d}${i}`
      );
    }
    let o = [
      "auth",
      "hash",
      "host",
      "hostname",
      "href",
      "path",
      "pathname",
      "port",
      "protocol",
      "query",
      "search",
      "slashes",
    ];
    function c(e) {
      return i(e);
    }
  },
  60203,
  (e, s, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", { value: !0 }),
      Object.defineProperty(t, "useMergedRef", {
        enumerable: !0,
        get: function () {
          return l;
        },
      });
    let r = e.r(80883);
    function l(e, s) {
      let t = (0, r.useRef)(null),
        l = (0, r.useRef)(null);
      return (0, r.useCallback)(
        (r) => {
          if (null === r) {
            let e = t.current;
            e && ((t.current = null), e());
            let s = l.current;
            s && ((l.current = null), s());
          } else e && (t.current = a(e, r)), s && (l.current = a(s, r));
        },
        [e, s]
      );
    }
    function a(e, s) {
      if ("function" != typeof e)
        return (
          (e.current = s),
          () => {
            e.current = null;
          }
        );
      {
        let t = e(s);
        return "function" == typeof t ? t : () => e(null);
      }
    }
    ("function" == typeof t.default ||
      ("object" == typeof t.default && null !== t.default)) &&
      void 0 === t.default.__esModule &&
      (Object.defineProperty(t.default, "__esModule", { value: !0 }),
      Object.assign(t.default, t),
      (s.exports = t.default));
  },
  6898,
  (e, s, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", { value: !0 });
    var r = {
      DecodeError: function () {
        return g;
      },
      MiddlewareNotFoundError: function () {
        return y;
      },
      MissingStaticPage: function () {
        return N;
      },
      NormalizeError: function () {
        return j;
      },
      PageNotFoundError: function () {
        return b;
      },
      SP: function () {
        return f;
      },
      ST: function () {
        return p;
      },
      WEB_VITALS: function () {
        return a;
      },
      execOnce: function () {
        return n;
      },
      getDisplayName: function () {
        return h;
      },
      getLocationOrigin: function () {
        return c;
      },
      getURL: function () {
        return d;
      },
      isAbsoluteUrl: function () {
        return o;
      },
      isResSent: function () {
        return u;
      },
      loadGetInitialProps: function () {
        return m;
      },
      normalizeRepeatedSlashes: function () {
        return x;
      },
      stringifyError: function () {
        return w;
      },
    };
    for (var l in r) Object.defineProperty(t, l, { enumerable: !0, get: r[l] });
    let a = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];
    function n(e) {
      let s,
        t = !1;
      return (...r) => (t || ((t = !0), (s = e(...r))), s);
    }
    let i = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
      o = (e) => i.test(e);
    function c() {
      let { protocol: e, hostname: s, port: t } = window.location;
      return `${e}//${s}${t ? ":" + t : ""}`;
    }
    function d() {
      let { href: e } = window.location,
        s = c();
      return e.substring(s.length);
    }
    function h(e) {
      return "string" == typeof e ? e : e.displayName || e.name || "Unknown";
    }
    function u(e) {
      return e.finished || e.headersSent;
    }
    function x(e) {
      let s = e.split("?");
      return (
        s[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") +
        (s[1] ? `?${s.slice(1).join("?")}` : "")
      );
    }
    async function m(e, s) {
      let t = s.res || (s.ctx && s.ctx.res);
      if (!e.getInitialProps)
        return s.ctx && s.Component
          ? { pageProps: await m(s.Component, s.ctx) }
          : {};
      let r = await e.getInitialProps(s);
      if (t && u(t)) return r;
      if (!r)
        throw Object.defineProperty(
          Error(
            `"${h(
              e
            )}.getInitialProps()" should resolve to an object. But found "${r}" instead.`
          ),
          "__NEXT_ERROR_CODE",
          { value: "E394", enumerable: !1, configurable: !0 }
        );
      return r;
    }
    let f = "undefined" != typeof performance,
      p =
        f &&
        ["mark", "measure", "getEntriesByName"].every(
          (e) => "function" == typeof performance[e]
        );
    class g extends Error {}
    class j extends Error {}
    class b extends Error {
      constructor(e) {
        super(),
          (this.code = "ENOENT"),
          (this.name = "PageNotFoundError"),
          (this.message = `Cannot find module for page: ${e}`);
      }
    }
    class N extends Error {
      constructor(e, s) {
        super(),
          (this.message = `Failed to load static file for page: ${e} ${s}`);
      }
    }
    class y extends Error {
      constructor() {
        super(),
          (this.code = "ENOENT"),
          (this.message = "Cannot find the middleware module");
      }
    }
    function w(e) {
      return JSON.stringify({ message: e.message, stack: e.stack });
    }
  },
  73350,
  (e, s, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", { value: !0 }),
      Object.defineProperty(t, "isLocalURL", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    let r = e.r(6898),
      l = e.r(56075);
    function a(e) {
      if (!(0, r.isAbsoluteUrl)(e)) return !0;
      try {
        let s = (0, r.getLocationOrigin)(),
          t = new URL(e, s);
        return t.origin === s && (0, l.hasBasePath)(t.pathname);
      } catch (e) {
        return !1;
      }
    }
  },
  95136,
  (e, s, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", { value: !0 }),
      Object.defineProperty(t, "errorOnce", {
        enumerable: !0,
        get: function () {
          return r;
        },
      });
    let r = (e) => {};
  },
  61021,
  (e, s, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", { value: !0 });
    var r = {
      default: function () {
        return g;
      },
      useLinkStatus: function () {
        return b;
      },
    };
    for (var l in r) Object.defineProperty(t, l, { enumerable: !0, get: r[l] });
    let a = e.r(44066),
      n = e.r(93046),
      i = a._(e.r(80883)),
      o = e.r(91552),
      c = e.r(89260),
      d = e.r(60203),
      h = e.r(6898),
      u = e.r(63118);
    e.r(60835);
    let x = e.r(68193),
      m = e.r(73350),
      f = e.r(50696);
    function p(e) {
      return "string" == typeof e ? e : (0, o.formatUrl)(e);
    }
    function g(s) {
      var t;
      let r,
        l,
        a,
        [o, g] = (0, i.useOptimistic)(x.IDLE_LINK_STATUS),
        b = (0, i.useRef)(null),
        {
          href: N,
          as: y,
          children: w,
          prefetch: v = null,
          passHref: k,
          replace: C,
          shallow: A,
          scroll: S,
          onClick: D,
          onMouseEnter: E,
          onTouchStart: P,
          legacyBehavior: T = !1,
          onNavigate: _,
          ref: O,
          unstable_dynamicOnHover: B,
          ...R
        } = s;
      (r = w),
        T &&
          ("string" == typeof r || "number" == typeof r) &&
          (r = (0, n.jsx)("a", { children: r }));
      let M = i.default.useContext(c.AppRouterContext),
        L = !1 !== v,
        I =
          !1 !== v
            ? null === (t = v) || "auto" === t
              ? f.FetchStrategy.PPR
              : f.FetchStrategy.Full
            : f.FetchStrategy.PPR,
        { href: U, as: W } = i.default.useMemo(() => {
          let e = p(N);
          return { href: e, as: y ? p(y) : e };
        }, [N, y]);
      if (T) {
        if (r?.$$typeof === Symbol.for("react.lazy"))
          throw Object.defineProperty(
            Error(
              "`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."
            ),
            "__NEXT_ERROR_CODE",
            { value: "E863", enumerable: !1, configurable: !0 }
          );
        l = i.default.Children.only(r);
      }
      let z = T ? l && "object" == typeof l && l.ref : O,
        F = i.default.useCallback(
          (e) => (
            null !== M &&
              (b.current = (0, x.mountLinkInstance)(e, U, M, I, L, g)),
            () => {
              b.current &&
                ((0, x.unmountLinkForCurrentNavigation)(b.current),
                (b.current = null)),
                (0, x.unmountPrefetchableInstance)(e);
            }
          ),
          [L, U, M, I, g]
        ),
        $ = {
          ref: (0, d.useMergedRef)(F, z),
          onClick(s) {
            T || "function" != typeof D || D(s),
              T &&
                l.props &&
                "function" == typeof l.props.onClick &&
                l.props.onClick(s),
              !M ||
                s.defaultPrevented ||
                (function (s, t, r, l, a, n, o) {
                  if ("undefined" != typeof window) {
                    let c,
                      { nodeName: d } = s.currentTarget;
                    if (
                      ("A" === d.toUpperCase() &&
                        (((c = s.currentTarget.getAttribute("target")) &&
                          "_self" !== c) ||
                          s.metaKey ||
                          s.ctrlKey ||
                          s.shiftKey ||
                          s.altKey ||
                          (s.nativeEvent && 2 === s.nativeEvent.which))) ||
                      s.currentTarget.hasAttribute("download")
                    )
                      return;
                    if (!(0, m.isLocalURL)(t)) {
                      a && (s.preventDefault(), location.replace(t));
                      return;
                    }
                    if ((s.preventDefault(), o)) {
                      let e = !1;
                      if (
                        (o({
                          preventDefault: () => {
                            e = !0;
                          },
                        }),
                        e)
                      )
                        return;
                    }
                    let { dispatchNavigateAction: h } = e.r(56797);
                    i.default.startTransition(() => {
                      h(r || t, a ? "replace" : "push", n ?? !0, l.current);
                    });
                  }
                })(s, U, W, b, C, S, _);
          },
          onMouseEnter(e) {
            T || "function" != typeof E || E(e),
              T &&
                l.props &&
                "function" == typeof l.props.onMouseEnter &&
                l.props.onMouseEnter(e),
              M && L && (0, x.onNavigationIntent)(e.currentTarget, !0 === B);
          },
          onTouchStart: function (e) {
            T || "function" != typeof P || P(e),
              T &&
                l.props &&
                "function" == typeof l.props.onTouchStart &&
                l.props.onTouchStart(e),
              M && L && (0, x.onNavigationIntent)(e.currentTarget, !0 === B);
          },
        };
      return (
        (0, h.isAbsoluteUrl)(W)
          ? ($.href = W)
          : (T && !k && ("a" !== l.type || "href" in l.props)) ||
            ($.href = (0, u.addBasePath)(W)),
        (a = T
          ? i.default.cloneElement(l, $)
          : (0, n.jsx)("a", { ...R, ...$, children: r })),
        (0, n.jsx)(j.Provider, { value: o, children: a })
      );
    }
    e.r(95136);
    let j = (0, i.createContext)(x.IDLE_LINK_STATUS),
      b = () => (0, i.useContext)(j);
    ("function" == typeof t.default ||
      ("object" == typeof t.default && null !== t.default)) &&
      void 0 === t.default.__esModule &&
      (Object.defineProperty(t.default, "__esModule", { value: !0 }),
      Object.assign(t.default, t),
      (s.exports = t.default));
  },
  84675,
  (e) => {
    "use strict";
    let s = (0, e.i(10965).default)("ArrowLeft", [
      ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
      ["path", { d: "M19 12H5", key: "x3x0zl" }],
    ]);
    e.s(["ArrowLeft", () => s], 84675);
  },
  35301,
  (e) => {
    "use strict";
    let s = (0, e.i(10965).default)("CircleCheck", [
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
      ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }],
    ]);
    e.s(["CheckCircle2", () => s], 35301);
  },
  17508,
  52910,
  (e) => {
    "use strict";
    var s = e.i(10965);
    let t = (0, s.default)("ChevronRight", [
      ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }],
    ]);
    e.s(["ChevronRight", () => t], 17508);
    let r = (0, s.default)("ChevronLeft", [
      ["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }],
    ]);
    e.s(["ChevronLeft", () => r], 52910);
  },
  10712,
  (e) => {
    "use strict";
    let s = (0, e.i(10965).default)("Info", [
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
      ["path", { d: "M12 16v-4", key: "1dtifu" }],
      ["path", { d: "M12 8h.01", key: "e9boi3" }],
    ]);
    e.s(["Info", () => s], 10712);
  },
  48054,
  (e) => {
    "use strict";
    let s = (0, e.i(10965).default)("Package", [
      [
        "path",
        {
          d: "M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",
          key: "1a0edw",
        },
      ],
      ["path", { d: "M12 22V12", key: "d0xqtd" }],
      [
        "path",
        { d: "m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7", key: "yx3hmr" },
      ],
      ["path", { d: "m7.5 4.27 9 5.15", key: "1c824w" }],
    ]);
    e.s(["Package", () => s], 48054);
  },
  4097,
  (e) => {
    "use strict";
    var s = e.i(93046),
      t = e.i(80883),
      r = e.i(61021),
      l = e.i(84675),
      a = e.i(13637),
      n = e.i(64877),
      i = e.i(35301),
      o = e.i(10712),
      c = e.i(17508),
      d = e.i(52910),
      h = e.i(48054),
      u = e.i(67881),
      x = e.i(81947);
    function m() {
      let [e, m] = (0, t.useState)(1),
        [f, p] = (0, t.useState)(!1);
      return (0, s.jsxs)("div", {
        className: "min-h-screen bg-background",
        children: [
          (0, s.jsx)("header", {
            className:
              "sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60",
            children: (0, s.jsx)("div", {
              className: "container flex h-16 items-center px-4",
              children: (0, s.jsxs)(r.default, {
                href: "/guides/hwid-unban",
                className:
                  "flex items-center gap-2 text-foreground hover:text-primary transition-colors",
                children: [
                  (0, s.jsx)(l.ArrowLeft, { className: "h-5 w-5" }),
                  (0, s.jsx)("span", {
                    className: "font-semibold",
                    children: "Back to Selection",
                  }),
                ],
              }),
            }),
          }),
          (0, s.jsx)("section", {
            className:
              "relative py-20 px-4 bg-gradient-to-b from-orange-500/20 to-background",
            children: (0, s.jsxs)("div", {
              className: "container mx-auto max-w-4xl text-center",
              children: [
                (0, s.jsx)("h1", {
                  className: "text-5xl font-bold mb-6 text-balance",
                  children: "EAC & BE Games HWID Spoof Guide",
                }),
                (0, s.jsx)("p", {
                  className: "text-xl text-muted-foreground text-pretty",
                  children:
                    "Complete step-by-step guide for Fortnite, Rust, Apex, and other EAC/BE games",
                }),
              ],
            }),
          }),
          (0, s.jsx)("section", {
            className:
              "py-8 px-4 bg-card/50 border-y border-border sticky top-16 z-40 backdrop-blur",
            children: (0, s.jsxs)("div", {
              className: "container mx-auto max-w-4xl",
              children: [
                (0, s.jsxs)("div", {
                  className: "flex items-center justify-between mb-4",
                  children: [
                    (0, s.jsxs)("p", {
                      className: "text-sm text-muted-foreground",
                      children: ["Step ", e, " of ", 10],
                    }),
                    (0, s.jsxs)("p", {
                      className: "text-sm text-muted-foreground",
                      children: [Math.round((e / 10) * 100), "% Complete"],
                    }),
                  ],
                }),
                (0, s.jsx)("div", {
                  className: "w-full bg-muted rounded-full h-3 overflow-hidden",
                  children: (0, s.jsx)("div", {
                    className:
                      "bg-orange-500 h-full transition-all duration-500 ease-out",
                    style: { width: `${(e / 10) * 100}%` },
                  }),
                }),
              ],
            }),
          }),
          (0, s.jsx)("section", {
            className: "py-12 px-4 min-h-[60vh]",
            children: (0, s.jsxs)("div", {
              className: "container mx-auto max-w-4xl",
              children: [
                0 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white font-bold text-2xl",
                            children: (0, s.jsx)(h.Package, {
                              className: "h-8 w-8",
                            }),
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children: "Download Required Tools First",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children:
                                  "You'll need these tools during spoofing. Download them now!",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)(x.Alert, {
                        className: "border-destructive/50 bg-destructive/10",
                        children: [
                          (0, s.jsx)(n.AlertTriangle, {
                            className: "h-5 w-5 text-destructive",
                          }),
                          (0, s.jsx)(x.AlertDescription, {
                            className: "text-base font-semibold",
                            children:
                              "Install these tools NOW before you start!",
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-gradient-to-br from-amber-500/10 to-amber-500/5 border-2 border-amber-500/30 rounded-lg p-8 space-y-6 text-center",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "text-2xl font-bold text-amber-600",
                            children: "Spoofing Tools Pack",
                          }),
                          (0, s.jsx)("p", {
                            className: "text-muted-foreground text-lg",
                            children: "Everything you need in one download",
                          }),
                          (0, s.jsx)(u.Button, {
                            size: "lg",
                            className:
                              "w-full sm:w-auto bg-amber-500 hover:bg-amber-600 text-white",
                            asChild: !0,
                            children: (0, s.jsxs)("a", {
                              href: "https://gofile.io/d/KCaxBx",
                              target: "_blank",
                              rel: "noopener noreferrer",
                              children: [
                                (0, s.jsx)(a.Download, {
                                  className: "mr-2 h-5 w-5",
                                }),
                                "Download Tools Pack",
                              ],
                            }),
                          }),
                          (0, s.jsxs)("div", {
                            className:
                              "mt-6 text-left bg-background/50 border border-border rounded-lg p-6 space-y-3",
                            children: [
                              (0, s.jsx)("p", {
                                className: "font-semibold text-base",
                                children: "What's inside:",
                              }),
                              (0, s.jsxs)("ul", {
                                className:
                                  "space-y-2 text-sm text-muted-foreground",
                                children: [
                                  (0, s.jsxs)("li", {
                                    className: "flex items-center gap-2",
                                    children: [
                                      (0, s.jsx)(i.CheckCircle2, {
                                        className: "h-4 w-4 text-green-500",
                                      }),
                                      "Serial Checker (check if spoof worked)",
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-center gap-2",
                                    children: [
                                      (0, s.jsx)(i.CheckCircle2, {
                                        className: "h-4 w-4 text-green-500",
                                      }),
                                      "Device Cleanup Tool (remove old devices)",
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-center gap-2",
                                    children: [
                                      (0, s.jsx)(i.CheckCircle2, {
                                        className: "h-4 w-4 text-green-500",
                                      }),
                                      "Other helpful tools",
                                    ],
                                  }),
                                ],
                              }),
                              (0, s.jsx)("p", {
                                className: "text-xs italic mt-4",
                                children:
                                  "Tip: Each folder name tells you what the tool does",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-gradient-to-br from-amber-500/10 to-amber-500/5 border-2 border-amber-500/30 rounded-lg p-8 space-y-6 text-center",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "text-2xl font-bold text-amber-600",
                            children: "Loader",
                          }),
                          (0, s.jsx)("p", {
                            className: "text-muted-foreground text-lg",
                            children: "Required for spoofing",
                          }),
                          (0, s.jsx)(u.Button, {
                            size: "lg",
                            className:
                              "w-full sm:w-auto bg-amber-500 hover:bg-amber-600 text-white",
                            asChild: !0,
                            children: (0, s.jsxs)("a", {
                              href: "https://workupload.com/file/gYmSJzyqxbE",
                              target: "_blank",
                              rel: "noopener noreferrer",
                              children: [
                                (0, s.jsx)(a.Download, {
                                  className: "mr-2 h-5 w-5",
                                }),
                                "Download Loader",
                              ],
                            }),
                          }),
                          (0, s.jsx)("p", {
                            className:
                              "text-sm text-muted-foreground font-semibold",
                            children: "Password: 123",
                          }),
                        ],
                      }),
                      (0, s.jsxs)(x.Alert, {
                        className: "border-blue-500/50 bg-blue-500/10",
                        children: [
                          (0, s.jsx)(o.Info, {
                            className: "h-5 w-5 text-blue-500",
                          }),
                          (0, s.jsx)(x.AlertDescription, {
                            children:
                              "Extract the pack and keep it somewhere easy to find. You'll need it later!",
                          }),
                        ],
                      }),
                    ],
                  }),
                1 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                            children: "1",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children: "Reinstall Windows 10",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children:
                                  "Clean install of official Windows 10",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)(x.Alert, {
                        className: "border-destructive/50 bg-destructive/10",
                        children: [
                          (0, s.jsx)(n.AlertTriangle, {
                            className: "h-5 w-5 text-destructive",
                          }),
                          (0, s.jsx)(x.AlertDescription, {
                            className: "text-base font-semibold",
                            children:
                              "WARNING: This will ERASE ALL DATA on your computer! Backup important files first!",
                          }),
                        ],
                      }),
                      (0, s.jsx)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: (0, s.jsxs)("div", {
                          className: "flex items-center justify-between",
                          children: [
                            (0, s.jsxs)("div", {
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "font-semibold text-lg",
                                  children: "Download Windows 10",
                                }),
                                (0, s.jsx)("p", {
                                  className: "text-sm text-muted-foreground",
                                  children:
                                    "Official Microsoft Media Creation Tool",
                                }),
                              ],
                            }),
                            (0, s.jsx)(u.Button, {
                              asChild: !0,
                              children: (0, s.jsxs)("a", {
                                href: "https://www.microsoft.com/en-us/software-download/windows10",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "gap-2",
                                children: [
                                  (0, s.jsx)(a.Download, {
                                    className: "h-4 w-4",
                                  }),
                                  "Download Tool",
                                ],
                              }),
                            }),
                          ],
                        }),
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Create Bootable USB Drive:",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-4",
                            children: [
                              (0, s.jsx)("p", {
                                className: "text-sm text-muted-foreground",
                                children:
                                  "Use the Media Creation Tool to create a bootable USB drive with Windows 10.",
                              }),
                              (0, s.jsxs)("div", {
                                className:
                                  "space-y-3 text-sm bg-muted/50 p-4 rounded-md",
                                children: [
                                  (0, s.jsx)("h4", {
                                    className: "font-semibold",
                                    children: "Media Creation Tool Setup:",
                                  }),
                                  (0, s.jsxs)("ol", {
                                    className:
                                      "space-y-2 list-decimal list-inside",
                                    children: [
                                      (0, s.jsx)("li", {
                                        children:
                                          "Run the Media Creation Tool you downloaded",
                                      }),
                                      (0, s.jsx)("li", {
                                        children: "Accept the license terms",
                                      }),
                                      (0, s.jsxs)("li", {
                                        children: [
                                          "Select ",
                                          (0, s.jsx)("strong", {
                                            children:
                                              '"Create installation media for another PC"',
                                          }),
                                        ],
                                      }),
                                      (0, s.jsx)("li", {
                                        children:
                                          "Choose your language, edition (Windows 10), and architecture (64-bit)",
                                      }),
                                      (0, s.jsxs)("li", {
                                        children: [
                                          "Select ",
                                          (0, s.jsx)("strong", {
                                            children: '"USB flash drive"',
                                          }),
                                          " (minimum 8GB required)",
                                        ],
                                      }),
                                      (0, s.jsx)("li", {
                                        children:
                                          "Select your USB drive and click Next",
                                      }),
                                      (0, s.jsx)("li", {
                                        children:
                                          "Wait for the download and creation process to complete",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Installation Steps:",
                          }),
                          (0, s.jsxs)("ol", {
                            className: "space-y-3 text-sm",
                            children: [
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "1",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Boot from the USB drive (press F12/F8/Del during startup to access boot menu)",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "2",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "Start the Windows installation",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "3",
                                  }),
                                  (0, s.jsxs)("span", {
                                    children: [
                                      "Select ",
                                      (0, s.jsx)("strong", {
                                        children:
                                          '"Custom: Install Windows only (advanced)"',
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "4",
                                  }),
                                  (0, s.jsxs)("span", {
                                    children: [
                                      (0, s.jsx)("strong", {
                                        children: "Delete ALL partitions",
                                      }),
                                      " on all drives to completely wipe your system",
                                    ],
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Select the unallocated space and click Next to install",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "6",
                                  }),
                                  (0, s.jsxs)("span", {
                                    children: [
                                      (0, s.jsx)("strong", {
                                        children:
                                          "Do NOT sign in with a Microsoft account",
                                      }),
                                      " - use a local account",
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)(x.Alert, {
                        className: "border-blue-500/50 bg-blue-500/10",
                        children: [
                          (0, s.jsx)(o.Info, {
                            className: "h-5 w-5 text-blue-500",
                          }),
                          (0, s.jsx)(x.AlertDescription, {
                            children:
                              "Using official Windows 10 ensures maximum compatibility with EAC and BattlEye anti-cheat systems.",
                          }),
                        ],
                      }),
                    ],
                  }),
                2 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-blue-500 text-white font-bold text-2xl",
                            children: "2",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children: "Install Drivers",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children:
                                  "Install required software and drivers",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Install Required Software",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-3",
                            children: [
                              (0, s.jsx)(u.Button, {
                                size: "lg",
                                className: "w-full",
                                asChild: !0,
                                children: (0, s.jsxs)("a", {
                                  href: "https://aka.ms/vs/17/release/vc_redist.x64.exe",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  children: [
                                    (0, s.jsx)(a.Download, {
                                      className: "mr-2 h-5 w-5",
                                    }),
                                    "Download Visual C++ Runtime",
                                  ],
                                }),
                              }),
                              (0, s.jsx)(u.Button, {
                                size: "lg",
                                className: "w-full bg-transparent",
                                variant: "outline",
                                asChild: !0,
                                children: (0, s.jsxs)("a", {
                                  href: "https://www.microsoft.com/en-us/download/details.aspx?id=35",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  children: [
                                    (0, s.jsx)(a.Download, {
                                      className: "mr-2 h-5 w-5",
                                    }),
                                    "Download DirectX",
                                  ],
                                }),
                              }),
                              (0, s.jsx)("p", {
                                className: "text-sm text-muted-foreground",
                                children:
                                  "Also install your GPU drivers from manufacturer's website (NVIDIA, AMD, or Intel)",
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                3 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-blue-500 text-white font-bold text-2xl",
                            children: "3",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children: "Disable Virus & Threat Protection",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children:
                                  "Prevent interference during spoofing",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Method 1: Manual Disable",
                          }),
                          (0, s.jsx)("p", {
                            className: "text-sm",
                            children:
                              "Go to Virus & Threat Protection and turn off all protection features",
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Method 2: Windows Defender Firewall",
                          }),
                          (0, s.jsx)("p", {
                            className: "text-sm",
                            children:
                              "Open Windows Defender Firewall and turn off the firewall for all network types",
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Method 3: Use Tools (Recommended)",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-3",
                            children: [
                              (0, s.jsx)(u.Button, {
                                size: "lg",
                                className: "w-full",
                                asChild: !0,
                                children: (0, s.jsxs)("a", {
                                  href: "https://www.sordum.org/downloads/?dcontrol",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  children: [
                                    (0, s.jsx)(a.Download, {
                                      className: "mr-2 h-5 w-5",
                                    }),
                                    "Download Defender Control",
                                  ],
                                }),
                              }),
                              (0, s.jsx)(u.Button, {
                                size: "lg",
                                className: "w-full bg-transparent",
                                variant: "outline",
                                asChild: !0,
                                children: (0, s.jsxs)("a", {
                                  href: "https://www.sordum.org/downloads/?st-windows-update-blocker",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  children: [
                                    (0, s.jsx)(a.Download, {
                                      className: "mr-2 h-5 w-5",
                                    }),
                                    "Download Windows Update Blocker",
                                  ],
                                }),
                              }),
                              (0, s.jsx)("p", {
                                className: "text-sm text-muted-foreground",
                                children:
                                  "Use these tools to completely disable Windows Defender and block updates",
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                4 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-blue-500 text-white font-bold text-2xl",
                            children: "4",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children:
                                  "Disable Background Apps & Startup Programs",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children: "Clean up unnecessary processes",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Disable Background Apps:",
                          }),
                          (0, s.jsxs)("ol", {
                            className: "space-y-2 text-sm",
                            children: [
                              (0, s.jsx)("li", {
                                children:
                                  "1. Open Settings → Privacy → Background apps",
                              }),
                              (0, s.jsx)("li", {
                                children: "2. Turn off all background apps",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Disable Startup Applications:",
                          }),
                          (0, s.jsxs)("ol", {
                            className: "space-y-2 text-sm",
                            children: [
                              (0, s.jsx)("li", {
                                children:
                                  "1. Press Ctrl + Shift + Esc to open Task Manager",
                              }),
                              (0, s.jsx)("li", {
                                children: '2. Go to the "Startup" tab',
                              }),
                              (0, s.jsx)("li", {
                                children: "3. Disable ALL startup applications",
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                5 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white font-bold text-2xl",
                            children: "5",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children: "Save Your Original Serials",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children: "Backup before spoofing",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)(x.Alert, {
                        className: "border-destructive/50 bg-destructive/10",
                        children: [
                          (0, s.jsx)(n.AlertTriangle, {
                            className: "h-5 w-5 text-destructive",
                          }),
                          (0, s.jsx)(x.AlertDescription, {
                            className: "text-base font-semibold",
                            children:
                              "CRITICAL: Save your serials NOW! You'll need them to verify the spoof worked!",
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "How to Save Serials:",
                          }),
                          (0, s.jsxs)("ol", {
                            className: "space-y-3 text-sm",
                            children: [
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "1",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Use the Serial Checker tool from the tools pack you downloaded",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "2",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "Copy all your current serials",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "3",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Save them in a text document on your desktop",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                6 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                            children: "6",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children: "Download Spoofer",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children: "Get the latest Ghosty-Spoofer",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)(x.Alert, {
                        className: "border-green-500/50 bg-green-500/10",
                        children: [
                          (0, s.jsx)(i.CheckCircle2, {
                            className: "h-5 w-5 text-green-500",
                          }),
                          (0, s.jsxs)(x.AlertDescription, {
                            children: [
                              (0, s.jsx)("strong", {
                                children: "Auto-Update Added!",
                              }),
                              " You no longer need to download new versions. The loader will update automatically when new versions are available.",
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)(u.Button, {
                            size: "lg",
                            className: "w-full",
                            asChild: !0,
                            children: (0, s.jsxs)("a", {
                              href: "https://workupload.com/file/P4e4fugEh84",
                              target: "_blank",
                              rel: "noopener noreferrer",
                              children: [
                                (0, s.jsx)(a.Download, {
                                  className: "mr-2 h-5 w-5",
                                }),
                                "Download Ghosty-Spoofer",
                              ],
                            }),
                          }),
                          (0, s.jsx)("div", {
                            className:
                              "bg-muted border border-border rounded-lg p-4 space-y-2",
                            children: (0, s.jsxs)("div", {
                              className: "flex items-center gap-2",
                              children: [
                                (0, s.jsx)("button", {
                                  onClick: () => p(!f),
                                  className:
                                    "text-sm text-muted-foreground hover:text-foreground underline transition-colors",
                                  children: f
                                    ? "Hide password"
                                    : "Click to see password",
                                }),
                                f &&
                                  (0, s.jsx)("span", {
                                    className:
                                      "text-sm font-mono bg-background px-3 py-1 rounded border",
                                    children: "123",
                                  }),
                              ],
                            }),
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-blue-500/10 border border-blue-500/30 rounded-lg p-6 space-y-3",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Update Logs:",
                          }),
                          (0, s.jsxs)("ul", {
                            className: "space-y-2 text-sm",
                            children: [
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "EAC & BE Spoof updated and optimized",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Better performance and stability",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Auto-update feature added - no more manual downloads!",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                7 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-primary text-white font-bold text-2xl",
                            children: "7",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children: "Run EAC & BE Spoof",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children: "Execute the spoofing process",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Spoofing Steps:",
                          }),
                          (0, s.jsxs)("ol", {
                            className: "space-y-3",
                            children: [
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "1",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      'Right-click the Ghosty-Spoofer and select "Run as Administrator"',
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "2",
                                  }),
                                  (0, s.jsxs)("span", {
                                    children: [
                                      "Click the ",
                                      (0, s.jsx)("strong", {
                                        children: "EAC & BE",
                                      }),
                                      " button to spoof for EAC/BattlEye games",
                                    ],
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "3",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Wait for the process to complete",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "4",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Your computer will automatically restart",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)(x.Alert, {
                        className: "border-blue-500/50 bg-blue-500/10",
                        children: [
                          (0, s.jsx)(o.Info, {
                            className: "h-5 w-5 text-blue-500",
                          }),
                          (0, s.jsx)(x.AlertDescription, {
                            children:
                              "No BIOS modifications or TPM changes needed for EAC/BE games - just run and go!",
                          }),
                        ],
                      }),
                    ],
                  }),
                8 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-green-500 text-white font-bold text-2xl",
                            children: "8",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children: "Verify Serials Changed",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children: "Compare before and after",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "How to Verify:",
                          }),
                          (0, s.jsxs)("ol", {
                            className: "space-y-3",
                            children: [
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "1",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Run the Serial Checker tool again",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "2",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Compare the new serials with the ones you saved earlier",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "3",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "If they're different, the spoof was successful!",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)(x.Alert, {
                        className: "border-green-500/50 bg-green-500/10",
                        children: [
                          (0, s.jsx)(i.CheckCircle2, {
                            className: "h-5 w-5 text-green-500",
                          }),
                          (0, s.jsx)(x.AlertDescription, {
                            children:
                              "All serials should be different from your original ones.",
                          }),
                        ],
                      }),
                    ],
                  }),
                9 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white font-bold text-2xl",
                            children: "9",
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children: "Test with New Account",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children:
                                  "Create a new account to test the spoof",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6 space-y-4",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg",
                            children: "Testing Steps:",
                          }),
                          (0, s.jsxs)("ol", {
                            className: "space-y-3",
                            children: [
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "1",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Create a NEW account for the game you want to play (Epic Games, Steam, etc.)",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "2",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "Download and install the game",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, s.jsx)("span", {
                                    className:
                                      "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm font-semibold",
                                    children: "3",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Launch the game and play for a while to confirm everything works",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)(x.Alert, {
                        className: "border-blue-500/50 bg-blue-500/10",
                        children: [
                          (0, s.jsx)(o.Info, {
                            className: "h-5 w-5 text-blue-500",
                          }),
                          (0, s.jsx)(x.AlertDescription, {
                            children:
                              "Always test with a new account first to make sure the spoof is working before using your main account.",
                          }),
                        ],
                      }),
                    ],
                  }),
                10 === e &&
                  (0, s.jsxs)("div", {
                    className: "space-y-6 animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-start gap-4",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-green-500 text-white font-bold text-2xl",
                            children: (0, s.jsx)(i.CheckCircle2, {
                              className: "h-8 w-8",
                            }),
                          }),
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-3xl font-bold",
                                children: "All Done!",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-lg text-muted-foreground",
                                children:
                                  "You've successfully spoofed your HWID for EAC & BattlEye games.",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border border-border rounded-lg p-6",
                        children: [
                          (0, s.jsx)("h3", {
                            className: "font-semibold text-lg mb-4",
                            children: "Compatible Games:",
                          }),
                          (0, s.jsxs)("div", {
                            className: "grid grid-cols-2 gap-3",
                            children: [
                              (0, s.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500",
                                  }),
                                  (0, s.jsx)("span", { children: "Fortnite" }),
                                ],
                              }),
                              (0, s.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500",
                                  }),
                                  (0, s.jsx)("span", { children: "Rust" }),
                                ],
                              }),
                              (0, s.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "Apex Legends",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500",
                                  }),
                                  (0, s.jsx)("span", { children: "DayZ" }),
                                ],
                              }),
                              (0, s.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "Dead by Daylight",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "The Finals",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500",
                                  }),
                                  (0, s.jsx)("span", { children: "FiveM" }),
                                ],
                              }),
                              (0, s.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className: "h-4 w-4 text-green-500",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "Other EAC/BE games",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)(x.Alert, {
                        className: "border-green-500/50 bg-green-500/10",
                        children: [
                          (0, s.jsx)(i.CheckCircle2, {
                            className: "h-5 w-5 text-green-500",
                          }),
                          (0, s.jsx)(x.AlertDescription, {
                            children:
                              "Enjoy your games! Remember to always test with a new account first.",
                          }),
                        ],
                      }),
                    ],
                  }),
              ],
            }),
          }),
          (0, s.jsx)("section", {
            className:
              "py-8 px-4 bg-card/50 border-t border-border sticky bottom-0",
            children: (0, s.jsxs)("div", {
              className: "container mx-auto max-w-4xl flex justify-between",
              children: [
                (0, s.jsxs)(u.Button, {
                  variant: "outline",
                  onClick: () => {
                    e > 0 &&
                      (m(e - 1),
                      window.scrollTo({ top: 0, behavior: "smooth" }));
                  },
                  disabled: 0 === e,
                  className: "bg-transparent",
                  children: [
                    (0, s.jsx)(d.ChevronLeft, { className: "mr-2 h-5 w-5" }),
                    "Previous Step",
                  ],
                }),
                (0, s.jsxs)(u.Button, {
                  onClick: () => {
                    e < 10 &&
                      (m(e + 1),
                      window.scrollTo({ top: 0, behavior: "smooth" }));
                  },
                  disabled: 10 === e,
                  children: [
                    9 === e ? "Finish" : "Next Step",
                    (0, s.jsx)(c.ChevronRight, { className: "ml-2 h-5 w-5" }),
                  ],
                }),
              ],
            }),
          }),
        ],
      });
    }
    e.s(["default", () => m]);
  },
]);
