(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  85155,
  (e, t, r) => {
    "use strict";
    function n(e, t = {}) {
      if (t.onlyHashChange) return void e();
      let r = document.documentElement;
      if ("smooth" !== r.dataset.scrollBehavior) return void e();
      let a = r.style.scrollBehavior;
      (r.style.scrollBehavior = "auto"),
        t.dontForceLayout || r.getClientRects(),
        e(),
        (r.style.scrollBehavior = a);
    }
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "disableSmoothScrollDuringRouteTransition", {
        enumerable: !0,
        get: function () {
          return n;
        },
      }),
      e.r(60835);
  },
  21158,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "HTTPAccessFallbackBoundary", {
        enumerable: !0,
        get: function () {
          return l;
        },
      });
    let n = e.r(44066),
      a = e.r(93046),
      o = n._(e.r(80883)),
      i = e.r(15861),
      s = e.r(68019);
    e.r(60835);
    let c = e.r(89260);
    class u extends o.default.Component {
      constructor(e) {
        super(e),
          (this.state = {
            triggeredStatus: void 0,
            previousPathname: e.pathname,
          });
      }
      componentDidCatch() {}
      static getDerivedStateFromError(e) {
        if ((0, s.isHTTPAccessFallbackError)(e))
          return { triggeredStatus: (0, s.getAccessFallbackHTTPStatus)(e) };
        throw e;
      }
      static getDerivedStateFromProps(e, t) {
        return e.pathname !== t.previousPathname && t.triggeredStatus
          ? { triggeredStatus: void 0, previousPathname: e.pathname }
          : {
              triggeredStatus: t.triggeredStatus,
              previousPathname: e.pathname,
            };
      }
      render() {
        let {
            notFound: e,
            forbidden: t,
            unauthorized: r,
            children: n,
          } = this.props,
          { triggeredStatus: o } = this.state,
          i = {
            [s.HTTPAccessErrorStatus.NOT_FOUND]: e,
            [s.HTTPAccessErrorStatus.FORBIDDEN]: t,
            [s.HTTPAccessErrorStatus.UNAUTHORIZED]: r,
          };
        if (o) {
          let c = o === s.HTTPAccessErrorStatus.NOT_FOUND && e,
            u = o === s.HTTPAccessErrorStatus.FORBIDDEN && t,
            l = o === s.HTTPAccessErrorStatus.UNAUTHORIZED && r;
          return c || u || l
            ? (0, a.jsxs)(a.Fragment, {
                children: [
                  (0, a.jsx)("meta", { name: "robots", content: "noindex" }),
                  !1,
                  i[o],
                ],
              })
            : n;
        }
        return n;
      }
    }
    function l({ notFound: e, forbidden: t, unauthorized: r, children: n }) {
      let s = (0, i.useUntrackedPathname)(),
        l = (0, o.useContext)(c.MissingSlotContext);
      return e || t || r
        ? (0, a.jsx)(u, {
            pathname: s,
            notFound: e,
            forbidden: t,
            unauthorized: r,
            missingSlots: l,
            children: n,
          })
        : (0, a.jsx)(a.Fragment, { children: n });
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  32388,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "useRouterBFCache", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    let n = e.r(80883);
    function a(e, t) {
      let [r, a] = (0, n.useState)(() => ({
        tree: e,
        stateKey: t,
        next: null,
      }));
      if (r.tree === e) return r;
      let o = { tree: e, stateKey: t, next: null },
        i = 1,
        s = r,
        c = o;
      for (; null !== s && i < 1; ) {
        if (s.stateKey === t) {
          c.next = s.next;
          break;
        }
        {
          i++;
          let e = { tree: s.tree, stateKey: s.stateKey, next: null };
          (c.next = e), (c = e);
        }
        s = s.next;
      }
      return a(o), o;
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  86667,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function () {
          return x;
        },
      });
    let n = e.r(81258),
      a = e.r(44066),
      o = e.r(93046),
      i = e.r(53447),
      s = a._(e.r(80883)),
      c = n._(e.r(36425)),
      u = e.r(89260),
      l = e.r(99212),
      d = e.r(99060),
      f = e.r(83052),
      p = e.r(39210),
      h = e.r(85155),
      m = e.r(84944),
      g = e.r(21158),
      y = e.r(71378),
      b = e.r(26302),
      P = e.r(93023),
      _ = e.r(32388);
    e.r(31551);
    let S = e.r(94150),
      v = e.r(49185),
      O =
        c.default.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
      R = ["bottom", "height", "left", "right", "top", "width", "x", "y"];
    function E(e, t) {
      let r = e.getBoundingClientRect();
      return r.top >= 0 && r.top <= t;
    }
    class j extends s.default.Component {
      componentDidMount() {
        this.handlePotentialScroll();
      }
      componentDidUpdate() {
        this.props.focusAndScrollRef.apply && this.handlePotentialScroll();
      }
      render() {
        return this.props.children;
      }
      constructor(...e) {
        super(...e),
          (this.handlePotentialScroll = () => {
            let { focusAndScrollRef: e, segmentPath: t } = this.props;
            if (e.apply) {
              if (
                0 !== e.segmentPaths.length &&
                !e.segmentPaths.some((e) =>
                  t.every((t, r) => (0, p.matchSegment)(t, e[r]))
                )
              )
                return;
              let r = null,
                n = e.hashFragment;
              if (
                (n &&
                  (r =
                    "top" === n
                      ? document.body
                      : document.getElementById(n) ??
                        document.getElementsByName(n)[0]),
                r ||
                  (r =
                    "undefined" == typeof window
                      ? null
                      : (0, O.findDOMNode)(this)),
                !(r instanceof Element))
              )
                return;
              for (
                ;
                !(r instanceof HTMLElement) ||
                (function (e) {
                  if (
                    ["sticky", "fixed"].includes(getComputedStyle(e).position)
                  )
                    return !0;
                  let t = e.getBoundingClientRect();
                  return R.every((e) => 0 === t[e]);
                })(r);

              ) {
                if (null === r.nextElementSibling) return;
                r = r.nextElementSibling;
              }
              (e.apply = !1),
                (e.hashFragment = null),
                (e.segmentPaths = []),
                (0, h.disableSmoothScrollDuringRouteTransition)(
                  () => {
                    if (n) return void r.scrollIntoView();
                    let e = document.documentElement,
                      t = e.clientHeight;
                    !E(r, t) &&
                      ((e.scrollTop = 0), E(r, t) || r.scrollIntoView());
                  },
                  { dontForceLayout: !0, onlyHashChange: e.onlyHashChange }
                ),
                (e.onlyHashChange = !1),
                r.focus();
            }
          });
      }
    }
    function w({ segmentPath: e, children: t }) {
      let r = (0, s.useContext)(u.GlobalLayoutRouterContext);
      if (!r)
        throw Object.defineProperty(
          Error("invariant global layout router not mounted"),
          "__NEXT_ERROR_CODE",
          { value: "E473", enumerable: !1, configurable: !0 }
        );
      return (0, o.jsx)(j, {
        segmentPath: e,
        focusAndScrollRef: r.focusAndScrollRef,
        children: t,
      });
    }
    function C({
      tree: e,
      segmentPath: t,
      debugNameContext: r,
      cacheNode: n,
      params: a,
      url: c,
      isActive: f,
    }) {
      let h = (0, s.useContext)(u.GlobalLayoutRouterContext);
      if (((0, s.useContext)(S.NavigationPromisesContext), !h))
        throw Object.defineProperty(
          Error("invariant global layout router not mounted"),
          "__NEXT_ERROR_CODE",
          { value: "E473", enumerable: !1, configurable: !0 }
        );
      let { tree: m } = h,
        g = null !== n.prefetchRsc ? n.prefetchRsc : n.rsc,
        y = (0, s.useDeferredValue)(n.rsc, g),
        _ =
          "object" == typeof y && null !== y && "function" == typeof y.then
            ? (0, s.use)(y)
            : y;
      if (!_) {
        if (f) {
          let e = n.lazyData;
          if (null === e) {
            let r = (function e(t, r) {
                if (t) {
                  let [n, a] = t,
                    o = 2 === t.length;
                  if ((0, p.matchSegment)(r[0], n) && r[1].hasOwnProperty(a)) {
                    if (o) {
                      let t = e(void 0, r[1][a]);
                      return [
                        r[0],
                        { ...r[1], [a]: [t[0], t[1], t[2], "refetch"] },
                      ];
                    }
                    return [r[0], { ...r[1], [a]: e(t.slice(2), r[1][a]) }];
                  }
                }
                return r;
              })(["", ...t], m),
              a = (0, b.hasInterceptionRouteInCurrentTree)(m),
              o = Date.now();
            (n.lazyData = e =
              (0, l.fetchServerResponse)(new URL(c, location.origin), {
                flightRouterState: r,
                nextUrl: a ? h.previousNextUrl || h.nextUrl : null,
              }).then(
                (e) => (
                  (0, s.startTransition)(() => {
                    (0, P.dispatchAppRouterAction)({
                      type: i.ACTION_SERVER_PATCH,
                      previousTree: m,
                      serverResponse: e,
                      navigatedAt: o,
                    });
                  }),
                  e
                )
              )),
              (0, s.use)(e);
          }
        }
        (0, s.use)(d.unresolvedThenable);
      }
      return (0, o.jsx)(u.LayoutRouterContext.Provider, {
        value: {
          parentTree: e,
          parentCacheNode: n,
          parentSegmentPath: t,
          parentParams: a,
          debugNameContext: r,
          url: c,
          isActive: f,
        },
        children: _,
      });
    }
    function T({ name: e, loading: t, children: r }) {
      let n;
      if (
        (n =
          "object" == typeof t && null !== t && "function" == typeof t.then
            ? (0, s.use)(t)
            : t)
      ) {
        let t = n[0],
          a = n[1],
          i = n[2];
        return (0, o.jsx)(s.Suspense, {
          name: e,
          fallback: (0, o.jsxs)(o.Fragment, { children: [a, i, t] }),
          children: r,
        });
      }
      return (0, o.jsx)(o.Fragment, { children: r });
    }
    function x({
      parallelRouterKey: e,
      error: t,
      errorStyles: r,
      errorScripts: n,
      templateStyles: a,
      templateScripts: i,
      template: c,
      notFound: l,
      forbidden: d,
      unauthorized: p,
      segmentViewBoundaries: h,
    }) {
      let b = (0, s.useContext)(u.LayoutRouterContext);
      if (!b)
        throw Object.defineProperty(
          Error("invariant expected layout router to be mounted"),
          "__NEXT_ERROR_CODE",
          { value: "E56", enumerable: !1, configurable: !0 }
        );
      let {
          parentTree: P,
          parentCacheNode: S,
          parentSegmentPath: O,
          parentParams: R,
          url: E,
          isActive: j,
          debugNameContext: x,
        } = b,
        A = S.parallelRoutes,
        M = A.get(e);
      M || ((M = new Map()), A.set(e, M));
      let D = P[0],
        I = null === O ? [e] : O.concat([D, e]),
        F = P[1][e],
        N = F[0],
        k = (0, y.createRouterCacheKey)(N, !0),
        U = (0, _.useRouterBFCache)(F, k),
        L = [];
      do {
        let e = U.tree,
          s = U.stateKey,
          h = e[0],
          b = (0, y.createRouterCacheKey)(h),
          P = M.get(b);
        if (void 0 === P) {
          let e = {
            lazyData: null,
            rsc: null,
            prefetchRsc: null,
            head: null,
            prefetchHead: null,
            parallelRoutes: new Map(),
            loading: null,
            navigatedAt: -1,
          };
          (P = e), M.set(b, e);
        }
        let _ = R;
        if (Array.isArray(h)) {
          let e = h[0],
            t = h[1],
            r = h[2],
            n = (0, v.getParamValueFromCacheKey)(t, r);
          null !== n && (_ = { ...R, [e]: n });
        }
        let O = (function (e) {
            if ("/" === e) return "/";
            if ("string" == typeof e)
              if ("(slot)" === e) return;
              else return e + "/";
            return e[1] + "/";
          })(h),
          A = O ?? x,
          D = void 0 === O ? void 0 : x,
          F = S.loading,
          N = (0, o.jsxs)(
            u.TemplateContext.Provider,
            {
              value: (0, o.jsxs)(w, {
                segmentPath: I,
                children: [
                  (0, o.jsx)(f.ErrorBoundary, {
                    errorComponent: t,
                    errorStyles: r,
                    errorScripts: n,
                    children: (0, o.jsx)(T, {
                      name: D,
                      loading: F,
                      children: (0, o.jsx)(g.HTTPAccessFallbackBoundary, {
                        notFound: l,
                        forbidden: d,
                        unauthorized: p,
                        children: (0, o.jsxs)(m.RedirectBoundary, {
                          children: [
                            (0, o.jsx)(C, {
                              url: E,
                              tree: e,
                              params: _,
                              cacheNode: P,
                              segmentPath: I,
                              debugNameContext: A,
                              isActive: j && s === k,
                            }),
                            null,
                          ],
                        }),
                      }),
                    }),
                  }),
                  null,
                ],
              }),
              children: [a, i, c],
            },
            s
          );
        L.push(N), (U = U.next);
      } while (null !== U);
      return L;
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  28996,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function () {
          return s;
        },
      });
    let n = e.r(44066),
      a = e.r(93046),
      o = n._(e.r(80883)),
      i = e.r(89260);
    function s() {
      let e = (0, o.useContext)(i.TemplateContext);
      return (0, a.jsx)(a.Fragment, { children: e });
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  74541,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    let n = new WeakMap();
    function a(e) {
      let t = n.get(e);
      if (t) return t;
      let r = Promise.resolve(e);
      return n.set(e, r), r;
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  13562,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let n = e.r(74541).createRenderSearchParamsFromClient;
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  9258,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    let n = new WeakMap();
    function a(e) {
      let t = n.get(e);
      if (t) return t;
      let r = Promise.resolve(e);
      return n.set(e, r), r;
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  10708,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let n = e.r(9258).createRenderParamsFromClient;
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  62790,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "ReflectAdapter", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    class n {
      static get(e, t, r) {
        let n = Reflect.get(e, t, r);
        return "function" == typeof n ? n.bind(e) : n;
      }
      static set(e, t, r, n) {
        return Reflect.set(e, t, r, n);
      }
      static has(e, t) {
        return Reflect.has(e, t);
      }
      static deleteProperty(e, t) {
        return Reflect.deleteProperty(e, t);
      }
    }
  },
  99484,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "createDedupedByCallsiteServerErrorLoggerDev", {
        enumerable: !0,
        get: function () {
          return c;
        },
      });
    let n = (function (e, t) {
      if (e && e.__esModule) return e;
      if (null === e || ("object" != typeof e && "function" != typeof e))
        return { default: e };
      var r = a(void 0);
      if (r && r.has(e)) return r.get(e);
      var n = { __proto__: null },
        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
      for (var i in e)
        if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
          var s = o ? Object.getOwnPropertyDescriptor(e, i) : null;
          s && (s.get || s.set)
            ? Object.defineProperty(n, i, s)
            : (n[i] = e[i]);
        }
      return (n.default = e), r && r.set(e, n), n;
    })(e.r(80883));
    function a(e) {
      if ("function" != typeof WeakMap) return null;
      var t = new WeakMap(),
        r = new WeakMap();
      return (a = function (e) {
        return e ? r : t;
      })(e);
    }
    let o = { current: null },
      i = "function" == typeof n.cache ? n.cache : (e) => e,
      s = console.warn;
    function c(e) {
      return function (...t) {
        s(e(...t));
      };
    }
    i((e) => {
      try {
        s(o.current);
      } finally {
        o.current = null;
      }
    });
  },
  87538,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      describeHasCheckingStringProperty: function () {
        return s;
      },
      describeStringPropertyAccess: function () {
        return i;
      },
      wellKnownProperties: function () {
        return c;
      },
    };
    for (var a in n) Object.defineProperty(r, a, { enumerable: !0, get: n[a] });
    let o = /^[A-Za-z_$][A-Za-z0-9_$]*$/;
    function i(e, t) {
      return o.test(t) ? `\`${e}.${t}\`` : `\`${e}[${JSON.stringify(t)}]\``;
    }
    function s(e, t) {
      let r = JSON.stringify(t);
      return `\`Reflect.has(${e}, ${r})\`, \`${r} in ${e}\`, or similar`;
    }
    let c = new Set([
      "hasOwnProperty",
      "isPrototypeOf",
      "propertyIsEnumerable",
      "toString",
      "valueOf",
      "toLocaleString",
      "then",
      "catch",
      "finally",
      "status",
      "displayName",
      "_debugInfo",
      "toJSON",
      "$$typeof",
      "__esModule",
    ]);
  },
  5161,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "afterTaskAsyncStorageInstance", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let n = (0, e.r(25933).createAsyncLocalStorage)();
  },
  50688,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "afterTaskAsyncStorage", {
        enumerable: !0,
        get: function () {
          return n.afterTaskAsyncStorageInstance;
        },
      });
    let n = e.r(5161);
  },
  31785,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      isRequestAPICallableInsideAfter: function () {
        return u;
      },
      throwForSearchParamsAccessInUseCache: function () {
        return c;
      },
      throwWithStaticGenerationBailoutErrorWithDynamicError: function () {
        return s;
      },
    };
    for (var a in n) Object.defineProperty(r, a, { enumerable: !0, get: n[a] });
    let o = e.r(77094),
      i = e.r(50688);
    function s(e, t) {
      throw Object.defineProperty(
        new o.StaticGenBailoutError(
          `Route ${e} with \`dynamic = "error"\` couldn't be rendered statically because it used ${t}. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`
        ),
        "__NEXT_ERROR_CODE",
        { value: "E543", enumerable: !1, configurable: !0 }
      );
    }
    function c(e, t) {
      let r = Object.defineProperty(
        Error(
          `Route ${e.route} used \`searchParams\` inside "use cache". Accessing dynamic request data inside a cache scope is not supported. If you need some search params inside a cached function await \`searchParams\` outside of the cached function and pass only the required search params as arguments to the cached function. See more info here: https://nextjs.org/docs/messages/next-request-in-use-cache`
        ),
        "__NEXT_ERROR_CODE",
        { value: "E842", enumerable: !1, configurable: !0 }
      );
      throw (
        (Error.captureStackTrace(r, t), (e.invalidDynamicUsageError ??= r), r)
      );
    }
    function u() {
      let e = i.afterTaskAsyncStorage.getStore();
      return (null == e ? void 0 : e.rootTaskSpawnPhase) === "action";
    }
  },
  62836,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n,
      a = {
        RenderStage: function () {
          return c;
        },
        StagedRenderingController: function () {
          return u;
        },
      };
    for (var o in a) Object.defineProperty(r, o, { enumerable: !0, get: a[o] });
    let i = e.r(4388),
      s = e.r(55049);
    var c =
      (((n = {})[(n.Before = 1)] = "Before"),
      (n[(n.Static = 2)] = "Static"),
      (n[(n.Runtime = 3)] = "Runtime"),
      (n[(n.Dynamic = 4)] = "Dynamic"),
      (n[(n.Abandoned = 5)] = "Abandoned"),
      n);
    class u {
      constructor(e = null, t) {
        (this.abortSignal = e),
          (this.hasRuntimePrefetch = t),
          (this.currentStage = 1),
          (this.staticInterruptReason = null),
          (this.runtimeInterruptReason = null),
          (this.staticStageEndTime = 1 / 0),
          (this.runtimeStageEndTime = 1 / 0),
          (this.runtimeStageListeners = []),
          (this.dynamicStageListeners = []),
          (this.runtimeStagePromise = (0, s.createPromiseWithResolvers)()),
          (this.dynamicStagePromise = (0, s.createPromiseWithResolvers)()),
          (this.mayAbandon = !1),
          e &&
            (e.addEventListener(
              "abort",
              () => {
                let { reason: t } = e;
                this.currentStage < 3 &&
                  (this.runtimeStagePromise.promise.catch(l),
                  this.runtimeStagePromise.reject(t)),
                  (this.currentStage < 4 || 5 === this.currentStage) &&
                    (this.dynamicStagePromise.promise.catch(l),
                    this.dynamicStagePromise.reject(t));
              },
              { once: !0 }
            ),
            (this.mayAbandon = !0));
      }
      onStage(e, t) {
        if (this.currentStage >= e) t();
        else if (3 === e) this.runtimeStageListeners.push(t);
        else if (4 === e) this.dynamicStageListeners.push(t);
        else
          throw Object.defineProperty(
            new i.InvariantError(`Invalid render stage: ${e}`),
            "__NEXT_ERROR_CODE",
            { value: "E881", enumerable: !1, configurable: !0 }
          );
      }
      canSyncInterrupt() {
        if (1 === this.currentStage) return !1;
        let e = this.hasRuntimePrefetch ? 4 : 3;
        return this.currentStage < e;
      }
      syncInterruptCurrentStageWithReason(e) {
        if (1 !== this.currentStage) {
          if (this.mayAbandon) return this.abandonRenderImpl();
          switch (this.currentStage) {
            case 2:
              (this.staticInterruptReason = e), this.advanceStage(4);
              return;
            case 3:
              this.hasRuntimePrefetch &&
                ((this.runtimeInterruptReason = e), this.advanceStage(4));
              return;
          }
        }
      }
      getStaticInterruptReason() {
        return this.staticInterruptReason;
      }
      getRuntimeInterruptReason() {
        return this.runtimeInterruptReason;
      }
      getStaticStageEndTime() {
        return this.staticStageEndTime;
      }
      getRuntimeStageEndTime() {
        return this.runtimeStageEndTime;
      }
      abandonRender() {
        if (!this.mayAbandon)
          throw Object.defineProperty(
            new i.InvariantError(
              "`abandonRender` called on a stage controller that cannot be abandoned."
            ),
            "__NEXT_ERROR_CODE",
            { value: "E938", enumerable: !1, configurable: !0 }
          );
        this.abandonRenderImpl();
      }
      abandonRenderImpl() {
        let { currentStage: e } = this;
        switch (e) {
          case 2:
            (this.currentStage = 5), this.resolveRuntimeStage();
            return;
          case 3:
            this.currentStage = 5;
            return;
        }
      }
      advanceStage(e) {
        if (e <= this.currentStage) return;
        let t = this.currentStage;
        if (
          ((this.currentStage = e),
          t < 3 &&
            e >= 3 &&
            ((this.staticStageEndTime =
              performance.now() + performance.timeOrigin),
            this.resolveRuntimeStage()),
          t < 4 && e >= 4)
        ) {
          (this.runtimeStageEndTime =
            performance.now() + performance.timeOrigin),
            this.resolveDynamicStage();
          return;
        }
      }
      resolveRuntimeStage() {
        let e = this.runtimeStageListeners;
        for (let t = 0; t < e.length; t++) e[t]();
        (e.length = 0), this.runtimeStagePromise.resolve();
      }
      resolveDynamicStage() {
        let e = this.dynamicStageListeners;
        for (let t = 0; t < e.length; t++) e[t]();
        (e.length = 0), this.dynamicStagePromise.resolve();
      }
      getStagePromise(e) {
        switch (e) {
          case 3:
            return this.runtimeStagePromise.promise;
          case 4:
            return this.dynamicStagePromise.promise;
          default:
            throw Object.defineProperty(
              new i.InvariantError(`Invalid render stage: ${e}`),
              "__NEXT_ERROR_CODE",
              { value: "E881", enumerable: !1, configurable: !0 }
            );
        }
      }
      waitForStage(e) {
        return this.getStagePromise(e);
      }
      delayUntilStage(e, t, r) {
        var n, a, o;
        let i,
          s =
            ((n = this.getStagePromise(e)),
            (a = t),
            (o = r),
            (i = new Promise((e, t) => {
              n.then(e.bind(null, o), t);
            })),
            void 0 !== a && (i.displayName = a),
            i);
        return this.abortSignal && s.catch(l), s;
      }
    }
    function l() {}
  },
  86258,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      createPrerenderSearchParamsForClientPage: function () {
        return g;
      },
      createSearchParamsFromClient: function () {
        return p;
      },
      createServerSearchParamsForMetadata: function () {
        return h;
      },
      createServerSearchParamsForServerPage: function () {
        return m;
      },
      makeErroringSearchParamsForUseCache: function () {
        return S;
      },
    };
    for (var a in n) Object.defineProperty(r, a, { enumerable: !0, get: n[a] });
    let o = e.r(62790),
      i = e.r(65044),
      s = e.r(70979),
      c = e.r(4388),
      u = e.r(24120),
      l = e.r(99484),
      d = e.r(87538),
      f = e.r(31785);
    function p(e, t) {
      let r = s.workUnitAsyncStorage.getStore();
      if (r)
        switch (r.type) {
          case "prerender":
          case "prerender-client":
          case "prerender-ppr":
          case "prerender-legacy":
            return y(t, r);
          case "prerender-runtime":
            throw Object.defineProperty(
              new c.InvariantError(
                "createSearchParamsFromClient should not be called in a runtime prerender."
              ),
              "__NEXT_ERROR_CODE",
              { value: "E769", enumerable: !1, configurable: !0 }
            );
          case "cache":
          case "private-cache":
          case "unstable-cache":
            throw Object.defineProperty(
              new c.InvariantError(
                "createSearchParamsFromClient should not be called in cache contexts."
              ),
              "__NEXT_ERROR_CODE",
              { value: "E739", enumerable: !1, configurable: !0 }
            );
          case "request":
            return b(e, t, r);
        }
      (0, s.throwInvariantForMissingStore)();
    }
    e.r(62836);
    let h = m;
    function m(e, t) {
      let r = s.workUnitAsyncStorage.getStore();
      if (r)
        switch (r.type) {
          case "prerender":
          case "prerender-client":
          case "prerender-ppr":
          case "prerender-legacy":
            return y(t, r);
          case "cache":
          case "private-cache":
          case "unstable-cache":
            throw Object.defineProperty(
              new c.InvariantError(
                "createServerSearchParamsForServerPage should not be called in cache contexts."
              ),
              "__NEXT_ERROR_CODE",
              { value: "E747", enumerable: !1, configurable: !0 }
            );
          case "prerender-runtime":
            var n, a;
            return (n = e), (a = r), (0, i.delayUntilRuntimeStage)(a, v(n));
          case "request":
            return b(e, t, r);
        }
      (0, s.throwInvariantForMissingStore)();
    }
    function g(e) {
      if (e.forceStatic) return Promise.resolve({});
      let t = s.workUnitAsyncStorage.getStore();
      if (t)
        switch (t.type) {
          case "prerender":
          case "prerender-client":
            return (0, u.makeHangingPromise)(
              t.renderSignal,
              e.route,
              "`searchParams`"
            );
          case "prerender-runtime":
            throw Object.defineProperty(
              new c.InvariantError(
                "createPrerenderSearchParamsForClientPage should not be called in a runtime prerender."
              ),
              "__NEXT_ERROR_CODE",
              { value: "E768", enumerable: !1, configurable: !0 }
            );
          case "cache":
          case "private-cache":
          case "unstable-cache":
            throw Object.defineProperty(
              new c.InvariantError(
                "createPrerenderSearchParamsForClientPage should not be called in cache contexts."
              ),
              "__NEXT_ERROR_CODE",
              { value: "E746", enumerable: !1, configurable: !0 }
            );
          case "prerender-ppr":
          case "prerender-legacy":
          case "request":
            return Promise.resolve({});
        }
      (0, s.throwInvariantForMissingStore)();
    }
    function y(e, t) {
      if (e.forceStatic) return Promise.resolve({});
      switch (t.type) {
        case "prerender":
        case "prerender-client":
          var r = e,
            n = t;
          let a = P.get(n);
          if (a) return a;
          let s = (0, u.makeHangingPromise)(
              n.renderSignal,
              r.route,
              "`searchParams`"
            ),
            c = new Proxy(s, {
              get(e, t, r) {
                if (Object.hasOwn(s, t)) return o.ReflectAdapter.get(e, t, r);
                switch (t) {
                  case "then":
                    return (
                      (0, i.annotateDynamicAccess)(
                        "`await searchParams`, `searchParams.then`, or similar",
                        n
                      ),
                      o.ReflectAdapter.get(e, t, r)
                    );
                  case "status":
                    return (
                      (0, i.annotateDynamicAccess)(
                        "`use(searchParams)`, `searchParams.status`, or similar",
                        n
                      ),
                      o.ReflectAdapter.get(e, t, r)
                    );
                  default:
                    return o.ReflectAdapter.get(e, t, r);
                }
              },
            });
          return P.set(n, c), c;
        case "prerender-ppr":
        case "prerender-legacy":
          var l = e,
            d = t;
          let p = P.get(l);
          if (p) return p;
          let h = Promise.resolve({}),
            m = new Proxy(h, {
              get(e, t, r) {
                if (Object.hasOwn(h, t)) return o.ReflectAdapter.get(e, t, r);
                if ("string" == typeof t && "then" === t) {
                  let e =
                    "`await searchParams`, `searchParams.then`, or similar";
                  l.dynamicShouldError
                    ? (0,
                      f.throwWithStaticGenerationBailoutErrorWithDynamicError)(
                        l.route,
                        e
                      )
                    : "prerender-ppr" === d.type
                    ? (0, i.postponeWithTracking)(l.route, e, d.dynamicTracking)
                    : (0, i.throwToInterruptStaticGeneration)(e, l, d);
                }
                return o.ReflectAdapter.get(e, t, r);
              },
            });
          return P.set(l, m), m;
        default:
          return t;
      }
    }
    function b(e, t, r) {
      return t.forceStatic ? Promise.resolve({}) : v(e);
    }
    let P = new WeakMap(),
      _ = new WeakMap();
    function S(e) {
      let t = _.get(e);
      if (t) return t;
      let r = Promise.resolve({}),
        n = new Proxy(r, {
          get: function t(n, a, i) {
            return (
              Object.hasOwn(r, a) ||
                "string" != typeof a ||
                ("then" !== a && d.wellKnownProperties.has(a)) ||
                (0, f.throwForSearchParamsAccessInUseCache)(e, t),
              o.ReflectAdapter.get(n, a, i)
            );
          },
        });
      return _.set(e, n), n;
    }
    function v(e) {
      let t = P.get(e);
      if (t) return t;
      let r = Promise.resolve(e);
      return P.set(e, r), r;
    }
    (0, l.createDedupedByCallsiteServerErrorLoggerDev)(function (e, t) {
      let r = e ? `Route "${e}" ` : "This route ";
      return Object.defineProperty(
        Error(
          `${r}used ${t}. \`searchParams\` is a Promise and must be unwrapped with \`await\` or \`React.use()\` before accessing its properties. Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis`
        ),
        "__NEXT_ERROR_CODE",
        { value: "E848", enumerable: !1, configurable: !0 }
      );
    });
  },
  28276,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "dynamicAccessAsyncStorageInstance", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let n = (0, e.r(25933).createAsyncLocalStorage)();
  },
  89396,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "dynamicAccessAsyncStorage", {
        enumerable: !0,
        get: function () {
          return n.dynamicAccessAsyncStorageInstance;
        },
      });
    let n = e.r(28276);
  },
  63935,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      createParamsFromClient: function () {
        return h;
      },
      createPrerenderParamsForClientSegment: function () {
        return b;
      },
      createServerParamsForMetadata: function () {
        return m;
      },
      createServerParamsForRoute: function () {
        return g;
      },
      createServerParamsForServerSegment: function () {
        return y;
      },
    };
    for (var a in n) Object.defineProperty(r, a, { enumerable: !0, get: n[a] });
    let o = e.r(85047),
      i = e.r(62790),
      s = e.r(65044),
      c = e.r(70979),
      u = e.r(4388),
      l = e.r(87538),
      d = e.r(24120),
      f = e.r(99484),
      p = e.r(89396);
    function h(e, t) {
      let r = c.workUnitAsyncStorage.getStore();
      if (r)
        switch (r.type) {
          case "prerender":
          case "prerender-client":
          case "prerender-ppr":
          case "prerender-legacy":
            return P(e, t, r);
          case "cache":
          case "private-cache":
          case "unstable-cache":
            throw Object.defineProperty(
              new u.InvariantError(
                "createParamsFromClient should not be called in cache contexts."
              ),
              "__NEXT_ERROR_CODE",
              { value: "E736", enumerable: !1, configurable: !0 }
            );
          case "prerender-runtime":
            throw Object.defineProperty(
              new u.InvariantError(
                "createParamsFromClient should not be called in a runtime prerender."
              ),
              "__NEXT_ERROR_CODE",
              { value: "E770", enumerable: !1, configurable: !0 }
            );
          case "request":
            return O(e);
        }
      (0, c.throwInvariantForMissingStore)();
    }
    e.r(62836);
    let m = y;
    function g(e, t) {
      let r = c.workUnitAsyncStorage.getStore();
      if (r)
        switch (r.type) {
          case "prerender":
          case "prerender-client":
          case "prerender-ppr":
          case "prerender-legacy":
            return P(e, t, r);
          case "cache":
          case "private-cache":
          case "unstable-cache":
            throw Object.defineProperty(
              new u.InvariantError(
                "createServerParamsForRoute should not be called in cache contexts."
              ),
              "__NEXT_ERROR_CODE",
              { value: "E738", enumerable: !1, configurable: !0 }
            );
          case "prerender-runtime":
            return _(e, r);
          case "request":
            return O(e);
        }
      (0, c.throwInvariantForMissingStore)();
    }
    function y(e, t) {
      let r = c.workUnitAsyncStorage.getStore();
      if (r)
        switch (r.type) {
          case "prerender":
          case "prerender-client":
          case "prerender-ppr":
          case "prerender-legacy":
            return P(e, t, r);
          case "cache":
          case "private-cache":
          case "unstable-cache":
            throw Object.defineProperty(
              new u.InvariantError(
                "createServerParamsForServerSegment should not be called in cache contexts."
              ),
              "__NEXT_ERROR_CODE",
              { value: "E743", enumerable: !1, configurable: !0 }
            );
          case "prerender-runtime":
            return _(e, r);
          case "request":
            return O(e);
        }
      (0, c.throwInvariantForMissingStore)();
    }
    function b(e) {
      let t = o.workAsyncStorage.getStore();
      if (!t)
        throw Object.defineProperty(
          new u.InvariantError(
            "Missing workStore in createPrerenderParamsForClientSegment"
          ),
          "__NEXT_ERROR_CODE",
          { value: "E773", enumerable: !1, configurable: !0 }
        );
      let r = c.workUnitAsyncStorage.getStore();
      if (r)
        switch (r.type) {
          case "prerender":
          case "prerender-client":
            let n = r.fallbackRouteParams;
            if (n) {
              for (let a in e)
                if (n.has(a))
                  return (0, d.makeHangingPromise)(
                    r.renderSignal,
                    t.route,
                    "`params`"
                  );
            }
            break;
          case "cache":
          case "private-cache":
          case "unstable-cache":
            throw Object.defineProperty(
              new u.InvariantError(
                "createPrerenderParamsForClientSegment should not be called in cache contexts."
              ),
              "__NEXT_ERROR_CODE",
              { value: "E734", enumerable: !1, configurable: !0 }
            );
        }
      return Promise.resolve(e);
    }
    function P(e, t, r) {
      switch (r.type) {
        case "prerender":
        case "prerender-client": {
          let n = r.fallbackRouteParams;
          if (n) {
            for (let a in e)
              if (n.has(a))
                return (function (e, t, r) {
                  let n = S.get(e);
                  if (n) return n;
                  let a = new Proxy(
                    (0, d.makeHangingPromise)(
                      r.renderSignal,
                      t.route,
                      "`params`"
                    ),
                    v
                  );
                  return S.set(e, a), a;
                })(e, t, r);
          }
          break;
        }
        case "prerender-ppr": {
          let n = r.fallbackRouteParams;
          if (n) {
            for (let a in e)
              if (n.has(a))
                return (function (e, t, r, n) {
                  let a = S.get(e);
                  if (a) return a;
                  let o = { ...e },
                    i = Promise.resolve(o);
                  return (
                    S.set(e, i),
                    Object.keys(e).forEach((e) => {
                      l.wellKnownProperties.has(e) ||
                        (t.has(e) &&
                          Object.defineProperty(o, e, {
                            get() {
                              let t = (0, l.describeStringPropertyAccess)(
                                "params",
                                e
                              );
                              "prerender-ppr" === n.type
                                ? (0, s.postponeWithTracking)(
                                    r.route,
                                    t,
                                    n.dynamicTracking
                                  )
                                : (0, s.throwToInterruptStaticGeneration)(
                                    t,
                                    r,
                                    n
                                  );
                            },
                            enumerable: !0,
                          }));
                    }),
                    i
                  );
                })(e, n, t, r);
          }
        }
      }
      return O(e);
    }
    function _(e, t) {
      return (0, s.delayUntilRuntimeStage)(t, O(e));
    }
    let S = new WeakMap(),
      v = {
        get: function (e, t, r) {
          if ("then" === t || "catch" === t || "finally" === t) {
            let n = i.ReflectAdapter.get(e, t, r);
            return {
              [t]: (...t) => {
                let r = p.dynamicAccessAsyncStorage.getStore();
                return (
                  r &&
                    r.abortController.abort(
                      Object.defineProperty(
                        Error(
                          "Accessed fallback `params` during prerendering."
                        ),
                        "__NEXT_ERROR_CODE",
                        { value: "E691", enumerable: !1, configurable: !0 }
                      )
                    ),
                  new Proxy(n.apply(e, t), v)
                );
              },
            }[t];
          }
          return i.ReflectAdapter.get(e, t, r);
        },
      };
    function O(e) {
      let t = S.get(e);
      if (t) return t;
      let r = Promise.resolve(e);
      return S.set(e, r), r;
    }
    (0, f.createDedupedByCallsiteServerErrorLoggerDev)(function (e, t) {
      let r = e ? `Route "${e}" ` : "This route ";
      return Object.defineProperty(
        Error(
          `${r}used ${t}. \`params\` is a Promise and must be unwrapped with \`await\` or \`React.use()\` before accessing its properties. Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis`
        ),
        "__NEXT_ERROR_CODE",
        { value: "E834", enumerable: !1, configurable: !0 }
      );
    });
  },
  75091,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "ClientPageRoot", {
        enumerable: !0,
        get: function () {
          return u;
        },
      });
    let n = e.r(93046),
      a = e.r(4388),
      o = e.r(89260),
      i = e.r(80883),
      s = e.r(49185),
      c = e.r(94150);
    function u({ Component: t, serverProvidedParams: r }) {
      let u, l;
      if (null !== r) (u = r.searchParams), (l = r.params);
      else {
        let e = (0, i.use)(o.LayoutRouterContext);
        (l = null !== e ? e.parentParams : {}),
          (u = (0, s.urlSearchParamsToParsedUrlQuery)(
            (0, i.use)(c.SearchParamsContext)
          ));
      }
      if ("undefined" == typeof window) {
        let r,
          o,
          { workAsyncStorage: i } = e.r(85047),
          s = i.getStore();
        if (!s)
          throw Object.defineProperty(
            new a.InvariantError(
              "Expected workStore to exist when handling searchParams in a client Page."
            ),
            "__NEXT_ERROR_CODE",
            { value: "E564", enumerable: !1, configurable: !0 }
          );
        let { createSearchParamsFromClient: c } = e.r(86258);
        r = c(u, s);
        let { createParamsFromClient: d } = e.r(63935);
        return (o = d(l, s)), (0, n.jsx)(t, { params: o, searchParams: r });
      }
      {
        let { createRenderSearchParamsFromClient: r } = e.r(13562),
          a = r(u),
          { createRenderParamsFromClient: o } = e.r(10708),
          i = o(l);
        return (0, n.jsx)(t, { params: i, searchParams: a });
      }
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  26839,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "ClientSegmentRoot", {
        enumerable: !0,
        get: function () {
          return s;
        },
      });
    let n = e.r(93046),
      a = e.r(4388),
      o = e.r(89260),
      i = e.r(80883);
    function s({ Component: t, slots: r, serverProvidedParams: s }) {
      let c;
      if (null !== s) c = s.params;
      else {
        let e = (0, i.use)(o.LayoutRouterContext);
        c = null !== e ? e.parentParams : {};
      }
      if ("undefined" == typeof window) {
        let o,
          { workAsyncStorage: i } = e.r(85047),
          s = i.getStore();
        if (!s)
          throw Object.defineProperty(
            new a.InvariantError(
              "Expected workStore to exist when handling params in a client segment such as a Layout or Template."
            ),
            "__NEXT_ERROR_CODE",
            { value: "E600", enumerable: !1, configurable: !0 }
          );
        let { createParamsFromClient: u } = e.r(63935);
        return (o = u(c, s)), (0, n.jsx)(t, { ...r, params: o });
      }
      {
        let { createRenderParamsFromClient: a } = e.r(10708),
          o = a(c);
        return (0, n.jsx)(t, { ...r, params: o });
      }
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  24859,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "IconMark", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    let n = e.r(93046),
      a = () =>
        "undefined" != typeof window
          ? null
          : (0, n.jsx)("meta", { name: "«nxt-icon»" });
  },
]);
