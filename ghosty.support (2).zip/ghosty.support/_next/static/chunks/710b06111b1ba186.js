(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  4478,
  (e) => {
    "use strict";
    let t;
    var n,
      r,
      o,
      a,
      i,
      s,
      l,
      c,
      u = e.i(93046),
      d = e.i(80883),
      f = e.i(61021),
      p = e.i(84675),
      m = e.i(10965);
    let h = (0, m.default)("Target", [
        ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
        ["circle", { cx: "12", cy: "12", r: "6", key: "1vlfrh" }],
        ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }],
      ]),
      v = (0, m.default)("Gamepad2", [
        ["line", { x1: "6", x2: "10", y1: "11", y2: "11", key: "1gktln" }],
        ["line", { x1: "8", x2: "8", y1: "9", y2: "13", key: "qnk9ow" }],
        ["line", { x1: "15", x2: "15.01", y1: "12", y2: "12", key: "krot7o" }],
        ["line", { x1: "18", x2: "18.01", y1: "10", y2: "10", key: "1lcuu1" }],
        [
          "path",
          {
            d: "M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",
            key: "mfqc10",
          },
        ],
      ]),
      g = (0, m.default)("CircleHelp", [
        ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
        ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
        ["path", { d: "M12 17h.01", key: "p32p05" }],
      ]);
    var y = e.i(67881);
    function x(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
      return function (r) {
        if ((e?.(r), !1 === n || !r.defaultPrevented)) return t?.(r);
      };
    }
    var b = e.i(21991),
      w = e.i(13942),
      E = globalThis?.document ? d.useLayoutEffect : () => {},
      N = d["useId".toString()] || (() => void 0),
      j = 0;
    function C(e) {
      let [t, n] = d.useState(N());
      return (
        E(() => {
          e || n((e) => e ?? String(j++));
        }, [e]),
        e || (t ? `radix-${t}` : "")
      );
    }
    function k(e) {
      let t = d.useRef(e);
      return (
        d.useEffect(() => {
          t.current = e;
        }),
        d.useMemo(
          () =>
            (...e) =>
              t.current?.(...e),
          []
        )
      );
    }
    var R = e.i(4786),
      S = "dismissableLayer.update",
      P = d.createContext({
        layers: new Set(),
        layersWithOutsidePointerEventsDisabled: new Set(),
        branches: new Set(),
      }),
      O = d.forwardRef((e, t) => {
        let {
            disableOutsidePointerEvents: n = !1,
            onEscapeKeyDown: r,
            onPointerDownOutside: o,
            onFocusOutside: a,
            onInteractOutside: i,
            onDismiss: s,
            ...c
          } = e,
          f = d.useContext(P),
          [p, m] = d.useState(null),
          h = p?.ownerDocument ?? globalThis?.document,
          [, v] = d.useState({}),
          g = (0, b.useComposedRefs)(t, (e) => m(e)),
          y = Array.from(f.layers),
          [w] = [...f.layersWithOutsidePointerEventsDisabled].slice(-1),
          E = y.indexOf(w),
          N = p ? y.indexOf(p) : -1,
          j = f.layersWithOutsidePointerEventsDisabled.size > 0,
          C = N >= E,
          O = (function (e, t = globalThis?.document) {
            let n = k(e),
              r = d.useRef(!1),
              o = d.useRef(() => {});
            return (
              d.useEffect(() => {
                let e = (e) => {
                    if (e.target && !r.current) {
                      let r = function () {
                          D("dismissableLayer.pointerDownOutside", n, a, {
                            discrete: !0,
                          });
                        },
                        a = { originalEvent: e };
                      "touch" === e.pointerType
                        ? (t.removeEventListener("click", o.current),
                          (o.current = r),
                          t.addEventListener("click", o.current, { once: !0 }))
                        : r();
                    } else t.removeEventListener("click", o.current);
                    r.current = !1;
                  },
                  a = window.setTimeout(() => {
                    t.addEventListener("pointerdown", e);
                  }, 0);
                return () => {
                  window.clearTimeout(a),
                    t.removeEventListener("pointerdown", e),
                    t.removeEventListener("click", o.current);
                };
              }, [t, n]),
              { onPointerDownCapture: () => (r.current = !0) }
            );
          })((e) => {
            let t = e.target,
              n = [...f.branches].some((e) => e.contains(t));
            C && !n && (o?.(e), i?.(e), e.defaultPrevented || s?.());
          }, h),
          A = (function (e, t = globalThis?.document) {
            let n = k(e),
              r = d.useRef(!1);
            return (
              d.useEffect(() => {
                let e = (e) => {
                  e.target &&
                    !r.current &&
                    D(
                      "dismissableLayer.focusOutside",
                      n,
                      { originalEvent: e },
                      { discrete: !1 }
                    );
                };
                return (
                  t.addEventListener("focusin", e),
                  () => t.removeEventListener("focusin", e)
                );
              }, [t, n]),
              {
                onFocusCapture: () => (r.current = !0),
                onBlurCapture: () => (r.current = !1),
              }
            );
          })((e) => {
            let t = e.target;
            ![...f.branches].some((e) => e.contains(t)) &&
              (a?.(e), i?.(e), e.defaultPrevented || s?.());
          }, h);
        return (
          !(function (e, t = globalThis?.document) {
            let n = k(e);
            d.useEffect(() => {
              let e = (e) => {
                "Escape" === e.key && n(e);
              };
              return (
                t.addEventListener("keydown", e, { capture: !0 }),
                () => t.removeEventListener("keydown", e, { capture: !0 })
              );
            }, [n, t]);
          })((e) => {
            N === f.layers.size - 1 &&
              (r?.(e), !e.defaultPrevented && s && (e.preventDefault(), s()));
          }, h),
          d.useEffect(() => {
            if (p)
              return (
                n &&
                  (0 === f.layersWithOutsidePointerEventsDisabled.size &&
                    ((l = h.body.style.pointerEvents),
                    (h.body.style.pointerEvents = "none")),
                  f.layersWithOutsidePointerEventsDisabled.add(p)),
                f.layers.add(p),
                T(),
                () => {
                  n &&
                    1 === f.layersWithOutsidePointerEventsDisabled.size &&
                    (h.body.style.pointerEvents = l);
                }
              );
          }, [p, h, n, f]),
          d.useEffect(
            () => () => {
              p &&
                (f.layers.delete(p),
                f.layersWithOutsidePointerEventsDisabled.delete(p),
                T());
            },
            [p, f]
          ),
          d.useEffect(() => {
            let e = () => v({});
            return (
              document.addEventListener(S, e),
              () => document.removeEventListener(S, e)
            );
          }, []),
          (0, u.jsx)(R.Primitive.div, {
            ...c,
            ref: g,
            style: {
              pointerEvents: j ? (C ? "auto" : "none") : void 0,
              ...e.style,
            },
            onFocusCapture: x(e.onFocusCapture, A.onFocusCapture),
            onBlurCapture: x(e.onBlurCapture, A.onBlurCapture),
            onPointerDownCapture: x(
              e.onPointerDownCapture,
              O.onPointerDownCapture
            ),
          })
        );
      });
    function T() {
      let e = new CustomEvent(S);
      document.dispatchEvent(e);
    }
    function D(e, t, n, { discrete: r }) {
      let o = n.originalEvent.target,
        a = new CustomEvent(e, { bubbles: !1, cancelable: !0, detail: n });
      t && o.addEventListener(e, t, { once: !0 }),
        r ? (0, R.dispatchDiscreteCustomEvent)(o, a) : o.dispatchEvent(a);
    }
    (O.displayName = "DismissableLayer"),
      (d.forwardRef((e, t) => {
        let n = d.useContext(P),
          r = d.useRef(null),
          o = (0, b.useComposedRefs)(t, r);
        return (
          d.useEffect(() => {
            let e = r.current;
            if (e)
              return (
                n.branches.add(e),
                () => {
                  n.branches.delete(e);
                }
              );
          }, [n.branches]),
          (0, u.jsx)(R.Primitive.div, { ...e, ref: o })
        );
      }).displayName = "DismissableLayerBranch");
    var A = "focusScope.autoFocusOnMount",
      M = "focusScope.autoFocusOnUnmount",
      L = { bubbles: !1, cancelable: !0 },
      I = d.forwardRef((e, t) => {
        let {
            loop: n = !1,
            trapped: r = !1,
            onMountAutoFocus: o,
            onUnmountAutoFocus: a,
            ...i
          } = e,
          [s, l] = d.useState(null),
          c = k(o),
          f = k(a),
          p = d.useRef(null),
          m = (0, b.useComposedRefs)(t, (e) => l(e)),
          h = d.useRef({
            paused: !1,
            pause() {
              this.paused = !0;
            },
            resume() {
              this.paused = !1;
            },
          }).current;
        d.useEffect(() => {
          if (r) {
            let e = function (e) {
                if (h.paused || !s) return;
                let t = e.target;
                s.contains(t) ? (p.current = t) : W(p.current, { select: !0 });
              },
              t = function (e) {
                if (h.paused || !s) return;
                let t = e.relatedTarget;
                null !== t && (s.contains(t) || W(p.current, { select: !0 }));
              };
            document.addEventListener("focusin", e),
              document.addEventListener("focusout", t);
            let n = new MutationObserver(function (e) {
              if (document.activeElement === document.body)
                for (let t of e) t.removedNodes.length > 0 && W(s);
            });
            return (
              s && n.observe(s, { childList: !0, subtree: !0 }),
              () => {
                document.removeEventListener("focusin", e),
                  document.removeEventListener("focusout", t),
                  n.disconnect();
              }
            );
          }
        }, [r, s, h.paused]),
          d.useEffect(() => {
            if (s) {
              B.add(h);
              let e = document.activeElement;
              if (!s.contains(e)) {
                let t = new CustomEvent(A, L);
                s.addEventListener(A, c),
                  s.dispatchEvent(t),
                  t.defaultPrevented ||
                    ((function (e, { select: t = !1 } = {}) {
                      let n = document.activeElement;
                      for (let r of e)
                        if ((W(r, { select: t }), document.activeElement !== n))
                          return;
                    })(
                      F(s).filter((e) => "A" !== e.tagName),
                      { select: !0 }
                    ),
                    document.activeElement === e && W(s));
              }
              return () => {
                s.removeEventListener(A, c),
                  setTimeout(() => {
                    let t = new CustomEvent(M, L);
                    s.addEventListener(M, f),
                      s.dispatchEvent(t),
                      t.defaultPrevented ||
                        W(e ?? document.body, { select: !0 }),
                      s.removeEventListener(M, f),
                      B.remove(h);
                  }, 0);
              };
            }
          }, [s, c, f, h]);
        let v = d.useCallback(
          (e) => {
            if ((!n && !r) || h.paused) return;
            let t = "Tab" === e.key && !e.altKey && !e.ctrlKey && !e.metaKey,
              o = document.activeElement;
            if (t && o) {
              var a;
              let t,
                r = e.currentTarget,
                [i, s] = [_((t = F((a = r))), a), _(t.reverse(), a)];
              i && s
                ? e.shiftKey || o !== s
                  ? e.shiftKey &&
                    o === i &&
                    (e.preventDefault(), n && W(s, { select: !0 }))
                  : (e.preventDefault(), n && W(i, { select: !0 }))
                : o === r && e.preventDefault();
            }
          },
          [n, r, h.paused]
        );
        return (0, u.jsx)(R.Primitive.div, {
          tabIndex: -1,
          ...i,
          ref: m,
          onKeyDown: v,
        });
      });
    function F(e) {
      let t = [],
        n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
          acceptNode: (e) => {
            let t = "INPUT" === e.tagName && "hidden" === e.type;
            return e.disabled || e.hidden || t
              ? NodeFilter.FILTER_SKIP
              : e.tabIndex >= 0
              ? NodeFilter.FILTER_ACCEPT
              : NodeFilter.FILTER_SKIP;
          },
        });
      for (; n.nextNode(); ) t.push(n.currentNode);
      return t;
    }
    function _(e, t) {
      for (let n of e)
        if (
          !(function (e, { upTo: t }) {
            if ("hidden" === getComputedStyle(e).visibility) return !0;
            for (; e && (void 0 === t || e !== t); ) {
              if ("none" === getComputedStyle(e).display) return !0;
              e = e.parentElement;
            }
            return !1;
          })(n, { upTo: t })
        )
          return n;
    }
    function W(e, { select: t = !1 } = {}) {
      if (e && e.focus) {
        var n;
        let r = document.activeElement;
        e.focus({ preventScroll: !0 }),
          e !== r &&
            (n = e) instanceof HTMLInputElement &&
            "select" in n &&
            t &&
            e.select();
      }
    }
    I.displayName = "FocusScope";
    var B =
      ((t = []),
      {
        add(e) {
          let n = t[0];
          e !== n && n?.pause(), (t = U(t, e)).unshift(e);
        },
        remove(e) {
          (t = U(t, e)), t[0]?.resume();
        },
      });
    function U(e, t) {
      let n = [...e],
        r = n.indexOf(t);
      return -1 !== r && n.splice(r, 1), n;
    }
    var z = e.i(36425),
      H = d.forwardRef((e, t) => {
        let { container: n, ...r } = e,
          [o, a] = d.useState(!1);
        E(() => a(!0), []);
        let i = n || (o && globalThis?.document?.body);
        return i
          ? z.default.createPortal(
              (0, u.jsx)(R.Primitive.div, { ...r, ref: t }),
              i
            )
          : null;
      });
    H.displayName = "Portal";
    var K = (e) => {
      var t;
      let n,
        r,
        { present: o, children: a } = e,
        i = (function (e) {
          var t, n;
          let [r, o] = d.useState(),
            a = d.useRef({}),
            i = d.useRef(e),
            s = d.useRef("none"),
            [l, c] =
              ((t = e ? "mounted" : "unmounted"),
              (n = {
                mounted: {
                  UNMOUNT: "unmounted",
                  ANIMATION_OUT: "unmountSuspended",
                },
                unmountSuspended: {
                  MOUNT: "mounted",
                  ANIMATION_END: "unmounted",
                },
                unmounted: { MOUNT: "mounted" },
              }),
              d.useReducer((e, t) => n[e][t] ?? e, t));
          return (
            d.useEffect(() => {
              let e = X(a.current);
              s.current = "mounted" === l ? e : "none";
            }, [l]),
            E(() => {
              let t = a.current,
                n = i.current;
              if (n !== e) {
                let r = s.current,
                  o = X(t);
                e
                  ? c("MOUNT")
                  : "none" === o || t?.display === "none"
                  ? c("UNMOUNT")
                  : n && r !== o
                  ? c("ANIMATION_OUT")
                  : c("UNMOUNT"),
                  (i.current = e);
              }
            }, [e, c]),
            E(() => {
              if (r) {
                let e,
                  t = r.ownerDocument.defaultView ?? window,
                  n = (n) => {
                    let o = X(a.current).includes(n.animationName);
                    if (
                      n.target === r &&
                      o &&
                      (c("ANIMATION_END"), !i.current)
                    ) {
                      let n = r.style.animationFillMode;
                      (r.style.animationFillMode = "forwards"),
                        (e = t.setTimeout(() => {
                          "forwards" === r.style.animationFillMode &&
                            (r.style.animationFillMode = n);
                        }));
                    }
                  },
                  o = (e) => {
                    e.target === r && (s.current = X(a.current));
                  };
                return (
                  r.addEventListener("animationstart", o),
                  r.addEventListener("animationcancel", n),
                  r.addEventListener("animationend", n),
                  () => {
                    t.clearTimeout(e),
                      r.removeEventListener("animationstart", o),
                      r.removeEventListener("animationcancel", n),
                      r.removeEventListener("animationend", n);
                  }
                );
              }
              c("ANIMATION_END");
            }, [r, c]),
            {
              isPresent: ["mounted", "unmountSuspended"].includes(l),
              ref: d.useCallback((e) => {
                e && (a.current = getComputedStyle(e)), o(e);
              }, []),
            }
          );
        })(o),
        s =
          "function" == typeof a
            ? a({ present: i.isPresent })
            : d.Children.only(a),
        l = (0, b.useComposedRefs)(
          i.ref,
          ((t = s),
          (r =
            (n = Object.getOwnPropertyDescriptor(t.props, "ref")?.get) &&
            "isReactWarning" in n &&
            n.isReactWarning)
            ? t.ref
            : (r =
                (n = Object.getOwnPropertyDescriptor(t, "ref")?.get) &&
                "isReactWarning" in n &&
                n.isReactWarning)
            ? t.props.ref
            : t.props.ref || t.ref)
        );
      return "function" == typeof a || i.isPresent
        ? d.cloneElement(s, { ref: l })
        : null;
    };
    function X(e) {
      return e?.animationName || "none";
    }
    K.displayName = "Presence";
    var Y = 0;
    function q() {
      let e = document.createElement("span");
      return (
        e.setAttribute("data-radix-focus-guard", ""),
        (e.tabIndex = 0),
        (e.style.outline = "none"),
        (e.style.opacity = "0"),
        (e.style.position = "fixed"),
        (e.style.pointerEvents = "none"),
        e
      );
    }
    var V = function () {
      return (V =
        Object.assign ||
        function (e) {
          for (var t, n = 1, r = arguments.length; n < r; n++)
            for (var o in (t = arguments[n]))
              Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
          return e;
        }).apply(this, arguments);
    };
    function $(e, t) {
      var n = {};
      for (var r in e)
        Object.prototype.hasOwnProperty.call(e, r) &&
          0 > t.indexOf(r) &&
          (n[r] = e[r]);
      if (null != e && "function" == typeof Object.getOwnPropertySymbols)
        for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++)
          0 > t.indexOf(r[o]) &&
            Object.prototype.propertyIsEnumerable.call(e, r[o]) &&
            (n[r[o]] = e[r[o]]);
      return n;
    }
    var G =
        ("function" == typeof SuppressedError && SuppressedError,
        "right-scroll-bar-position"),
      Z = "width-before-scroll-bar";
    function Q(e, t) {
      return "function" == typeof e ? e(t) : e && (e.current = t), e;
    }
    var J = "undefined" != typeof window ? d.useLayoutEffect : d.useEffect,
      ee = new WeakMap(),
      et =
        (void 0 === n && (n = {}),
        ((void 0 === r &&
          (r = function (e) {
            return e;
          }),
        (o = []),
        (a = !1),
        (i = {
          read: function () {
            if (a)
              throw Error(
                "Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`."
              );
            return o.length ? o[o.length - 1] : null;
          },
          useMedium: function (e) {
            var t = r(e, a);
            return (
              o.push(t),
              function () {
                o = o.filter(function (e) {
                  return e !== t;
                });
              }
            );
          },
          assignSyncMedium: function (e) {
            for (a = !0; o.length; ) {
              var t = o;
              (o = []), t.forEach(e);
            }
            o = {
              push: function (t) {
                return e(t);
              },
              filter: function () {
                return o;
              },
            };
          },
          assignMedium: function (e) {
            a = !0;
            var t = [];
            if (o.length) {
              var n = o;
              (o = []), n.forEach(e), (t = o);
            }
            var r = function () {
                var n = t;
                (t = []), n.forEach(e);
              },
              i = function () {
                return Promise.resolve().then(r);
              };
            i(),
              (o = {
                push: function (e) {
                  t.push(e), i();
                },
                filter: function (e) {
                  return (t = t.filter(e)), o;
                },
              });
          },
        })).options = V({ async: !0, ssr: !1 }, n)),
        i),
      en = function () {},
      er = d.forwardRef(function (e, t) {
        var n,
          r,
          o,
          a,
          i = d.useRef(null),
          s = d.useState({
            onScrollCapture: en,
            onWheelCapture: en,
            onTouchMoveCapture: en,
          }),
          l = s[0],
          c = s[1],
          u = e.forwardProps,
          f = e.children,
          p = e.className,
          m = e.removeScrollBar,
          h = e.enabled,
          v = e.shards,
          g = e.sideCar,
          y = e.noRelative,
          x = e.noIsolation,
          b = e.inert,
          w = e.allowPinchZoom,
          E = e.as,
          N = e.gapMode,
          j = $(e, [
            "forwardProps",
            "children",
            "className",
            "removeScrollBar",
            "enabled",
            "shards",
            "sideCar",
            "noRelative",
            "noIsolation",
            "inert",
            "allowPinchZoom",
            "as",
            "gapMode",
          ]),
          C =
            ((n = [i, t]),
            (r = function (e) {
              return n.forEach(function (t) {
                return Q(t, e);
              });
            }),
            ((o = (0, d.useState)(function () {
              return {
                value: null,
                callback: r,
                facade: {
                  get current() {
                    return o.value;
                  },
                  set current(value) {
                    var e = o.value;
                    e !== value && ((o.value = value), o.callback(value, e));
                  },
                },
              };
            })[0]).callback = r),
            (a = o.facade),
            J(
              function () {
                var e = ee.get(a);
                if (e) {
                  var t = new Set(e),
                    r = new Set(n),
                    o = a.current;
                  t.forEach(function (e) {
                    r.has(e) || Q(e, null);
                  }),
                    r.forEach(function (e) {
                      t.has(e) || Q(e, o);
                    });
                }
                ee.set(a, n);
              },
              [n]
            ),
            a),
          k = V(V({}, j), l);
        return d.createElement(
          d.Fragment,
          null,
          h &&
            d.createElement(g, {
              sideCar: et,
              removeScrollBar: m,
              shards: v,
              noRelative: y,
              noIsolation: x,
              inert: b,
              setCallbacks: c,
              allowPinchZoom: !!w,
              lockRef: i,
              gapMode: N,
            }),
          u
            ? d.cloneElement(d.Children.only(f), V(V({}, k), { ref: C }))
            : d.createElement(
                void 0 === E ? "div" : E,
                V({}, k, { className: p, ref: C }),
                f
              )
        );
      });
    (er.defaultProps = { enabled: !0, removeScrollBar: !0, inert: !1 }),
      (er.classNames = { fullWidth: Z, zeroRight: G });
    var eo = function (e) {
      var t = e.sideCar,
        n = $(e, ["sideCar"]);
      if (!t)
        throw Error(
          "Sidecar: please provide `sideCar` property to import the right car"
        );
      var r = t.read();
      if (!r) throw Error("Sidecar medium not found");
      return d.createElement(r, V({}, n));
    };
    eo.isSideCarExport = !0;
    var ea = function () {
        var e = 0,
          t = null;
        return {
          add: function (n) {
            if (
              0 == e &&
              (t = (function () {
                if (!document) return null;
                var e = document.createElement("style");
                e.type = "text/css";
                var t =
                  c ||
                  ("undefined" != typeof __webpack_nonce__
                    ? __webpack_nonce__
                    : void 0);
                return t && e.setAttribute("nonce", t), e;
              })())
            ) {
              var r, o;
              (r = t).styleSheet
                ? (r.styleSheet.cssText = n)
                : r.appendChild(document.createTextNode(n)),
                (o = t),
                (
                  document.head || document.getElementsByTagName("head")[0]
                ).appendChild(o);
            }
            e++;
          },
          remove: function () {
            --e ||
              !t ||
              (t.parentNode && t.parentNode.removeChild(t), (t = null));
          },
        };
      },
      ei = function () {
        var e = ea();
        return function (t, n) {
          d.useEffect(
            function () {
              return (
                e.add(t),
                function () {
                  e.remove();
                }
              );
            },
            [t && n]
          );
        };
      },
      es = function () {
        var e = ei();
        return function (t) {
          return e(t.styles, t.dynamic), null;
        };
      },
      el = { left: 0, top: 0, right: 0, gap: 0 },
      ec = function (e) {
        return parseInt(e || "", 10) || 0;
      },
      eu = function (e) {
        var t = window.getComputedStyle(document.body),
          n = t["padding" === e ? "paddingLeft" : "marginLeft"],
          r = t["padding" === e ? "paddingTop" : "marginTop"],
          o = t["padding" === e ? "paddingRight" : "marginRight"];
        return [ec(n), ec(r), ec(o)];
      },
      ed = function (e) {
        if ((void 0 === e && (e = "margin"), "undefined" == typeof window))
          return el;
        var t = eu(e),
          n = document.documentElement.clientWidth,
          r = window.innerWidth;
        return {
          left: t[0],
          top: t[1],
          right: t[2],
          gap: Math.max(0, r - n + t[2] - t[0]),
        };
      },
      ef = es(),
      ep = "data-scroll-locked",
      em = function (e, t, n, r) {
        var o = e.left,
          a = e.top,
          i = e.right,
          s = e.gap;
        return (
          void 0 === n && (n = "margin"),
          "\n  ."
            .concat("with-scroll-bars-hidden", " {\n   overflow: hidden ")
            .concat(r, ";\n   padding-right: ")
            .concat(s, "px ")
            .concat(r, ";\n  }\n  body[")
            .concat(ep, "] {\n    overflow: hidden ")
            .concat(r, ";\n    overscroll-behavior: contain;\n    ")
            .concat(
              [
                t && "position: relative ".concat(r, ";"),
                "margin" === n &&
                  "\n    padding-left: "
                    .concat(o, "px;\n    padding-top: ")
                    .concat(a, "px;\n    padding-right: ")
                    .concat(
                      i,
                      "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: "
                    )
                    .concat(s, "px ")
                    .concat(r, ";\n    "),
                "padding" === n &&
                  "padding-right: ".concat(s, "px ").concat(r, ";"),
              ]
                .filter(Boolean)
                .join(""),
              "\n  }\n  \n  ."
            )
            .concat(G, " {\n    right: ")
            .concat(s, "px ")
            .concat(r, ";\n  }\n  \n  .")
            .concat(Z, " {\n    margin-right: ")
            .concat(s, "px ")
            .concat(r, ";\n  }\n  \n  .")
            .concat(G, " .")
            .concat(G, " {\n    right: 0 ")
            .concat(r, ";\n  }\n  \n  .")
            .concat(Z, " .")
            .concat(Z, " {\n    margin-right: 0 ")
            .concat(r, ";\n  }\n  \n  body[")
            .concat(ep, "] {\n    ")
            .concat("--removed-body-scroll-bar-size", ": ")
            .concat(s, "px;\n  }\n")
        );
      },
      eh = function () {
        var e = parseInt(document.body.getAttribute(ep) || "0", 10);
        return isFinite(e) ? e : 0;
      },
      ev = function () {
        d.useEffect(function () {
          return (
            document.body.setAttribute(ep, (eh() + 1).toString()),
            function () {
              var e = eh() - 1;
              e <= 0
                ? document.body.removeAttribute(ep)
                : document.body.setAttribute(ep, e.toString());
            }
          );
        }, []);
      },
      eg = function (e) {
        var t = e.noRelative,
          n = e.noImportant,
          r = e.gapMode,
          o = void 0 === r ? "margin" : r;
        ev();
        var a = d.useMemo(
          function () {
            return ed(o);
          },
          [o]
        );
        return d.createElement(ef, {
          styles: em(a, !t, o, n ? "" : "!important"),
        });
      },
      ey = !1;
    if ("undefined" != typeof window)
      try {
        var ex = Object.defineProperty({}, "passive", {
          get: function () {
            return (ey = !0), !0;
          },
        });
        window.addEventListener("test", ex, ex),
          window.removeEventListener("test", ex, ex);
      } catch (e) {
        ey = !1;
      }
    var eb = !!ey && { passive: !1 },
      ew = function (e, t) {
        if (!(e instanceof Element)) return !1;
        var n = window.getComputedStyle(e);
        return (
          "hidden" !== n[t] &&
          (n.overflowY !== n.overflowX ||
            "TEXTAREA" === e.tagName ||
            "visible" !== n[t])
        );
      },
      eE = function (e, t) {
        var n = t.ownerDocument,
          r = t;
        do {
          if (
            ("undefined" != typeof ShadowRoot &&
              r instanceof ShadowRoot &&
              (r = r.host),
            eN(e, r))
          ) {
            var o = ej(e, r);
            if (o[1] > o[2]) return !0;
          }
          r = r.parentNode;
        } while (r && r !== n.body);
        return !1;
      },
      eN = function (e, t) {
        return "v" === e ? ew(t, "overflowY") : ew(t, "overflowX");
      },
      ej = function (e, t) {
        return "v" === e
          ? [t.scrollTop, t.scrollHeight, t.clientHeight]
          : [t.scrollLeft, t.scrollWidth, t.clientWidth];
      },
      eC = function (e, t, n, r, o) {
        var a,
          i =
            ((a = window.getComputedStyle(t).direction),
            "h" === e && "rtl" === a ? -1 : 1),
          s = i * r,
          l = n.target,
          c = t.contains(l),
          u = !1,
          d = s > 0,
          f = 0,
          p = 0;
        do {
          if (!l) break;
          var m = ej(e, l),
            h = m[0],
            v = m[1] - m[2] - i * h;
          (h || v) && eN(e, l) && ((f += v), (p += h));
          var g = l.parentNode;
          l = g && g.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? g.host : g;
        } while (
          (!c && l !== document.body) ||
          (c && (t.contains(l) || t === l))
        );
        return (
          d && ((o && 1 > Math.abs(f)) || (!o && s > f))
            ? (u = !0)
            : !d && ((o && 1 > Math.abs(p)) || (!o && -s > p)) && (u = !0),
          u
        );
      },
      ek = function (e) {
        return "changedTouches" in e
          ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY]
          : [0, 0];
      },
      eR = function (e) {
        return [e.deltaX, e.deltaY];
      },
      eS = function (e) {
        return e && "current" in e ? e.current : e;
      },
      eP = 0,
      eO = [];
    let eT =
      ((s = function (e) {
        var t = d.useRef([]),
          n = d.useRef([0, 0]),
          r = d.useRef(),
          o = d.useState(eP++)[0],
          a = d.useState(es)[0],
          i = d.useRef(e);
        d.useEffect(
          function () {
            i.current = e;
          },
          [e]
        ),
          d.useEffect(
            function () {
              if (e.inert) {
                document.body.classList.add("block-interactivity-".concat(o));
                var t = (function (e, t, n) {
                  if (n || 2 == arguments.length)
                    for (var r, o = 0, a = t.length; o < a; o++)
                      (!r && o in t) ||
                        (r || (r = Array.prototype.slice.call(t, 0, o)),
                        (r[o] = t[o]));
                  return e.concat(r || Array.prototype.slice.call(t));
                })([e.lockRef.current], (e.shards || []).map(eS), !0).filter(
                  Boolean
                );
                return (
                  t.forEach(function (e) {
                    return e.classList.add("allow-interactivity-".concat(o));
                  }),
                  function () {
                    document.body.classList.remove(
                      "block-interactivity-".concat(o)
                    ),
                      t.forEach(function (e) {
                        return e.classList.remove(
                          "allow-interactivity-".concat(o)
                        );
                      });
                  }
                );
              }
            },
            [e.inert, e.lockRef.current, e.shards]
          );
        var s = d.useCallback(function (e, t) {
            if (
              ("touches" in e && 2 === e.touches.length) ||
              ("wheel" === e.type && e.ctrlKey)
            )
              return !i.current.allowPinchZoom;
            var o,
              a = ek(e),
              s = n.current,
              l = "deltaX" in e ? e.deltaX : s[0] - a[0],
              c = "deltaY" in e ? e.deltaY : s[1] - a[1],
              u = e.target,
              d = Math.abs(l) > Math.abs(c) ? "h" : "v";
            if ("touches" in e && "h" === d && "range" === u.type) return !1;
            var f = window.getSelection(),
              p = f && f.anchorNode;
            if (p && (p === u || p.contains(u))) return !1;
            var m = eE(d, u);
            if (!m) return !0;
            if (
              (m ? (o = d) : ((o = "v" === d ? "h" : "v"), (m = eE(d, u))), !m)
            )
              return !1;
            if (
              (!r.current &&
                "changedTouches" in e &&
                (l || c) &&
                (r.current = o),
              !o)
            )
              return !0;
            var h = r.current || o;
            return eC(h, t, e, "h" === h ? l : c, !0);
          }, []),
          l = d.useCallback(function (e) {
            if (eO.length && eO[eO.length - 1] === a) {
              var n = "deltaY" in e ? eR(e) : ek(e),
                r = t.current.filter(function (t) {
                  var r;
                  return (
                    t.name === e.type &&
                    (t.target === e.target || e.target === t.shadowParent) &&
                    ((r = t.delta), r[0] === n[0] && r[1] === n[1])
                  );
                })[0];
              if (r && r.should) {
                e.cancelable && e.preventDefault();
                return;
              }
              if (!r) {
                var o = (i.current.shards || [])
                  .map(eS)
                  .filter(Boolean)
                  .filter(function (t) {
                    return t.contains(e.target);
                  });
                (o.length > 0 ? s(e, o[0]) : !i.current.noIsolation) &&
                  e.cancelable &&
                  e.preventDefault();
              }
            }
          }, []),
          c = d.useCallback(function (e, n, r, o) {
            var a = {
              name: e,
              delta: n,
              target: r,
              should: o,
              shadowParent: (function (e) {
                for (var t = null; null !== e; )
                  e instanceof ShadowRoot && ((t = e.host), (e = e.host)),
                    (e = e.parentNode);
                return t;
              })(r),
            };
            t.current.push(a),
              setTimeout(function () {
                t.current = t.current.filter(function (e) {
                  return e !== a;
                });
              }, 1);
          }, []),
          u = d.useCallback(function (e) {
            (n.current = ek(e)), (r.current = void 0);
          }, []),
          f = d.useCallback(function (t) {
            c(t.type, eR(t), t.target, s(t, e.lockRef.current));
          }, []),
          p = d.useCallback(function (t) {
            c(t.type, ek(t), t.target, s(t, e.lockRef.current));
          }, []);
        d.useEffect(function () {
          return (
            eO.push(a),
            e.setCallbacks({
              onScrollCapture: f,
              onWheelCapture: f,
              onTouchMoveCapture: p,
            }),
            document.addEventListener("wheel", l, eb),
            document.addEventListener("touchmove", l, eb),
            document.addEventListener("touchstart", u, eb),
            function () {
              (eO = eO.filter(function (e) {
                return e !== a;
              })),
                document.removeEventListener("wheel", l, eb),
                document.removeEventListener("touchmove", l, eb),
                document.removeEventListener("touchstart", u, eb);
            }
          );
        }, []);
        var m = e.removeScrollBar,
          h = e.inert;
        return d.createElement(
          d.Fragment,
          null,
          h
            ? d.createElement(a, {
                styles: "\n  .block-interactivity-"
                  .concat(
                    o,
                    " {pointer-events: none;}\n  .allow-interactivity-"
                  )
                  .concat(o, " {pointer-events: all;}\n"),
              })
            : null,
          m
            ? d.createElement(eg, {
                noRelative: e.noRelative,
                gapMode: e.gapMode,
              })
            : null
        );
      }),
      et.useMedium(s),
      eo);
    var eD = d.forwardRef(function (e, t) {
      return d.createElement(er, V({}, e, { ref: t, sideCar: eT }));
    });
    eD.classNames = er.classNames;
    var eA = new WeakMap(),
      eM = new WeakMap(),
      eL = {},
      eI = 0,
      eF = function (e) {
        return e && (e.host || eF(e.parentNode));
      },
      e_ = function (e, t, n, r) {
        var o = (Array.isArray(e) ? e : [e])
          .map(function (e) {
            if (t.contains(e)) return e;
            var n = eF(e);
            return n && t.contains(n)
              ? n
              : (console.error(
                  "aria-hidden",
                  e,
                  "in not contained inside",
                  t,
                  ". Doing nothing"
                ),
                null);
          })
          .filter(function (e) {
            return !!e;
          });
        eL[n] || (eL[n] = new WeakMap());
        var a = eL[n],
          i = [],
          s = new Set(),
          l = new Set(o),
          c = function (e) {
            !e || s.has(e) || (s.add(e), c(e.parentNode));
          };
        o.forEach(c);
        var u = function (e) {
          !e ||
            l.has(e) ||
            Array.prototype.forEach.call(e.children, function (e) {
              if (s.has(e)) u(e);
              else
                try {
                  var t = e.getAttribute(r),
                    o = null !== t && "false" !== t,
                    l = (eA.get(e) || 0) + 1,
                    c = (a.get(e) || 0) + 1;
                  eA.set(e, l),
                    a.set(e, c),
                    i.push(e),
                    1 === l && o && eM.set(e, !0),
                    1 === c && e.setAttribute(n, "true"),
                    o || e.setAttribute(r, "true");
                } catch (t) {
                  console.error("aria-hidden: cannot operate on ", e, t);
                }
            });
        };
        return (
          u(t),
          s.clear(),
          eI++,
          function () {
            i.forEach(function (e) {
              var t = eA.get(e) - 1,
                o = a.get(e) - 1;
              eA.set(e, t),
                a.set(e, o),
                t || (eM.has(e) || e.removeAttribute(r), eM.delete(e)),
                o || e.removeAttribute(n);
            }),
              --eI ||
                ((eA = new WeakMap()),
                (eA = new WeakMap()),
                (eM = new WeakMap()),
                (eL = {}));
          }
        );
      },
      eW = function (e, t, n) {
        void 0 === n && (n = "data-aria-hidden");
        var r = Array.from(Array.isArray(e) ? e : [e]),
          o =
            t ||
            ("undefined" == typeof document
              ? null
              : (Array.isArray(e) ? e[0] : e).ownerDocument.body);
        return o
          ? (r.push.apply(
              r,
              Array.from(o.querySelectorAll("[aria-live], script"))
            ),
            e_(r, o, n, "aria-hidden"))
          : function () {
              return null;
            };
      },
      eB = e.i(87576),
      eU = "Dialog",
      [ez, eH] = (0, w.createContextScope)(eU),
      [eK, eX] = ez(eU),
      eY = (e) => {
        let {
            __scopeDialog: t,
            children: n,
            open: r,
            defaultOpen: o,
            onOpenChange: a,
            modal: i = !0,
          } = e,
          s = d.useRef(null),
          l = d.useRef(null),
          [c = !1, f] = (function ({
            prop: e,
            defaultProp: t,
            onChange: n = () => {},
          }) {
            let [r, o] = (function ({ defaultProp: e, onChange: t }) {
                let n = d.useState(e),
                  [r] = n,
                  o = d.useRef(r),
                  a = k(t);
                return (
                  d.useEffect(() => {
                    o.current !== r && (a(r), (o.current = r));
                  }, [r, o, a]),
                  n
                );
              })({ defaultProp: t, onChange: n }),
              a = void 0 !== e,
              i = a ? e : r,
              s = k(n);
            return [
              i,
              d.useCallback(
                (t) => {
                  if (a) {
                    let n = "function" == typeof t ? t(e) : t;
                    n !== e && s(n);
                  } else o(t);
                },
                [a, e, o, s]
              ),
            ];
          })({ prop: r, defaultProp: o, onChange: a });
        return (0, u.jsx)(eK, {
          scope: t,
          triggerRef: s,
          contentRef: l,
          contentId: C(),
          titleId: C(),
          descriptionId: C(),
          open: c,
          onOpenChange: f,
          onOpenToggle: d.useCallback(() => f((e) => !e), [f]),
          modal: i,
          children: n,
        });
      };
    eY.displayName = eU;
    var eq = "DialogTrigger";
    d.forwardRef((e, t) => {
      let { __scopeDialog: n, ...r } = e,
        o = eX(eq, n),
        a = (0, b.useComposedRefs)(t, o.triggerRef);
      return (0, u.jsx)(R.Primitive.button, {
        type: "button",
        "aria-haspopup": "dialog",
        "aria-expanded": o.open,
        "aria-controls": o.contentId,
        "data-state": tn(o.open),
        ...r,
        ref: a,
        onClick: x(e.onClick, o.onOpenToggle),
      });
    }).displayName = eq;
    var eV = "DialogPortal",
      [e$, eG] = ez(eV, { forceMount: void 0 }),
      eZ = (e) => {
        let { __scopeDialog: t, forceMount: n, children: r, container: o } = e,
          a = eX(eV, t);
        return (0, u.jsx)(e$, {
          scope: t,
          forceMount: n,
          children: d.Children.map(r, (e) =>
            (0, u.jsx)(K, {
              present: n || a.open,
              children: (0, u.jsx)(H, {
                asChild: !0,
                container: o,
                children: e,
              }),
            })
          ),
        });
      };
    eZ.displayName = eV;
    var eQ = "DialogOverlay",
      eJ = d.forwardRef((e, t) => {
        let n = eG(eQ, e.__scopeDialog),
          { forceMount: r = n.forceMount, ...o } = e,
          a = eX(eQ, e.__scopeDialog);
        return a.modal
          ? (0, u.jsx)(K, {
              present: r || a.open,
              children: (0, u.jsx)(e0, { ...o, ref: t }),
            })
          : null;
      });
    eJ.displayName = eQ;
    var e0 = d.forwardRef((e, t) => {
        let { __scopeDialog: n, ...r } = e,
          o = eX(eQ, n);
        return (0, u.jsx)(eD, {
          as: eB.Slot,
          allowPinchZoom: !0,
          shards: [o.contentRef],
          children: (0, u.jsx)(R.Primitive.div, {
            "data-state": tn(o.open),
            ...r,
            ref: t,
            style: { pointerEvents: "auto", ...r.style },
          }),
        });
      }),
      e1 = "DialogContent",
      e2 = d.forwardRef((e, t) => {
        let n = eG(e1, e.__scopeDialog),
          { forceMount: r = n.forceMount, ...o } = e,
          a = eX(e1, e.__scopeDialog);
        return (0, u.jsx)(K, {
          present: r || a.open,
          children: a.modal
            ? (0, u.jsx)(e5, { ...o, ref: t })
            : (0, u.jsx)(e4, { ...o, ref: t }),
        });
      });
    e2.displayName = e1;
    var e5 = d.forwardRef((e, t) => {
        let n = eX(e1, e.__scopeDialog),
          r = d.useRef(null),
          o = (0, b.useComposedRefs)(t, n.contentRef, r);
        return (
          d.useEffect(() => {
            let e = r.current;
            if (e) return eW(e);
          }, []),
          (0, u.jsx)(e3, {
            ...e,
            ref: o,
            trapFocus: n.open,
            disableOutsidePointerEvents: !0,
            onCloseAutoFocus: x(e.onCloseAutoFocus, (e) => {
              e.preventDefault(), n.triggerRef.current?.focus();
            }),
            onPointerDownOutside: x(e.onPointerDownOutside, (e) => {
              let t = e.detail.originalEvent,
                n = 0 === t.button && !0 === t.ctrlKey;
              (2 === t.button || n) && e.preventDefault();
            }),
            onFocusOutside: x(e.onFocusOutside, (e) => e.preventDefault()),
          })
        );
      }),
      e4 = d.forwardRef((e, t) => {
        let n = eX(e1, e.__scopeDialog),
          r = d.useRef(!1),
          o = d.useRef(!1);
        return (0, u.jsx)(e3, {
          ...e,
          ref: t,
          trapFocus: !1,
          disableOutsidePointerEvents: !1,
          onCloseAutoFocus: (t) => {
            e.onCloseAutoFocus?.(t),
              t.defaultPrevented ||
                (r.current || n.triggerRef.current?.focus(),
                t.preventDefault()),
              (r.current = !1),
              (o.current = !1);
          },
          onInteractOutside: (t) => {
            e.onInteractOutside?.(t),
              t.defaultPrevented ||
                ((r.current = !0),
                "pointerdown" === t.detail.originalEvent.type &&
                  (o.current = !0));
            let a = t.target;
            n.triggerRef.current?.contains(a) && t.preventDefault(),
              "focusin" === t.detail.originalEvent.type &&
                o.current &&
                t.preventDefault();
          },
        });
      }),
      e3 = d.forwardRef((e, t) => {
        let {
            __scopeDialog: n,
            trapFocus: r,
            onOpenAutoFocus: o,
            onCloseAutoFocus: a,
            ...i
          } = e,
          s = eX(e1, n),
          l = d.useRef(null),
          c = (0, b.useComposedRefs)(t, l);
        return (
          d.useEffect(() => {
            let e = document.querySelectorAll("[data-radix-focus-guard]");
            return (
              document.body.insertAdjacentElement("afterbegin", e[0] ?? q()),
              document.body.insertAdjacentElement("beforeend", e[1] ?? q()),
              Y++,
              () => {
                1 === Y &&
                  document
                    .querySelectorAll("[data-radix-focus-guard]")
                    .forEach((e) => e.remove()),
                  Y--;
              }
            );
          }, []),
          (0, u.jsxs)(u.Fragment, {
            children: [
              (0, u.jsx)(I, {
                asChild: !0,
                loop: !0,
                trapped: r,
                onMountAutoFocus: o,
                onUnmountAutoFocus: a,
                children: (0, u.jsx)(O, {
                  role: "dialog",
                  id: s.contentId,
                  "aria-describedby": s.descriptionId,
                  "aria-labelledby": s.titleId,
                  "data-state": tn(s.open),
                  ...i,
                  ref: c,
                  onDismiss: () => s.onOpenChange(!1),
                }),
              }),
              (0, u.jsxs)(u.Fragment, {
                children: [
                  (0, u.jsx)(ti, { titleId: s.titleId }),
                  (0, u.jsx)(ts, {
                    contentRef: l,
                    descriptionId: s.descriptionId,
                  }),
                ],
              }),
            ],
          })
        );
      }),
      e6 = "DialogTitle",
      e8 = d.forwardRef((e, t) => {
        let { __scopeDialog: n, ...r } = e,
          o = eX(e6, n);
        return (0, u.jsx)(R.Primitive.h2, { id: o.titleId, ...r, ref: t });
      });
    e8.displayName = e6;
    var e7 = "DialogDescription",
      e9 = d.forwardRef((e, t) => {
        let { __scopeDialog: n, ...r } = e,
          o = eX(e7, n);
        return (0, u.jsx)(R.Primitive.p, { id: o.descriptionId, ...r, ref: t });
      });
    e9.displayName = e7;
    var te = "DialogClose",
      tt = d.forwardRef((e, t) => {
        let { __scopeDialog: n, ...r } = e,
          o = eX(te, n);
        return (0, u.jsx)(R.Primitive.button, {
          type: "button",
          ...r,
          ref: t,
          onClick: x(e.onClick, () => o.onOpenChange(!1)),
        });
      });
    function tn(e) {
      return e ? "open" : "closed";
    }
    tt.displayName = te;
    var tr = "DialogTitleWarning",
      [to, ta] = (0, w.createContext)(tr, {
        contentName: e1,
        titleName: e6,
        docsSlug: "dialog",
      }),
      ti = ({ titleId: e }) => {
        let t = ta(tr),
          n = `\`${t.contentName}\` requires a \`${t.titleName}\` for the component to be accessible for screen reader users.

If you want to hide the \`${t.titleName}\`, you can wrap it with our VisuallyHidden component.

For more information, see https://radix-ui.com/primitives/docs/components/${t.docsSlug}`;
        return (
          d.useEffect(() => {
            e && (document.getElementById(e) || console.error(n));
          }, [n, e]),
          null
        );
      },
      ts = ({ contentRef: e, descriptionId: t }) => {
        let n = ta("DialogDescriptionWarning"),
          r = `Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${n.contentName}}.`;
        return (
          d.useEffect(() => {
            let n = e.current?.getAttribute("aria-describedby");
            t && n && (document.getElementById(t) || console.warn(r));
          }, [r, e, t]),
          null
        );
      };
    let tl = (0, m.default)("X", [
      ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
      ["path", { d: "m6 6 12 12", key: "d8bk6v" }],
    ]);
    var tc = e.i(47163);
    function tu({ ...e }) {
      return (0, u.jsx)(eY, { "data-slot": "dialog", ...e });
    }
    function td({ ...e }) {
      return (0, u.jsx)(eZ, { "data-slot": "dialog-portal", ...e });
    }
    function tf({ className: e, ...t }) {
      return (0, u.jsx)(eJ, {
        "data-slot": "dialog-overlay",
        className: (0, tc.cn)(
          "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50",
          e
        ),
        ...t,
      });
    }
    function tp({ className: e, children: t, showCloseButton: n = !0, ...r }) {
      return (0, u.jsxs)(td, {
        "data-slot": "dialog-portal",
        children: [
          (0, u.jsx)(tf, {}),
          (0, u.jsxs)(e2, {
            "data-slot": "dialog-content",
            className: (0, tc.cn)(
              "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg duration-200 sm:max-w-lg",
              e
            ),
            ...r,
            children: [
              t,
              n &&
                (0, u.jsxs)(tt, {
                  "data-slot": "dialog-close",
                  className:
                    "ring-offset-background focus:ring-ring data-[state=open]:bg-accent data-[state=open]:text-muted-foreground absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
                  children: [
                    (0, u.jsx)(tl, {}),
                    (0, u.jsx)("span", {
                      className: "sr-only",
                      children: "Close",
                    }),
                  ],
                }),
            ],
          }),
        ],
      });
    }
    function tm({ className: e, ...t }) {
      return (0, u.jsx)("div", {
        "data-slot": "dialog-header",
        className: (0, tc.cn)(
          "flex flex-col gap-2 text-center sm:text-left",
          e
        ),
        ...t,
      });
    }
    function th({ className: e, ...t }) {
      return (0, u.jsx)("div", {
        "data-slot": "dialog-footer",
        className: (0, tc.cn)(
          "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
          e
        ),
        ...t,
      });
    }
    function tv({ className: e, ...t }) {
      return (0, u.jsx)(e8, {
        "data-slot": "dialog-title",
        className: (0, tc.cn)("text-lg leading-none font-semibold", e),
        ...t,
      });
    }
    function tg({ className: e, ...t }) {
      return (0, u.jsx)(e9, {
        "data-slot": "dialog-description",
        className: (0, tc.cn)("text-muted-foreground text-sm", e),
        ...t,
      });
    }
    function ty() {
      let [e, t] = (0, d.useState)(!0),
        [n, r] = (0, d.useState)(!1);
      return (0, u.jsxs)("div", {
        className: "min-h-screen bg-background",
        children: [
          (0, u.jsx)(tu, {
            open: e,
            onOpenChange: t,
            children: (0, u.jsxs)(tp, {
              className: "sm:max-w-md",
              children: [
                (0, u.jsxs)(tm, {
                  children: [
                    (0, u.jsxs)(tv, {
                      className: "flex items-center gap-2",
                      children: [
                        (0, u.jsx)(g, { className: "h-5 w-5 text-primary" }),
                        "Quick Question",
                      ],
                    }),
                    (0, u.jsx)(tg, {
                      className: "text-base pt-2",
                      children: "Are you using Windows 11?",
                    }),
                  ],
                }),
                (0, u.jsxs)(th, {
                  className: "flex-row gap-2 sm:justify-center",
                  children: [
                    (0, u.jsx)(y.Button, {
                      variant: "outline",
                      onClick: () => {
                        t(!1);
                      },
                      className: "flex-1 bg-transparent",
                      children: "No",
                    }),
                    (0, u.jsx)(y.Button, {
                      onClick: () => {
                        t(!1), r(!0);
                      },
                      className: "flex-1",
                      children: "Yes",
                    }),
                  ],
                }),
              ],
            }),
          }),
          (0, u.jsx)(tu, {
            open: n,
            onOpenChange: r,
            children: (0, u.jsxs)(tp, {
              className: "sm:max-w-lg",
              children: [
                (0, u.jsx)(tm, {
                  children: (0, u.jsxs)(tv, {
                    className: "flex items-center gap-2",
                    children: [
                      (0, u.jsx)(g, { className: "h-5 w-5 text-amber-500" }),
                      "Windows 11",
                    ],
                  }),
                }),
                (0, u.jsxs)("div", {
                  className: "space-y-4 py-4",
                  children: [
                    (0, u.jsx)("p", {
                      className: "text-muted-foreground",
                      children:
                        "Before using any of the products it is preferable to follow the steps below:",
                    }),
                    (0, u.jsxs)("ol", {
                      className: "space-y-3 text-sm",
                      children: [
                        (0, u.jsxs)("li", {
                          className: "flex items-start gap-2",
                          children: [
                            (0, u.jsx)("span", {
                              className: "font-semibold text-primary",
                              children: "1.",
                            }),
                            (0, u.jsxs)("span", {
                              children: [
                                "Go to ",
                                (0, u.jsx)("strong", {
                                  children: "Check For Updates",
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, u.jsxs)("li", {
                          className: "flex items-start gap-2",
                          children: [
                            (0, u.jsx)("span", {
                              className: "font-semibold text-primary",
                              children: "2.",
                            }),
                            (0, u.jsxs)("span", {
                              children: [
                                "Press ",
                                (0, u.jsx)("strong", {
                                  children: "Update History",
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, u.jsxs)("li", {
                          className: "flex items-start gap-2",
                          children: [
                            (0, u.jsx)("span", {
                              className: "font-semibold text-primary",
                              children: "3.",
                            }),
                            (0, u.jsxs)("span", {
                              children: [
                                "Delete all ",
                                (0, u.jsx)("strong", { children: "Updates" }),
                                " that is possible especially the one starting with",
                                " ",
                                (0, u.jsx)("strong", { children: "25H" }),
                                " and the ",
                                (0, u.jsx)("strong", { children: "KB" }),
                                " updates.",
                              ],
                            }),
                          ],
                        }),
                        (0, u.jsxs)("li", {
                          className: "flex items-start gap-2",
                          children: [
                            (0, u.jsx)("span", {
                              className: "font-semibold text-primary",
                              children: "4.",
                            }),
                            (0, u.jsxs)("span", {
                              children: [
                                "After doing that, install Windows Update Blocker (WUB) (",
                                (0, u.jsx)("a", {
                                  href: "https://www.sordum.org/9470/windows-update-blocker-v1-8/",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  className:
                                    "text-primary underline hover:no-underline",
                                  children: "Click Here",
                                }),
                                ")",
                              ],
                            }),
                          ],
                        }),
                        (0, u.jsxs)("li", {
                          className: "flex items-start gap-2",
                          children: [
                            (0, u.jsx)("span", {
                              className: "font-semibold text-primary",
                              children: "5.",
                            }),
                            (0, u.jsx)("span", {
                              children:
                                "Use it and disable new updates from being auto installed.",
                            }),
                          ],
                        }),
                        (0, u.jsxs)("li", {
                          className: "flex items-start gap-2",
                          children: [
                            (0, u.jsx)("span", {
                              className: "font-semibold text-primary",
                              children: "6.",
                            }),
                            (0, u.jsxs)("span", {
                              children: [
                                "Restart your ",
                                (0, u.jsx)("strong", { children: "PC" }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, u.jsx)("p", {
                      className:
                        "text-sm text-amber-600 font-medium border-t border-border pt-4",
                      children:
                        "This should be done if you are spoofing, so after reinstalling PC, or if you are injecting before injecting.",
                    }),
                  ],
                }),
                (0, u.jsx)(th, {
                  children: (0, u.jsx)(y.Button, {
                    onClick: () => {
                      r(!1);
                    },
                    className: "w-full",
                    children: "I Understand, Continue",
                  }),
                }),
              ],
            }),
          }),
          (0, u.jsx)("header", {
            className:
              "sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60",
            children: (0, u.jsx)("div", {
              className: "container flex h-16 items-center px-4",
              children: (0, u.jsxs)(f.default, {
                href: "/",
                className:
                  "flex items-center gap-2 text-foreground hover:text-primary transition-colors",
                children: [
                  (0, u.jsx)(p.ArrowLeft, { className: "h-5 w-5" }),
                  (0, u.jsx)("span", {
                    className: "font-semibold",
                    children: "Back to Home",
                  }),
                ],
              }),
            }),
          }),
          (0, u.jsx)("section", {
            className:
              "relative py-20 px-4 bg-gradient-to-b from-primary/20 to-background",
            children: (0, u.jsxs)("div", {
              className: "container mx-auto max-w-4xl text-center",
              children: [
                (0, u.jsx)("h1", {
                  className: "text-5xl font-bold mb-6 text-balance",
                  children: "HWID Unban Setup",
                }),
                (0, u.jsx)("p", {
                  className: "text-xl text-muted-foreground text-pretty",
                  children: "Choose which game you want to spoof for",
                }),
              ],
            }),
          }),
          (0, u.jsx)("section", {
            className: "py-16 px-4",
            children: (0, u.jsx)("div", {
              className: "container mx-auto max-w-5xl",
              children: (0, u.jsxs)("div", {
                className: "grid md:grid-cols-2 gap-8",
                children: [
                  (0, u.jsx)(f.default, {
                    href: "/guides/hwid-unban/valorant",
                    className: "group",
                    children: (0, u.jsxs)("div", {
                      className:
                        "h-full bg-gradient-to-br from-red-500/10 to-red-500/5 border-2 border-red-500/30 rounded-lg p-8 space-y-6 hover:border-red-500/50 transition-all hover:scale-105",
                      children: [
                        (0, u.jsx)("div", {
                          className: "flex justify-center",
                          children: (0, u.jsx)("div", {
                            className:
                              "h-20 w-20 rounded-full bg-red-500/20 flex items-center justify-center group-hover:bg-red-500/30 transition-colors",
                            children: (0, u.jsx)(h, {
                              className: "h-10 w-10 text-red-500",
                            }),
                          }),
                        }),
                        (0, u.jsxs)("div", {
                          className: "text-center space-y-3",
                          children: [
                            (0, u.jsx)("h2", {
                              className: "text-3xl font-bold",
                              children: "Valorant Spoof",
                            }),
                            (0, u.jsx)("p", {
                              className: "text-muted-foreground text-lg",
                              children:
                                "Complete HWID spoofing for Valorant with Vanguard bypass",
                            }),
                          ],
                        }),
                        (0, u.jsx)("div", {
                          className: "pt-4",
                          children: (0, u.jsx)(y.Button, {
                            size: "lg",
                            className:
                              "w-full bg-red-500 hover:bg-red-600 text-white",
                            children: "Select Valorant",
                          }),
                        }),
                      ],
                    }),
                  }),
                  (0, u.jsx)(f.default, {
                    href: "/guides/hwid-unban/eac-be",
                    className: "group",
                    children: (0, u.jsxs)("div", {
                      className:
                        "h-full bg-gradient-to-br from-primary/10 to-primary/5 border-2 border-primary/30 rounded-lg p-8 space-y-6 hover:border-primary/50 transition-all hover:scale-105",
                      children: [
                        (0, u.jsx)("div", {
                          className: "flex justify-center",
                          children: (0, u.jsx)("div", {
                            className:
                              "h-20 w-20 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary/30 transition-colors",
                            children: (0, u.jsx)(v, {
                              className: "h-10 w-10 text-primary",
                            }),
                          }),
                        }),
                        (0, u.jsxs)("div", {
                          className: "text-center space-y-3",
                          children: [
                            (0, u.jsx)("h2", {
                              className: "text-3xl font-bold",
                              children: "EAC & BE Games Spoof",
                            }),
                            (0, u.jsx)("p", {
                              className: "text-muted-foreground text-lg",
                              children:
                                "Simplified spoofing for Fortnite, Rust, and other EAC/BE games",
                            }),
                          ],
                        }),
                        (0, u.jsx)("div", {
                          className: "pt-4",
                          children: (0, u.jsx)(y.Button, {
                            size: "lg",
                            className: "w-full",
                            children: "Select EAC/BE Games",
                          }),
                        }),
                      ],
                    }),
                  }),
                ],
              }),
            }),
          }),
        ],
      });
    }
    e.s(["default", () => ty], 4478);
  },
]);
