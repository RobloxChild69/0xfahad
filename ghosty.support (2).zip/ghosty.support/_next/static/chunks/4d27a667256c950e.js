(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  60835,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "warnOnce", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let n = (e) => {};
  },
  85260,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      assign: function () {
        return l;
      },
      searchParamsToUrlQuery: function () {
        return u;
      },
      urlQueryToSearchParams: function () {
        return a;
      },
    };
    for (var o in n) Object.defineProperty(r, o, { enumerable: !0, get: n[o] });
    function u(e) {
      let t = {};
      for (let [r, n] of e.entries()) {
        let e = t[r];
        void 0 === e
          ? (t[r] = n)
          : Array.isArray(e)
          ? e.push(n)
          : (t[r] = [e, n]);
      }
      return t;
    }
    function i(e) {
      return "string" == typeof e
        ? e
        : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e
        ? ""
        : String(e);
    }
    function a(e) {
      let t = new URLSearchParams();
      for (let [r, n] of Object.entries(e))
        if (Array.isArray(n)) for (let e of n) t.append(r, i(e));
        else t.set(r, i(n));
      return t;
    }
    function l(e, ...t) {
      for (let r of t) {
        for (let t of r.keys()) e.delete(t);
        for (let [t, n] of r.entries()) e.append(t, n);
      }
      return e;
    }
  },
  91552,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      formatUrl: function () {
        return a;
      },
      formatWithValidation: function () {
        return s;
      },
      urlObjectKeys: function () {
        return l;
      },
    };
    for (var o in n) Object.defineProperty(r, o, { enumerable: !0, get: n[o] });
    let u = e.r(44066)._(e.r(85260)),
      i = /https?|ftp|gopher|file/;
    function a(e) {
      let { auth: t, hostname: r } = e,
        n = e.protocol || "",
        o = e.pathname || "",
        a = e.hash || "",
        l = e.query || "",
        s = !1;
      (t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : ""),
        e.host
          ? (s = t + e.host)
          : r &&
            ((s = t + (~r.indexOf(":") ? `[${r}]` : r)),
            e.port && (s += ":" + e.port)),
        l && "object" == typeof l && (l = String(u.urlQueryToSearchParams(l)));
      let c = e.search || (l && `?${l}`) || "";
      return (
        n && !n.endsWith(":") && (n += ":"),
        e.slashes || ((!n || i.test(n)) && !1 !== s)
          ? ((s = "//" + (s || "")), o && "/" !== o[0] && (o = "/" + o))
          : s || (s = ""),
        a && "#" !== a[0] && (a = "#" + a),
        c && "?" !== c[0] && (c = "?" + c),
        (o = o.replace(/[?#]/g, encodeURIComponent)),
        (c = c.replace("#", "%23")),
        `${n}${s}${o}${c}${a}`
      );
    }
    let l = [
      "auth",
      "hash",
      "host",
      "hostname",
      "href",
      "path",
      "pathname",
      "port",
      "protocol",
      "query",
      "search",
      "slashes",
    ];
    function s(e) {
      return a(e);
    }
  },
  60203,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function () {
          return o;
        },
      });
    let n = e.r(80883);
    function o(e, t) {
      let r = (0, n.useRef)(null),
        o = (0, n.useRef)(null);
      return (0, n.useCallback)(
        (n) => {
          if (null === n) {
            let e = r.current;
            e && ((r.current = null), e());
            let t = o.current;
            t && ((o.current = null), t());
          } else e && (r.current = u(e, n)), t && (o.current = u(t, n));
        },
        [e, t]
      );
    }
    function u(e, t) {
      if ("function" != typeof e)
        return (
          (e.current = t),
          () => {
            e.current = null;
          }
        );
      {
        let r = e(t);
        return "function" == typeof r ? r : () => e(null);
      }
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  6898,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      DecodeError: function () {
        return g;
      },
      MiddlewareNotFoundError: function () {
        return _;
      },
      MissingStaticPage: function () {
        return P;
      },
      NormalizeError: function () {
        return b;
      },
      PageNotFoundError: function () {
        return v;
      },
      SP: function () {
        return y;
      },
      ST: function () {
        return m;
      },
      WEB_VITALS: function () {
        return u;
      },
      execOnce: function () {
        return i;
      },
      getDisplayName: function () {
        return f;
      },
      getLocationOrigin: function () {
        return s;
      },
      getURL: function () {
        return c;
      },
      isAbsoluteUrl: function () {
        return l;
      },
      isResSent: function () {
        return p;
      },
      loadGetInitialProps: function () {
        return h;
      },
      normalizeRepeatedSlashes: function () {
        return d;
      },
      stringifyError: function () {
        return O;
      },
    };
    for (var o in n) Object.defineProperty(r, o, { enumerable: !0, get: n[o] });
    let u = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];
    function i(e) {
      let t,
        r = !1;
      return (...n) => (r || ((r = !0), (t = e(...n))), t);
    }
    let a = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
      l = (e) => a.test(e);
    function s() {
      let { protocol: e, hostname: t, port: r } = window.location;
      return `${e}//${t}${r ? ":" + r : ""}`;
    }
    function c() {
      let { href: e } = window.location,
        t = s();
      return e.substring(t.length);
    }
    function f(e) {
      return "string" == typeof e ? e : e.displayName || e.name || "Unknown";
    }
    function p(e) {
      return e.finished || e.headersSent;
    }
    function d(e) {
      let t = e.split("?");
      return (
        t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") +
        (t[1] ? `?${t.slice(1).join("?")}` : "")
      );
    }
    async function h(e, t) {
      let r = t.res || (t.ctx && t.ctx.res);
      if (!e.getInitialProps)
        return t.ctx && t.Component
          ? { pageProps: await h(t.Component, t.ctx) }
          : {};
      let n = await e.getInitialProps(t);
      if (r && p(r)) return n;
      if (!n)
        throw Object.defineProperty(
          Error(
            `"${f(
              e
            )}.getInitialProps()" should resolve to an object. But found "${n}" instead.`
          ),
          "__NEXT_ERROR_CODE",
          { value: "E394", enumerable: !1, configurable: !0 }
        );
      return n;
    }
    let y = "undefined" != typeof performance,
      m =
        y &&
        ["mark", "measure", "getEntriesByName"].every(
          (e) => "function" == typeof performance[e]
        );
    class g extends Error {}
    class b extends Error {}
    class v extends Error {
      constructor(e) {
        super(),
          (this.code = "ENOENT"),
          (this.name = "PageNotFoundError"),
          (this.message = `Cannot find module for page: ${e}`);
      }
    }
    class P extends Error {
      constructor(e, t) {
        super(),
          (this.message = `Failed to load static file for page: ${e} ${t}`);
      }
    }
    class _ extends Error {
      constructor() {
        super(),
          (this.code = "ENOENT"),
          (this.message = "Cannot find the middleware module");
      }
    }
    function O(e) {
      return JSON.stringify({ message: e.message, stack: e.stack });
    }
  },
  73350,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function () {
          return u;
        },
      });
    let n = e.r(6898),
      o = e.r(56075);
    function u(e) {
      if (!(0, n.isAbsoluteUrl)(e)) return !0;
      try {
        let t = (0, n.getLocationOrigin)(),
          r = new URL(e, t);
        return r.origin === t && (0, o.hasBasePath)(r.pathname);
      } catch (e) {
        return !1;
      }
    }
  },
  95136,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "errorOnce", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let n = (e) => {};
  },
  61021,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      default: function () {
        return g;
      },
      useLinkStatus: function () {
        return v;
      },
    };
    for (var o in n) Object.defineProperty(r, o, { enumerable: !0, get: n[o] });
    let u = e.r(44066),
      i = e.r(93046),
      a = u._(e.r(80883)),
      l = e.r(91552),
      s = e.r(89260),
      c = e.r(60203),
      f = e.r(6898),
      p = e.r(63118);
    e.r(60835);
    let d = e.r(68193),
      h = e.r(73350),
      y = e.r(50696);
    function m(e) {
      return "string" == typeof e ? e : (0, l.formatUrl)(e);
    }
    function g(t) {
      var r;
      let n,
        o,
        u,
        [l, g] = (0, a.useOptimistic)(d.IDLE_LINK_STATUS),
        v = (0, a.useRef)(null),
        {
          href: P,
          as: _,
          children: O,
          prefetch: E = null,
          passHref: j,
          replace: C,
          shallow: S,
          scroll: x,
          onClick: w,
          onMouseEnter: N,
          onTouchStart: T,
          legacyBehavior: R = !1,
          onNavigate: M,
          ref: $,
          unstable_dynamicOnHover: L,
          ...A
        } = t;
      (n = O),
        R &&
          ("string" == typeof n || "number" == typeof n) &&
          (n = (0, i.jsx)("a", { children: n }));
      let U = a.default.useContext(s.AppRouterContext),
        k = !1 !== E,
        I =
          !1 !== E
            ? null === (r = E) || "auto" === r
              ? y.FetchStrategy.PPR
              : y.FetchStrategy.Full
            : y.FetchStrategy.PPR,
        { href: F, as: D } = a.default.useMemo(() => {
          let e = m(P);
          return { href: e, as: _ ? m(_) : e };
        }, [P, _]);
      if (R) {
        if (n?.$$typeof === Symbol.for("react.lazy"))
          throw Object.defineProperty(
            Error(
              "`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."
            ),
            "__NEXT_ERROR_CODE",
            { value: "E863", enumerable: !1, configurable: !0 }
          );
        o = a.default.Children.only(n);
      }
      let B = R ? o && "object" == typeof o && o.ref : $,
        K = a.default.useCallback(
          (e) => (
            null !== U &&
              (v.current = (0, d.mountLinkInstance)(e, F, U, I, k, g)),
            () => {
              v.current &&
                ((0, d.unmountLinkForCurrentNavigation)(v.current),
                (v.current = null)),
                (0, d.unmountPrefetchableInstance)(e);
            }
          ),
          [k, F, U, I, g]
        ),
        z = {
          ref: (0, c.useMergedRef)(K, B),
          onClick(t) {
            R || "function" != typeof w || w(t),
              R &&
                o.props &&
                "function" == typeof o.props.onClick &&
                o.props.onClick(t),
              !U ||
                t.defaultPrevented ||
                (function (t, r, n, o, u, i, l) {
                  if ("undefined" != typeof window) {
                    let s,
                      { nodeName: c } = t.currentTarget;
                    if (
                      ("A" === c.toUpperCase() &&
                        (((s = t.currentTarget.getAttribute("target")) &&
                          "_self" !== s) ||
                          t.metaKey ||
                          t.ctrlKey ||
                          t.shiftKey ||
                          t.altKey ||
                          (t.nativeEvent && 2 === t.nativeEvent.which))) ||
                      t.currentTarget.hasAttribute("download")
                    )
                      return;
                    if (!(0, h.isLocalURL)(r)) {
                      u && (t.preventDefault(), location.replace(r));
                      return;
                    }
                    if ((t.preventDefault(), l)) {
                      let e = !1;
                      if (
                        (l({
                          preventDefault: () => {
                            e = !0;
                          },
                        }),
                        e)
                      )
                        return;
                    }
                    let { dispatchNavigateAction: f } = e.r(56797);
                    a.default.startTransition(() => {
                      f(n || r, u ? "replace" : "push", i ?? !0, o.current);
                    });
                  }
                })(t, F, D, v, C, x, M);
          },
          onMouseEnter(e) {
            R || "function" != typeof N || N(e),
              R &&
                o.props &&
                "function" == typeof o.props.onMouseEnter &&
                o.props.onMouseEnter(e),
              U && k && (0, d.onNavigationIntent)(e.currentTarget, !0 === L);
          },
          onTouchStart: function (e) {
            R || "function" != typeof T || T(e),
              R &&
                o.props &&
                "function" == typeof o.props.onTouchStart &&
                o.props.onTouchStart(e),
              U && k && (0, d.onNavigationIntent)(e.currentTarget, !0 === L);
          },
        };
      return (
        (0, f.isAbsoluteUrl)(D)
          ? (z.href = D)
          : (R && !j && ("a" !== o.type || "href" in o.props)) ||
            (z.href = (0, p.addBasePath)(D)),
        (u = R
          ? a.default.cloneElement(o, z)
          : (0, i.jsx)("a", { ...A, ...z, children: n })),
        (0, i.jsx)(b.Provider, { value: l, children: u })
      );
    }
    e.r(95136);
    let b = (0, a.createContext)(d.IDLE_LINK_STATUS),
      v = () => (0, a.useContext)(b);
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  84675,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("ArrowLeft", [
      ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
      ["path", { d: "M19 12H5", key: "x3x0zl" }],
    ]);
    e.s(["ArrowLeft", () => t], 84675);
  },
  13942,
  4786,
  (e) => {
    "use strict";
    var t = e.i(80883),
      r = e.i(93046);
    function n(e, n) {
      let o = t.createContext(n),
        u = (e) => {
          let { children: n, ...u } = e,
            i = t.useMemo(() => u, Object.values(u));
          return (0, r.jsx)(o.Provider, { value: i, children: n });
        };
      return (
        (u.displayName = e + "Provider"),
        [
          u,
          function (r) {
            let u = t.useContext(o);
            if (u) return u;
            if (void 0 !== n) return n;
            throw Error(`\`${r}\` must be used within \`${e}\``);
          },
        ]
      );
    }
    function o(e, n = []) {
      let u = [],
        i = () => {
          let r = u.map((e) => t.createContext(e));
          return function (n) {
            let o = n?.[e] || r;
            return t.useMemo(
              () => ({ [`__scope${e}`]: { ...n, [e]: o } }),
              [n, o]
            );
          };
        };
      return (
        (i.scopeName = e),
        [
          function (n, o) {
            let i = t.createContext(o),
              a = u.length;
            u = [...u, o];
            let l = (n) => {
              let { scope: o, children: u, ...l } = n,
                s = o?.[e]?.[a] || i,
                c = t.useMemo(() => l, Object.values(l));
              return (0, r.jsx)(s.Provider, { value: c, children: u });
            };
            return (
              (l.displayName = n + "Provider"),
              [
                l,
                function (r, u) {
                  let l = u?.[e]?.[a] || i,
                    s = t.useContext(l);
                  if (s) return s;
                  if (void 0 !== o) return o;
                  throw Error(`\`${r}\` must be used within \`${n}\``);
                },
              ]
            );
          },
          (function (...e) {
            let r = e[0];
            if (1 === e.length) return r;
            let n = () => {
              let n = e.map((e) => ({ useScope: e(), scopeName: e.scopeName }));
              return function (e) {
                let o = n.reduce((t, { useScope: r, scopeName: n }) => {
                  let o = r(e)[`__scope${n}`];
                  return { ...t, ...o };
                }, {});
                return t.useMemo(() => ({ [`__scope${r.scopeName}`]: o }), [o]);
              };
            };
            return (n.scopeName = r.scopeName), n;
          })(i, ...n),
        ]
      );
    }
    e.s(["createContext", () => n, "createContextScope", () => o], 13942);
    var u = e.i(36425),
      i = e.i(87576),
      a = [
        "a",
        "button",
        "div",
        "form",
        "h2",
        "h3",
        "img",
        "input",
        "label",
        "li",
        "nav",
        "ol",
        "p",
        "span",
        "svg",
        "ul",
      ].reduce((e, n) => {
        let o = t.forwardRef((e, t) => {
          let { asChild: o, ...u } = e,
            a = o ? i.Slot : n;
          return (
            "undefined" != typeof window &&
              (window[Symbol.for("radix-ui")] = !0),
            (0, r.jsx)(a, { ...u, ref: t })
          );
        });
        return (o.displayName = `Primitive.${n}`), { ...e, [n]: o };
      }, {});
    function l(e, t) {
      e && u.flushSync(() => e.dispatchEvent(t));
    }
    e.s(["Primitive", () => a, "dispatchDiscreteCustomEvent", () => l], 4786);
  },
]);
