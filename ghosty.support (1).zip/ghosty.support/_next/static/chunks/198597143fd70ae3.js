(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  81947,
  (e) => {
    "use strict";
    var s = e.i(93046),
      t = e.i(94237),
      r = e.i(47163);
    let a = (0, t.cva)(
      "relative w-full rounded-lg border px-4 py-3 text-sm grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current",
      {
        variants: {
          variant: {
            default: "bg-card text-card-foreground",
            destructive:
              "text-destructive bg-card [&>svg]:text-current *:data-[slot=alert-description]:text-destructive/90",
          },
        },
        defaultVariants: { variant: "default" },
      }
    );
    function l({ className: e, variant: t, ...l }) {
      return (0, s.jsx)("div", {
        "data-slot": "alert",
        role: "alert",
        className: (0, r.cn)(a({ variant: t }), e),
        ...l,
      });
    }
    function n({ className: e, ...t }) {
      return (0, s.jsx)("div", {
        "data-slot": "alert-description",
        className: (0, r.cn)(
          "text-muted-foreground col-start-2 grid justify-items-start gap-1 text-sm [&_p]:leading-relaxed",
          e
        ),
        ...t,
      });
    }
    e.s(["Alert", () => l, "AlertDescription", () => n]);
  },
  13637,
  (e) => {
    "use strict";
    let s = (0, e.i(10965).default)("Download", [
      [
        "path",
        { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
      ],
      ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
      ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }],
    ]);
    e.s(["Download", () => s], 13637);
  },
  64877,
  (e) => {
    "use strict";
    let s = (0, e.i(10965).default)("TriangleAlert", [
      [
        "path",
        {
          d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
          key: "wmoenq",
        },
      ],
      ["path", { d: "M12 9v4", key: "juzpu7" }],
      ["path", { d: "M12 17h.01", key: "p32p05" }],
    ]);
    e.s(["AlertTriangle", () => s], 64877);
  },
  70065,
  (e) => {
    "use strict";
    var s = e.i(93046),
      t = e.i(47163);
    function r({ className: e, ...r }) {
      return (0, s.jsx)("div", {
        "data-slot": "card",
        className: (0, t.cn)(
          "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",
          e
        ),
        ...r,
      });
    }
    function a({ className: e, ...r }) {
      return (0, s.jsx)("div", {
        "data-slot": "card-header",
        className: (0, t.cn)(
          "@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6",
          e
        ),
        ...r,
      });
    }
    function l({ className: e, ...r }) {
      return (0, s.jsx)("div", {
        "data-slot": "card-title",
        className: (0, t.cn)("leading-none font-semibold", e),
        ...r,
      });
    }
    function n({ className: e, ...r }) {
      return (0, s.jsx)("div", {
        "data-slot": "card-description",
        className: (0, t.cn)("text-muted-foreground text-sm", e),
        ...r,
      });
    }
    function d({ className: e, ...r }) {
      return (0, s.jsx)("div", {
        "data-slot": "card-content",
        className: (0, t.cn)("px-6", e),
        ...r,
      });
    }
    e.s([
      "Card",
      () => r,
      "CardContent",
      () => d,
      "CardDescription",
      () => n,
      "CardHeader",
      () => a,
      "CardTitle",
      () => l,
    ]);
  },
  10712,
  (e) => {
    "use strict";
    let s = (0, e.i(10965).default)("Info", [
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
      ["path", { d: "M12 16v-4", key: "1dtifu" }],
      ["path", { d: "M12 8h.01", key: "e9boi3" }],
    ]);
    e.s(["Info", () => s], 10712);
  },
  17508,
  52910,
  (e) => {
    "use strict";
    var s = e.i(10965);
    let t = (0, s.default)("ChevronRight", [
      ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }],
    ]);
    e.s(["ChevronRight", () => t], 17508);
    let r = (0, s.default)("ChevronLeft", [
      ["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }],
    ]);
    e.s(["ChevronLeft", () => r], 52910);
  },
  13293,
  76841,
  (e) => {
    "use strict";
    var s = e.i(93046);
    let t = (0, e.i(10965).default)("Ghost", [
      ["path", { d: "M9 10h.01", key: "qbtxuw" }],
      ["path", { d: "M15 10h.01", key: "1qmjsl" }],
      [
        "path",
        {
          d: "M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z",
          key: "uwwb07",
        },
      ],
    ]);
    var r = e.i(67881);
    function a() {
      return (0, s.jsx)("header", {
        className:
          "border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50",
        children: (0, s.jsxs)("div", {
          className:
            "container mx-auto px-4 py-4 flex items-center justify-between",
          children: [
            (0, s.jsxs)("div", {
              className: "flex items-center gap-2",
              children: [
                (0, s.jsx)(t, { className: "h-8 w-8 text-primary" }),
                (0, s.jsx)("span", {
                  className: "text-2xl font-bold text-foreground",
                  children: "GHOSTY Services",
                }),
              ],
            }),
            (0, s.jsxs)("nav", {
              className: "hidden md:flex items-center gap-6",
              children: [
                (0, s.jsx)("a", {
                  href: "#products",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Products",
                }),
                (0, s.jsx)("a", {
                  href: "#guides",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Guides",
                }),
                (0, s.jsx)("a", {
                  href: "#support",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Support",
                }),
                (0, s.jsx)(r.Button, {
                  size: "sm",
                  className:
                    "bg-primary hover:bg-primary/90 text-primary-foreground",
                  children: "Get Started",
                }),
              ],
            }),
          ],
        }),
      });
    }
    function l() {
      return (0, s.jsx)("footer", {
        className: "border-t border-border bg-card/50 py-12 px-4",
        children: (0, s.jsxs)("div", {
          className: "container mx-auto",
          children: [
            (0, s.jsxs)("div", {
              className: "grid grid-cols-1 md:grid-cols-4 gap-8 mb-8",
              children: [
                (0, s.jsxs)("div", {
                  className: "space-y-4",
                  children: [
                    (0, s.jsxs)("div", {
                      className: "flex items-center gap-2",
                      children: [
                        (0, s.jsx)(t, { className: "h-6 w-6 text-primary" }),
                        (0, s.jsx)("span", {
                          className: "text-xl font-bold text-foreground",
                          children: "GHOSTY Services",
                        }),
                      ],
                    }),
                    (0, s.jsx)("p", {
                      className:
                        "text-muted-foreground text-sm leading-relaxed",
                      children:
                        "Your trusted source for gaming guides, tutorials, and professional services.",
                    }),
                  ],
                }),
                (0, s.jsxs)("div", {
                  children: [
                    (0, s.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Products",
                    }),
                    (0, s.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "All Guides",
                          }),
                        }),
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "FPS Games",
                          }),
                        }),
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Battle Royale",
                          }),
                        }),
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Services",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                (0, s.jsxs)("div", {
                  children: [
                    (0, s.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Support",
                    }),
                    (0, s.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Help Center",
                          }),
                        }),
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Contact Us",
                          }),
                        }),
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "FAQ",
                          }),
                        }),
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Discord",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                (0, s.jsxs)("div", {
                  children: [
                    (0, s.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Legal",
                    }),
                    (0, s.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Terms of Service",
                          }),
                        }),
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Privacy Policy",
                          }),
                        }),
                        (0, s.jsx)("li", {
                          children: (0, s.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Refund Policy",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            (0, s.jsx)("div", {
              className:
                "border-t border-border pt-8 text-center text-sm text-muted-foreground",
              children: (0, s.jsx)("p", {
                children: "© 2025 GHOSTY Services. All rights reserved.",
              }),
            }),
          ],
        }),
      });
    }
    e.s(["Header", () => a], 13293), e.s(["Footer", () => l], 76841);
  },
  88297,
  (e) => {
    "use strict";
    let s = (0, e.i(10965).default)("CircleCheckBig", [
      ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
      ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }],
    ]);
    e.s(["CheckCircle", () => s], 88297);
  },
  94179,
  (e) => {
    "use strict";
    var s = e.i(93046),
      t = e.i(87576),
      r = e.i(94237),
      a = e.i(47163);
    let l = (0, r.cva)(
      "inline-flex items-center justify-center rounded-md border px-2 py-0.5 text-xs font-medium w-fit whitespace-nowrap shrink-0 [&>svg]:size-3 gap-1 [&>svg]:pointer-events-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive transition-[color,box-shadow] overflow-hidden",
      {
        variants: {
          variant: {
            default:
              "border-transparent bg-primary text-primary-foreground [a&]:hover:bg-primary/90",
            secondary:
              "border-transparent bg-secondary text-secondary-foreground [a&]:hover:bg-secondary/90",
            destructive:
              "border-transparent bg-destructive text-white [a&]:hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline:
              "text-foreground [a&]:hover:bg-accent [a&]:hover:text-accent-foreground",
          },
        },
        defaultVariants: { variant: "default" },
      }
    );
    function n({ className: e, variant: r, asChild: n = !1, ...d }) {
      let i = n ? t.Slot : "span";
      return (0, s.jsx)(i, {
        "data-slot": "badge",
        className: (0, a.cn)(l({ variant: r }), e),
        ...d,
      });
    }
    e.s(["Badge", () => n]);
  },
  47316,
  (e) => {
    "use strict";
    var s = e.i(93046),
      t = e.i(80883),
      r = e.i(13293),
      a = e.i(76841),
      l = e.i(67881),
      n = e.i(70065),
      d = e.i(94179),
      i = e.i(81947),
      o = e.i(17508),
      c = e.i(52910),
      x = e.i(88297),
      m = e.i(64877),
      h = e.i(10712),
      u = e.i(13637);
    function g() {
      let [e, g] = (0, t.useState)(1),
        f = (e / 6) * 100;
      return (0, s.jsxs)("main", {
        className: "min-h-screen bg-background",
        children: [
          (0, s.jsx)(r.Header, {}),
          (0, s.jsxs)("section", {
            className:
              "relative py-20 px-4 bg-gradient-to-br from-primary/20 via-background to-background overflow-hidden",
            children: [
              (0, s.jsx)("div", {
                className: "absolute inset-0 bg-grid-white/[0.02] -z-10",
              }),
              (0, s.jsx)("div", {
                className: "container mx-auto max-w-5xl",
                children: (0, s.jsx)("div", {
                  className: "flex flex-col lg:flex-row items-center gap-8",
                  children: (0, s.jsxs)("div", {
                    className: "flex-1",
                    children: [
                      (0, s.jsx)(d.Badge, {
                        className: "mb-4 bg-primary/90 text-primary-foreground",
                        children: "Multiplayer Mod",
                      }),
                      (0, s.jsx)("h1", {
                        className: "text-5xl font-bold mb-4 text-foreground",
                        children: "FiveM Setup Guide",
                      }),
                      (0, s.jsx)("p", {
                        className:
                          "text-xl text-muted-foreground leading-relaxed",
                        children:
                          "Quick and easy setup for FiveM. Follow these simple steps to get started.",
                      }),
                    ],
                  }),
                }),
              }),
            ],
          }),
          (0, s.jsx)("section", {
            className:
              "sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border py-4 px-4",
            children: (0, s.jsxs)("div", {
              className: "container mx-auto max-w-5xl",
              children: [
                (0, s.jsxs)("div", {
                  className: "flex items-center justify-between mb-3",
                  children: [
                    (0, s.jsxs)("div", {
                      className: "text-sm font-medium text-foreground",
                      children: ["Step ", e, " of ", 6],
                    }),
                    (0, s.jsxs)("div", {
                      className: "text-sm text-muted-foreground",
                      children: [f.toFixed(0), "% Complete"],
                    }),
                  ],
                }),
                (0, s.jsx)("div", {
                  className: "h-2 bg-muted rounded-full overflow-hidden",
                  children: (0, s.jsx)("div", {
                    className:
                      "h-full bg-primary transition-all duration-500 ease-out",
                    style: { width: `${f}%` },
                  }),
                }),
              ],
            }),
          }),
          (0, s.jsx)("section", {
            className: "py-12 px-4",
            children: (0, s.jsxs)("div", {
              className: "container mx-auto max-w-5xl",
              children: [
                1 === e &&
                  (0, s.jsxs)("div", {
                    className: "animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-center gap-4 mb-8",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "w-20 h-20 rounded-2xl bg-amber-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-amber-500/30",
                            children: "⚠️",
                          }),
                          (0, s.jsxs)("div", {
                            children: [
                              (0, s.jsx)("h2", {
                                className:
                                  "text-5xl font-bold text-foreground mb-2",
                                children: "Important Notice",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-muted-foreground text-xl",
                                children: "Please read this before starting",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)(i.Alert, {
                        className: "border-amber-500/50 bg-amber-500/10 mb-6",
                        children: [
                          (0, s.jsx)(m.AlertTriangle, {
                            className: "h-5 w-5 text-amber-500",
                          }),
                          (0, s.jsxs)(i.AlertDescription, {
                            className: "text-foreground text-lg",
                            children: [
                              (0, s.jsx)("strong", {
                                children: "Before launching the loader:",
                              }),
                              " Make sure GTA V and FiveM are completely closed!",
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                2 === e &&
                  (0, s.jsxs)("div", {
                    className: "animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-center gap-4 mb-8",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "w-20 h-20 rounded-2xl bg-orange-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-orange-500/30",
                            children: "1",
                          }),
                          (0, s.jsxs)("div", {
                            children: [
                              (0, s.jsx)("h2", {
                                className:
                                  "text-5xl font-bold text-foreground mb-2",
                                children: "Disable Windows Defender",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-muted-foreground text-xl",
                                children: "Use dControl to turn off antivirus",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsx)(n.Card, {
                        className:
                          "border-orange-500/30 bg-orange-500/5 backdrop-blur",
                        children: (0, s.jsxs)(n.CardContent, {
                          className: "pt-8 space-y-6",
                          children: [
                            (0, s.jsxs)(i.Alert, {
                              className: "border-red-500/50 bg-red-500/10",
                              children: [
                                (0, s.jsx)(m.AlertTriangle, {
                                  className: "h-5 w-5 text-red-500",
                                }),
                                (0, s.jsxs)(i.AlertDescription, {
                                  className: "text-foreground text-lg",
                                  children: [
                                    (0, s.jsx)("strong", {
                                      children: "IMPORTANT:",
                                    }),
                                    " You must disable Windows Defender before opening the loader!",
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "space-y-4 text-muted-foreground text-lg",
                              children: [
                                (0, s.jsxs)("p", {
                                  className: "flex items-start gap-3",
                                  children: [
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-orange-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Download dControl using the button below",
                                  ],
                                }),
                                (0, s.jsxs)("p", {
                                  className: "flex items-start gap-3",
                                  children: [
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-orange-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Install and run dControl",
                                  ],
                                }),
                                (0, s.jsxs)("p", {
                                  className: "flex items-start gap-3",
                                  children: [
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-orange-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Click the button to disable Windows Defender completely",
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsx)(l.Button, {
                              asChild: !0,
                              className:
                                "w-full sm:w-auto h-14 text-base bg-orange-500 hover:bg-orange-600",
                              children: (0, s.jsxs)("a", {
                                href: "https://www.sordum.org/downloads/?dcontrol",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: [
                                  (0, s.jsx)(u.Download, {
                                    className: "mr-2 h-5 w-5",
                                  }),
                                  "Download dControl",
                                ],
                              }),
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                3 === e &&
                  (0, s.jsxs)("div", {
                    className: "animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-center gap-4 mb-8",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "w-20 h-20 rounded-2xl bg-purple-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-purple-500/30",
                            children: "2",
                          }),
                          (0, s.jsxs)("div", {
                            children: [
                              (0, s.jsx)("h2", {
                                className:
                                  "text-5xl font-bold text-foreground mb-2",
                                children: "Install Required Dependencies",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-muted-foreground text-xl",
                                children: "DirectX and Visual C++ Runtime",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsx)(n.Card, {
                        className:
                          "border-purple-500/30 bg-purple-500/5 backdrop-blur",
                        children: (0, s.jsxs)(n.CardContent, {
                          className: "pt-8 space-y-6",
                          children: [
                            (0, s.jsxs)(i.Alert, {
                              className: "border-blue-500/50 bg-blue-500/10",
                              children: [
                                (0, s.jsx)(h.Info, {
                                  className: "h-5 w-5 text-blue-500",
                                }),
                                (0, s.jsx)(i.AlertDescription, {
                                  className: "text-foreground text-lg",
                                  children:
                                    "These are required for the loader to work properly",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className: "grid gap-4",
                              children: [
                                (0, s.jsxs)("div", {
                                  className:
                                    "p-6 bg-secondary/50 rounded-lg space-y-4",
                                  children: [
                                    (0, s.jsx)("h4", {
                                      className:
                                        "text-xl font-semibold flex items-center gap-2 text-foreground",
                                      children: "DirectX End-User Runtime",
                                    }),
                                    (0, s.jsx)("p", {
                                      className: "text-muted-foreground",
                                      children:
                                        "Required for graphics and game functionality",
                                    }),
                                    (0, s.jsx)(l.Button, {
                                      asChild: !0,
                                      variant: "default",
                                      className:
                                        "w-full sm:w-auto h-12 text-base bg-purple-500 hover:bg-purple-600",
                                      children: (0, s.jsxs)("a", {
                                        href: "https://www.microsoft.com/en-us/download/details.aspx?id=35",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: [
                                          (0, s.jsx)(u.Download, {
                                            className: "mr-2 h-5 w-5",
                                          }),
                                          "Download DirectX",
                                        ],
                                      }),
                                    }),
                                  ],
                                }),
                                (0, s.jsxs)("div", {
                                  className:
                                    "p-6 bg-secondary/50 rounded-lg space-y-4",
                                  children: [
                                    (0, s.jsx)("h4", {
                                      className:
                                        "text-xl font-semibold flex items-center gap-2 text-foreground",
                                      children:
                                        "Visual C++ Runtime (All-in-One)",
                                    }),
                                    (0, s.jsx)("p", {
                                      className: "text-muted-foreground",
                                      children:
                                        "Essential runtime libraries for the loader",
                                    }),
                                    (0, s.jsx)(l.Button, {
                                      asChild: !0,
                                      variant: "default",
                                      className:
                                        "w-full sm:w-auto h-12 text-base bg-purple-500 hover:bg-purple-600",
                                      children: (0, s.jsxs)("a", {
                                        href: "https://www.techpowerup.com/download/visual-c-redistributable-runtime-package-all-in-one/",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: [
                                          (0, s.jsx)(u.Download, {
                                            className: "mr-2 h-5 w-5",
                                          }),
                                          "Download Visual C++",
                                        ],
                                      }),
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(i.Alert, {
                              className: "border-amber-500/50 bg-amber-500/10",
                              children: [
                                (0, s.jsx)(m.AlertTriangle, {
                                  className: "h-5 w-5 text-amber-500",
                                }),
                                (0, s.jsx)(i.AlertDescription, {
                                  className: "text-foreground text-lg",
                                  children:
                                    "Install both of these before continuing to the next step",
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                4 === e &&
                  (0, s.jsxs)("div", {
                    className: "animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-center gap-4 mb-8",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "w-20 h-20 rounded-2xl bg-blue-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-blue-500/30",
                            children: "3",
                          }),
                          (0, s.jsxs)("div", {
                            children: [
                              (0, s.jsx)("h2", {
                                className:
                                  "text-5xl font-bold text-foreground mb-2",
                                children: "Install and Run Loader",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-muted-foreground text-xl",
                                children:
                                  "Download and launch the cheat loader",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsx)(n.Card, {
                        className:
                          "border-blue-500/30 bg-blue-500/5 backdrop-blur",
                        children: (0, s.jsxs)(n.CardContent, {
                          className: "pt-8 space-y-6",
                          children: [
                            (0, s.jsxs)(i.Alert, {
                              className: "border-red-500/50 bg-red-500/10",
                              children: [
                                (0, s.jsx)(m.AlertTriangle, {
                                  className: "h-5 w-5 text-red-500",
                                }),
                                (0, s.jsxs)(i.AlertDescription, {
                                  className: "text-foreground text-lg",
                                  children: [
                                    (0, s.jsx)("strong", {
                                      children: "IMPORTANT:",
                                    }),
                                    " Launch the loader BEFORE starting the game!",
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "space-y-4 text-muted-foreground text-lg",
                              children: [
                                (0, s.jsxs)("p", {
                                  className: "flex items-start gap-3",
                                  children: [
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-blue-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Download the loader from the link below",
                                  ],
                                }),
                                (0, s.jsxs)("p", {
                                  className: "flex items-start gap-3",
                                  children: [
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-blue-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Extract the files to your desktop",
                                  ],
                                }),
                                (0, s.jsxs)("p", {
                                  className: "flex items-start gap-3",
                                  children: [
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-blue-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Right-click the loader and select",
                                    " ",
                                    (0, s.jsx)("span", {
                                      className: "text-foreground font-medium",
                                      children: "Run as Administrator",
                                    }),
                                  ],
                                }),
                                (0, s.jsxs)("p", {
                                  className: "flex items-start gap-3",
                                  children: [
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-blue-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Wait for the loader to initialize before starting the game",
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsx)(l.Button, {
                              asChild: !0,
                              className:
                                "w-full sm:w-auto h-14 text-base bg-blue-500 hover:bg-blue-600",
                              children: (0, s.jsxs)("a", {
                                href: "https://mega.nz/folder/eM0TxISI#1Cz75iaf0_8HZ4VOaRU_DQ",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: [
                                  (0, s.jsx)(u.Download, {
                                    className: "mr-2 h-5 w-5",
                                  }),
                                  "Download FiveM Loader",
                                ],
                              }),
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                5 === e &&
                  (0, s.jsxs)("div", {
                    className: "animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-center gap-4 mb-8",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "w-20 h-20 rounded-2xl bg-green-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-green-500/30",
                            children: "4",
                          }),
                          (0, s.jsxs)("div", {
                            children: [
                              (0, s.jsx)("h2", {
                                className:
                                  "text-5xl font-bold text-foreground mb-2",
                                children: "Launch Game & Enjoy!",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-muted-foreground text-xl",
                                children: "You're all set to play",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsx)(n.Card, {
                        className:
                          "border-green-500/30 bg-green-500/5 backdrop-blur mb-6",
                        children: (0, s.jsxs)(n.CardContent, {
                          className: "pt-8 space-y-6",
                          children: [
                            (0, s.jsxs)("div", {
                              className:
                                "space-y-4 text-muted-foreground text-lg",
                              children: [
                                (0, s.jsxs)("p", {
                                  className: "flex items-start gap-3",
                                  children: [
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-green-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Launch FiveM (the loader should already be running)",
                                  ],
                                }),
                                (0, s.jsxs)("p", {
                                  className: "flex items-start gap-3",
                                  children: [
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-green-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Once in the game, press",
                                    " ",
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-foreground font-bold px-2 py-1 bg-secondary rounded",
                                      children: "INSERT",
                                    }),
                                    " to open/close the menu",
                                  ],
                                }),
                                (0, s.jsxs)("p", {
                                  className: "flex items-start gap-3",
                                  children: [
                                    (0, s.jsx)("span", {
                                      className:
                                        "text-green-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Enjoy playing!",
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(i.Alert, {
                              className: "border-amber-500/50 bg-amber-500/10",
                              children: [
                                (0, s.jsx)(m.AlertTriangle, {
                                  className: "h-5 w-5 text-amber-500",
                                }),
                                (0, s.jsxs)(i.AlertDescription, {
                                  className: "text-foreground text-lg",
                                  children: [
                                    (0, s.jsx)("strong", {
                                      children: "IMPORTANT:",
                                    }),
                                    " Make sure your game resolution is set to",
                                    " ",
                                    (0, s.jsx)("span", {
                                      className: "font-bold",
                                      children: "Borderless Window",
                                    }),
                                    " mode!",
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(i.Alert, {
                              className: "border-blue-500/50 bg-blue-500/10",
                              children: [
                                (0, s.jsx)(h.Info, {
                                  className: "h-5 w-5 text-blue-500",
                                }),
                                (0, s.jsxs)(i.AlertDescription, {
                                  className: "text-foreground text-lg",
                                  children: [
                                    (0, s.jsx)("strong", {
                                      children: "Menu Keybind:",
                                    }),
                                    " Press",
                                    " ",
                                    (0, s.jsx)("span", {
                                      className:
                                        "font-bold px-2 py-1 bg-secondary rounded",
                                      children: "INSERT",
                                    }),
                                    " to open or close the cheat menu in-game",
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                      (0, s.jsx)(n.Card, {
                        className: "border-green-500/50 bg-green-500/10",
                        children: (0, s.jsx)(n.CardContent, {
                          className: "pt-6",
                          children: (0, s.jsxs)("div", {
                            className: "flex items-center gap-4",
                            children: [
                              (0, s.jsx)(x.CheckCircle, {
                                className: "h-12 w-12 text-green-500",
                              }),
                              (0, s.jsxs)("div", {
                                children: [
                                  (0, s.jsx)("h3", {
                                    className:
                                      "text-2xl font-bold text-foreground mb-1",
                                    children: "Setup Complete!",
                                  }),
                                  (0, s.jsx)("p", {
                                    className: "text-muted-foreground text-lg",
                                    children: "You're ready to use FiveM cheat",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                      }),
                    ],
                  }),
                6 === e &&
                  (0, s.jsxs)("div", {
                    className: "animate-in fade-in duration-500",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-center gap-4 mb-8",
                        children: [
                          (0, s.jsx)("div", {
                            className:
                              "w-20 h-20 rounded-2xl bg-red-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-red-500/30",
                            children: "🔧",
                          }),
                          (0, s.jsxs)("div", {
                            children: [
                              (0, s.jsx)("h2", {
                                className:
                                  "text-5xl font-bold text-foreground mb-2",
                                children: "Error Fix",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-muted-foreground text-xl",
                                children: "Troubleshooting common issues",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsx)(n.Card, {
                        className:
                          "border-red-500/30 bg-red-500/5 backdrop-blur",
                        children: (0, s.jsxs)(n.CardContent, {
                          className: "pt-8 space-y-6",
                          children: [
                            (0, s.jsxs)(i.Alert, {
                              className: "border-red-500/50 bg-red-500/10",
                              children: [
                                (0, s.jsx)(m.AlertTriangle, {
                                  className: "h-5 w-5 text-red-500",
                                }),
                                (0, s.jsxs)(i.AlertDescription, {
                                  className: "text-foreground text-lg",
                                  children: [
                                    (0, s.jsx)("strong", {
                                      children: "Having Issues?",
                                    }),
                                    " If you're having problems launching the cheat or it's not working in-game",
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className: "space-y-4",
                              children: [
                                (0, s.jsxs)("div", {
                                  className: "p-6 bg-secondary/50 rounded-lg",
                                  children: [
                                    (0, s.jsxs)("h4", {
                                      className:
                                        "text-xl font-semibold mb-4 flex items-center gap-2",
                                      children: [
                                        (0, s.jsx)(h.Info, {
                                          className: "w-5 h-5 text-red-500",
                                        }),
                                        "Diagnostic File",
                                      ],
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-muted-foreground mb-4 text-lg",
                                      children:
                                        "Download this file, run it, and send a screenshot in your support ticket:",
                                    }),
                                    (0, s.jsx)(l.Button, {
                                      asChild: !0,
                                      className:
                                        "w-full sm:w-auto h-12 text-base bg-red-500 hover:bg-red-600",
                                      children: (0, s.jsxs)("a", {
                                        href: "https://mega.nz/file/FzclQSDC#2iKnZBOmkBOwttKpnRa-BLo21LOZfgFPS_HkDG7DveU",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: [
                                          (0, s.jsx)(u.Download, {
                                            className: "w-5 h-5 mr-2",
                                          }),
                                          "Download Diagnostic Tool",
                                        ],
                                      }),
                                    }),
                                  ],
                                }),
                                (0, s.jsxs)("div", {
                                  className:
                                    "space-y-3 text-muted-foreground text-lg",
                                  children: [
                                    (0, s.jsxs)("p", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "text-red-500 font-bold text-xl",
                                          children: "1.",
                                        }),
                                        "Download the diagnostic file from the link above",
                                      ],
                                    }),
                                    (0, s.jsxs)("p", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "text-red-500 font-bold text-xl",
                                          children: "2.",
                                        }),
                                        "Run it as Administrator",
                                      ],
                                    }),
                                    (0, s.jsxs)("p", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "text-red-500 font-bold text-xl",
                                          children: "3.",
                                        }),
                                        "Take a screenshot of the results",
                                      ],
                                    }),
                                    (0, s.jsxs)("p", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "text-red-500 font-bold text-xl",
                                          children: "4.",
                                        }),
                                        "Send the screenshot to support via Discord ticket",
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
              ],
            }),
          }),
          (0, s.jsx)("section", {
            className:
              "sticky bottom-0 z-40 bg-background/95 backdrop-blur border-t border-border py-6 px-4",
            children: (0, s.jsx)("div", {
              className: "container mx-auto max-w-5xl",
              children: (0, s.jsxs)("div", {
                className: "flex items-center justify-between gap-4",
                children: [
                  (0, s.jsxs)(l.Button, {
                    variant: "outline",
                    size: "lg",
                    onClick: () => {
                      e > 1 &&
                        (g(e - 1),
                        window.scrollTo({ top: 0, behavior: "smooth" }));
                    },
                    disabled: 1 === e,
                    className: "h-14 px-8 text-base bg-transparent",
                    children: [
                      (0, s.jsx)(c.ChevronLeft, { className: "mr-2 h-5 w-5" }),
                      "Back",
                    ],
                  }),
                  (0, s.jsxs)("div", {
                    className: "text-center",
                    children: [
                      (0, s.jsx)("p", {
                        className: "text-sm text-muted-foreground mb-1",
                        children: "Progress",
                      }),
                      (0, s.jsxs)("p", {
                        className: "text-lg font-semibold text-foreground",
                        children: [e, " / ", 6],
                      }),
                    ],
                  }),
                  (0, s.jsx)(l.Button, {
                    size: "lg",
                    onClick: () => {
                      e < 6 &&
                        (g(e + 1),
                        window.scrollTo({ top: 0, behavior: "smooth" }));
                    },
                    disabled: 6 === e,
                    className: "h-14 px-8 text-base",
                    children:
                      6 === e
                        ? (0, s.jsxs)(s.Fragment, {
                            children: [
                              (0, s.jsx)(x.CheckCircle, {
                                className: "mr-2 h-5 w-5",
                              }),
                              "Complete",
                            ],
                          })
                        : (0, s.jsxs)(s.Fragment, {
                            children: [
                              "Continue",
                              (0, s.jsx)(o.ChevronRight, {
                                className: "ml-2 h-5 w-5",
                              }),
                            ],
                          }),
                  }),
                ],
              }),
            }),
          }),
          (0, s.jsx)(a.Footer, {}),
        ],
      });
    }
    e.s(["default", () => g]);
  },
]);
