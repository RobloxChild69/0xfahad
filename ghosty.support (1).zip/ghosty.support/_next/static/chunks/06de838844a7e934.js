(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  60835,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "warnOnce", {
        enumerable: !0,
        get: function () {
          return s;
        },
      });
    let s = (e) => {};
  },
  85260,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      assign: function () {
        return i;
      },
      searchParamsToUrlQuery: function () {
        return a;
      },
      urlQueryToSearchParams: function () {
        return o;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    function a(e) {
      let t = {};
      for (let [r, s] of e.entries()) {
        let e = t[r];
        void 0 === e
          ? (t[r] = s)
          : Array.isArray(e)
          ? e.push(s)
          : (t[r] = [e, s]);
      }
      return t;
    }
    function l(e) {
      return "string" == typeof e
        ? e
        : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e
        ? ""
        : String(e);
    }
    function o(e) {
      let t = new URLSearchParams();
      for (let [r, s] of Object.entries(e))
        if (Array.isArray(s)) for (let e of s) t.append(r, l(e));
        else t.set(r, l(s));
      return t;
    }
    function i(e, ...t) {
      for (let r of t) {
        for (let t of r.keys()) e.delete(t);
        for (let [t, s] of r.entries()) e.append(t, s);
      }
      return e;
    }
  },
  91552,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      formatUrl: function () {
        return o;
      },
      formatWithValidation: function () {
        return c;
      },
      urlObjectKeys: function () {
        return i;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    let a = e.r(44066)._(e.r(85260)),
      l = /https?|ftp|gopher|file/;
    function o(e) {
      let { auth: t, hostname: r } = e,
        s = e.protocol || "",
        n = e.pathname || "",
        o = e.hash || "",
        i = e.query || "",
        c = !1;
      (t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : ""),
        e.host
          ? (c = t + e.host)
          : r &&
            ((c = t + (~r.indexOf(":") ? `[${r}]` : r)),
            e.port && (c += ":" + e.port)),
        i && "object" == typeof i && (i = String(a.urlQueryToSearchParams(i)));
      let d = e.search || (i && `?${i}`) || "";
      return (
        s && !s.endsWith(":") && (s += ":"),
        e.slashes || ((!s || l.test(s)) && !1 !== c)
          ? ((c = "//" + (c || "")), n && "/" !== n[0] && (n = "/" + n))
          : c || (c = ""),
        o && "#" !== o[0] && (o = "#" + o),
        d && "?" !== d[0] && (d = "?" + d),
        (n = n.replace(/[?#]/g, encodeURIComponent)),
        (d = d.replace("#", "%23")),
        `${s}${c}${n}${d}${o}`
      );
    }
    let i = [
      "auth",
      "hash",
      "host",
      "hostname",
      "href",
      "path",
      "pathname",
      "port",
      "protocol",
      "query",
      "search",
      "slashes",
    ];
    function c(e) {
      return o(e);
    }
  },
  60203,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let s = e.r(80883);
    function n(e, t) {
      let r = (0, s.useRef)(null),
        n = (0, s.useRef)(null);
      return (0, s.useCallback)(
        (s) => {
          if (null === s) {
            let e = r.current;
            e && ((r.current = null), e());
            let t = n.current;
            t && ((n.current = null), t());
          } else e && (r.current = a(e, s)), t && (n.current = a(t, s));
        },
        [e, t]
      );
    }
    function a(e, t) {
      if ("function" != typeof e)
        return (
          (e.current = t),
          () => {
            e.current = null;
          }
        );
      {
        let r = e(t);
        return "function" == typeof r ? r : () => e(null);
      }
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  6898,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      DecodeError: function () {
        return g;
      },
      MiddlewareNotFoundError: function () {
        return v;
      },
      MissingStaticPage: function () {
        return N;
      },
      NormalizeError: function () {
        return j;
      },
      PageNotFoundError: function () {
        return b;
      },
      SP: function () {
        return h;
      },
      ST: function () {
        return x;
      },
      WEB_VITALS: function () {
        return a;
      },
      execOnce: function () {
        return l;
      },
      getDisplayName: function () {
        return u;
      },
      getLocationOrigin: function () {
        return c;
      },
      getURL: function () {
        return d;
      },
      isAbsoluteUrl: function () {
        return i;
      },
      isResSent: function () {
        return f;
      },
      loadGetInitialProps: function () {
        return p;
      },
      normalizeRepeatedSlashes: function () {
        return m;
      },
      stringifyError: function () {
        return y;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    let a = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];
    function l(e) {
      let t,
        r = !1;
      return (...s) => (r || ((r = !0), (t = e(...s))), t);
    }
    let o = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
      i = (e) => o.test(e);
    function c() {
      let { protocol: e, hostname: t, port: r } = window.location;
      return `${e}//${t}${r ? ":" + r : ""}`;
    }
    function d() {
      let { href: e } = window.location,
        t = c();
      return e.substring(t.length);
    }
    function u(e) {
      return "string" == typeof e ? e : e.displayName || e.name || "Unknown";
    }
    function f(e) {
      return e.finished || e.headersSent;
    }
    function m(e) {
      let t = e.split("?");
      return (
        t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") +
        (t[1] ? `?${t.slice(1).join("?")}` : "")
      );
    }
    async function p(e, t) {
      let r = t.res || (t.ctx && t.ctx.res);
      if (!e.getInitialProps)
        return t.ctx && t.Component
          ? { pageProps: await p(t.Component, t.ctx) }
          : {};
      let s = await e.getInitialProps(t);
      if (r && f(r)) return s;
      if (!s)
        throw Object.defineProperty(
          Error(
            `"${u(
              e
            )}.getInitialProps()" should resolve to an object. But found "${s}" instead.`
          ),
          "__NEXT_ERROR_CODE",
          { value: "E394", enumerable: !1, configurable: !0 }
        );
      return s;
    }
    let h = "undefined" != typeof performance,
      x =
        h &&
        ["mark", "measure", "getEntriesByName"].every(
          (e) => "function" == typeof performance[e]
        );
    class g extends Error {}
    class j extends Error {}
    class b extends Error {
      constructor(e) {
        super(),
          (this.code = "ENOENT"),
          (this.name = "PageNotFoundError"),
          (this.message = `Cannot find module for page: ${e}`);
      }
    }
    class N extends Error {
      constructor(e, t) {
        super(),
          (this.message = `Failed to load static file for page: ${e} ${t}`);
      }
    }
    class v extends Error {
      constructor() {
        super(),
          (this.code = "ENOENT"),
          (this.message = "Cannot find the middleware module");
      }
    }
    function y(e) {
      return JSON.stringify({ message: e.message, stack: e.stack });
    }
  },
  73350,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    let s = e.r(6898),
      n = e.r(56075);
    function a(e) {
      if (!(0, s.isAbsoluteUrl)(e)) return !0;
      try {
        let t = (0, s.getLocationOrigin)(),
          r = new URL(e, t);
        return r.origin === t && (0, n.hasBasePath)(r.pathname);
      } catch (e) {
        return !1;
      }
    }
  },
  95136,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "errorOnce", {
        enumerable: !0,
        get: function () {
          return s;
        },
      });
    let s = (e) => {};
  },
  61021,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      default: function () {
        return g;
      },
      useLinkStatus: function () {
        return b;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    let a = e.r(44066),
      l = e.r(93046),
      o = a._(e.r(80883)),
      i = e.r(91552),
      c = e.r(89260),
      d = e.r(60203),
      u = e.r(6898),
      f = e.r(63118);
    e.r(60835);
    let m = e.r(68193),
      p = e.r(73350),
      h = e.r(50696);
    function x(e) {
      return "string" == typeof e ? e : (0, i.formatUrl)(e);
    }
    function g(t) {
      var r;
      let s,
        n,
        a,
        [i, g] = (0, o.useOptimistic)(m.IDLE_LINK_STATUS),
        b = (0, o.useRef)(null),
        {
          href: N,
          as: v,
          children: y,
          prefetch: w = null,
          passHref: P,
          replace: k,
          shallow: C,
          scroll: _,
          onClick: O,
          onMouseEnter: T,
          onTouchStart: A,
          legacyBehavior: E = !1,
          onNavigate: S,
          ref: D,
          unstable_dynamicOnHover: M,
          ...R
        } = t;
      (s = y),
        E &&
          ("string" == typeof s || "number" == typeof s) &&
          (s = (0, l.jsx)("a", { children: s }));
      let $ = o.default.useContext(c.AppRouterContext),
        L = !1 !== w,
        I =
          !1 !== w
            ? null === (r = w) || "auto" === r
              ? h.FetchStrategy.PPR
              : h.FetchStrategy.Full
            : h.FetchStrategy.PPR,
        { href: B, as: F } = o.default.useMemo(() => {
          let e = x(N);
          return { href: e, as: v ? x(v) : e };
        }, [N, v]);
      if (E) {
        if (s?.$$typeof === Symbol.for("react.lazy"))
          throw Object.defineProperty(
            Error(
              "`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."
            ),
            "__NEXT_ERROR_CODE",
            { value: "E863", enumerable: !1, configurable: !0 }
          );
        n = o.default.Children.only(s);
      }
      let U = E ? n && "object" == typeof n && n.ref : D,
        z = o.default.useCallback(
          (e) => (
            null !== $ &&
              (b.current = (0, m.mountLinkInstance)(e, B, $, I, L, g)),
            () => {
              b.current &&
                ((0, m.unmountLinkForCurrentNavigation)(b.current),
                (b.current = null)),
                (0, m.unmountPrefetchableInstance)(e);
            }
          ),
          [L, B, $, I, g]
        ),
        K = {
          ref: (0, d.useMergedRef)(z, U),
          onClick(t) {
            E || "function" != typeof O || O(t),
              E &&
                n.props &&
                "function" == typeof n.props.onClick &&
                n.props.onClick(t),
              !$ ||
                t.defaultPrevented ||
                (function (t, r, s, n, a, l, i) {
                  if ("undefined" != typeof window) {
                    let c,
                      { nodeName: d } = t.currentTarget;
                    if (
                      ("A" === d.toUpperCase() &&
                        (((c = t.currentTarget.getAttribute("target")) &&
                          "_self" !== c) ||
                          t.metaKey ||
                          t.ctrlKey ||
                          t.shiftKey ||
                          t.altKey ||
                          (t.nativeEvent && 2 === t.nativeEvent.which))) ||
                      t.currentTarget.hasAttribute("download")
                    )
                      return;
                    if (!(0, p.isLocalURL)(r)) {
                      a && (t.preventDefault(), location.replace(r));
                      return;
                    }
                    if ((t.preventDefault(), i)) {
                      let e = !1;
                      if (
                        (i({
                          preventDefault: () => {
                            e = !0;
                          },
                        }),
                        e)
                      )
                        return;
                    }
                    let { dispatchNavigateAction: u } = e.r(56797);
                    o.default.startTransition(() => {
                      u(s || r, a ? "replace" : "push", l ?? !0, n.current);
                    });
                  }
                })(t, B, F, b, k, _, S);
          },
          onMouseEnter(e) {
            E || "function" != typeof T || T(e),
              E &&
                n.props &&
                "function" == typeof n.props.onMouseEnter &&
                n.props.onMouseEnter(e),
              $ && L && (0, m.onNavigationIntent)(e.currentTarget, !0 === M);
          },
          onTouchStart: function (e) {
            E || "function" != typeof A || A(e),
              E &&
                n.props &&
                "function" == typeof n.props.onTouchStart &&
                n.props.onTouchStart(e),
              $ && L && (0, m.onNavigationIntent)(e.currentTarget, !0 === M);
          },
        };
      return (
        (0, u.isAbsoluteUrl)(F)
          ? (K.href = F)
          : (E && !P && ("a" !== n.type || "href" in n.props)) ||
            (K.href = (0, f.addBasePath)(F)),
        (a = E
          ? o.default.cloneElement(n, K)
          : (0, l.jsx)("a", { ...R, ...K, children: s })),
        (0, l.jsx)(j.Provider, { value: i, children: a })
      );
    }
    e.r(95136);
    let j = (0, o.createContext)(m.IDLE_LINK_STATUS),
      b = () => (0, o.useContext)(j);
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  84675,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("ArrowLeft", [
      ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
      ["path", { d: "M19 12H5", key: "x3x0zl" }],
    ]);
    e.s(["ArrowLeft", () => t], 84675);
  },
  13637,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Download", [
      [
        "path",
        { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
      ],
      ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
      ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }],
    ]);
    e.s(["Download", () => t], 13637);
  },
  81947,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(94237),
      s = e.i(47163);
    let n = (0, r.cva)(
      "relative w-full rounded-lg border px-4 py-3 text-sm grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current",
      {
        variants: {
          variant: {
            default: "bg-card text-card-foreground",
            destructive:
              "text-destructive bg-card [&>svg]:text-current *:data-[slot=alert-description]:text-destructive/90",
          },
        },
        defaultVariants: { variant: "default" },
      }
    );
    function a({ className: e, variant: r, ...a }) {
      return (0, t.jsx)("div", {
        "data-slot": "alert",
        role: "alert",
        className: (0, s.cn)(n({ variant: r }), e),
        ...a,
      });
    }
    function l({ className: e, ...r }) {
      return (0, t.jsx)("div", {
        "data-slot": "alert-description",
        className: (0, s.cn)(
          "text-muted-foreground col-start-2 grid justify-items-start gap-1 text-sm [&_p]:leading-relaxed",
          e
        ),
        ...r,
      });
    }
    e.s(["Alert", () => a, "AlertDescription", () => l]);
  },
  64877,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("TriangleAlert", [
      [
        "path",
        {
          d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
          key: "wmoenq",
        },
      ],
      ["path", { d: "M12 9v4", key: "juzpu7" }],
      ["path", { d: "M12 17h.01", key: "p32p05" }],
    ]);
    e.s(["AlertTriangle", () => t], 64877);
  },
  70065,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(47163);
    function s({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card",
        className: (0, r.cn)(
          "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",
          e
        ),
        ...s,
      });
    }
    function n({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-header",
        className: (0, r.cn)(
          "@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6",
          e
        ),
        ...s,
      });
    }
    function a({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-title",
        className: (0, r.cn)("leading-none font-semibold", e),
        ...s,
      });
    }
    function l({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-description",
        className: (0, r.cn)("text-muted-foreground text-sm", e),
        ...s,
      });
    }
    function o({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-content",
        className: (0, r.cn)("px-6", e),
        ...s,
      });
    }
    e.s([
      "Card",
      () => s,
      "CardContent",
      () => o,
      "CardDescription",
      () => l,
      "CardHeader",
      () => n,
      "CardTitle",
      () => a,
    ]);
  },
  13942,
  4786,
  (e) => {
    "use strict";
    var t = e.i(80883),
      r = e.i(93046);
    function s(e, s) {
      let n = t.createContext(s),
        a = (e) => {
          let { children: s, ...a } = e,
            l = t.useMemo(() => a, Object.values(a));
          return (0, r.jsx)(n.Provider, { value: l, children: s });
        };
      return (
        (a.displayName = e + "Provider"),
        [
          a,
          function (r) {
            let a = t.useContext(n);
            if (a) return a;
            if (void 0 !== s) return s;
            throw Error(`\`${r}\` must be used within \`${e}\``);
          },
        ]
      );
    }
    function n(e, s = []) {
      let a = [],
        l = () => {
          let r = a.map((e) => t.createContext(e));
          return function (s) {
            let n = s?.[e] || r;
            return t.useMemo(
              () => ({ [`__scope${e}`]: { ...s, [e]: n } }),
              [s, n]
            );
          };
        };
      return (
        (l.scopeName = e),
        [
          function (s, n) {
            let l = t.createContext(n),
              o = a.length;
            a = [...a, n];
            let i = (s) => {
              let { scope: n, children: a, ...i } = s,
                c = n?.[e]?.[o] || l,
                d = t.useMemo(() => i, Object.values(i));
              return (0, r.jsx)(c.Provider, { value: d, children: a });
            };
            return (
              (i.displayName = s + "Provider"),
              [
                i,
                function (r, a) {
                  let i = a?.[e]?.[o] || l,
                    c = t.useContext(i);
                  if (c) return c;
                  if (void 0 !== n) return n;
                  throw Error(`\`${r}\` must be used within \`${s}\``);
                },
              ]
            );
          },
          (function (...e) {
            let r = e[0];
            if (1 === e.length) return r;
            let s = () => {
              let s = e.map((e) => ({ useScope: e(), scopeName: e.scopeName }));
              return function (e) {
                let n = s.reduce((t, { useScope: r, scopeName: s }) => {
                  let n = r(e)[`__scope${s}`];
                  return { ...t, ...n };
                }, {});
                return t.useMemo(() => ({ [`__scope${r.scopeName}`]: n }), [n]);
              };
            };
            return (s.scopeName = r.scopeName), s;
          })(l, ...s),
        ]
      );
    }
    e.s(["createContext", () => s, "createContextScope", () => n], 13942);
    var a = e.i(36425),
      l = e.i(87576),
      o = [
        "a",
        "button",
        "div",
        "form",
        "h2",
        "h3",
        "img",
        "input",
        "label",
        "li",
        "nav",
        "ol",
        "p",
        "span",
        "svg",
        "ul",
      ].reduce((e, s) => {
        let n = t.forwardRef((e, t) => {
          let { asChild: n, ...a } = e,
            o = n ? l.Slot : s;
          return (
            "undefined" != typeof window &&
              (window[Symbol.for("radix-ui")] = !0),
            (0, r.jsx)(o, { ...a, ref: t })
          );
        });
        return (n.displayName = `Primitive.${s}`), { ...e, [s]: n };
      }, {});
    function i(e, t) {
      e && a.flushSync(() => e.dispatchEvent(t));
    }
    e.s(["Primitive", () => o, "dispatchDiscreteCustomEvent", () => i], 4786);
  },
  93115,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(80883),
      s = e.i(61021),
      n = e.i(84675),
      a = e.i(13637),
      l = e.i(64877);
    let o = (0, e.i(10965).default)("Check", [
      ["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }],
    ]);
    var i = e.i(67881),
      c = e.i(81947),
      d = e.i(70065),
      u = e.i(13942),
      f = e.i(4786),
      m = "Progress",
      [p, h] = (0, u.createContextScope)(m),
      [x, g] = p(m),
      j = r.forwardRef((e, r) => {
        var s, n;
        let {
          __scopeProgress: a,
          value: l = null,
          max: o,
          getValueLabel: i = v,
          ...c
        } = e;
        (o || 0 === o) &&
          !P(o) &&
          console.error(
            ((s = `${o}`),
            `Invalid prop \`max\` of value \`${s}\` supplied to \`Progress\`. Only numbers greater than 0 are valid max values. Defaulting to \`100\`.`)
          );
        let d = P(o) ? o : 100;
        null === l ||
          k(l, d) ||
          console.error(
            ((n = `${l}`),
            `Invalid prop \`value\` of value \`${n}\` supplied to \`Progress\`. The \`value\` prop must be:
  - a positive number
  - less than the value passed to \`max\` (or 100 if no \`max\` prop is set)
  - \`null\` or \`undefined\` if the progress is indeterminate.

Defaulting to \`null\`.`)
          );
        let u = k(l, d) ? l : null,
          m = w(u) ? i(u, d) : void 0;
        return (0, t.jsx)(x, {
          scope: a,
          value: u,
          max: d,
          children: (0, t.jsx)(f.Primitive.div, {
            "aria-valuemax": d,
            "aria-valuemin": 0,
            "aria-valuenow": w(u) ? u : void 0,
            "aria-valuetext": m,
            role: "progressbar",
            "data-state": y(u, d),
            "data-value": u ?? void 0,
            "data-max": d,
            ...c,
            ref: r,
          }),
        });
      });
    j.displayName = m;
    var b = "ProgressIndicator",
      N = r.forwardRef((e, r) => {
        let { __scopeProgress: s, ...n } = e,
          a = g(b, s);
        return (0, t.jsx)(f.Primitive.div, {
          "data-state": y(a.value, a.max),
          "data-value": a.value ?? void 0,
          "data-max": a.max,
          ...n,
          ref: r,
        });
      });
    function v(e, t) {
      return `${Math.round((e / t) * 100)}%`;
    }
    function y(e, t) {
      return null == e ? "indeterminate" : e === t ? "complete" : "loading";
    }
    function w(e) {
      return "number" == typeof e;
    }
    function P(e) {
      return w(e) && !isNaN(e) && e > 0;
    }
    function k(e, t) {
      return w(e) && !isNaN(e) && e <= t && e >= 0;
    }
    N.displayName = b;
    var C = e.i(47163);
    function _({ className: e, value: r, ...s }) {
      return (0, t.jsx)(j, {
        "data-slot": "progress",
        className: (0, C.cn)(
          "bg-primary/20 relative h-2 w-full overflow-hidden rounded-full",
          e
        ),
        ...s,
        children: (0, t.jsx)(N, {
          "data-slot": "progress-indicator",
          className: "bg-primary h-full w-full flex-1 transition-all",
          style: { transform: `translateX(-${100 - (r || 0)}%)` },
        }),
      });
    }
    function O() {
      let [e, u] = (0, r.useState)(1),
        f = (e / 5) * 100;
      return (0, t.jsxs)("div", {
        className: "min-h-screen bg-background",
        children: [
          (0, t.jsx)("header", {
            className:
              "sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60",
            children: (0, t.jsxs)("div", {
              className: "container flex h-16 items-center justify-between",
              children: [
                (0, t.jsxs)(s.default, {
                  href: "/",
                  className:
                    "flex items-center gap-2 text-foreground hover:text-primary transition-colors",
                  children: [
                    (0, t.jsx)(n.ArrowLeft, { className: "h-5 w-5" }),
                    (0, t.jsx)("span", {
                      className: "font-semibold",
                      children: "Back to Home",
                    }),
                  ],
                }),
                (0, t.jsx)("div", {
                  className: "text-xl font-bold text-primary",
                  children: "GHOSTY Services",
                }),
              ],
            }),
          }),
          (0, t.jsxs)("main", {
            className: "container mx-auto px-4 py-12 max-w-4xl",
            children: [
              (0, t.jsxs)("div", {
                className: "mb-8",
                children: [
                  (0, t.jsx)("h1", {
                    className: "text-4xl font-bold mb-4 text-foreground",
                    children: "Delta Force Setup Guide",
                  }),
                  (0, t.jsx)("p", {
                    className: "text-muted-foreground text-lg text-pretty",
                    children:
                      "Follow these steps carefully to set up Delta Force",
                  }),
                ],
              }),
              (0, t.jsxs)("div", {
                className: "mb-8",
                children: [
                  (0, t.jsxs)("div", {
                    className: "flex justify-between items-center mb-2",
                    children: [
                      (0, t.jsxs)("span", {
                        className: "text-sm font-medium text-muted-foreground",
                        children: ["Step ", e, " of ", 5],
                      }),
                      (0, t.jsxs)("span", {
                        className: "text-sm font-medium text-primary",
                        children: [Math.round(f), "% Complete"],
                      }),
                    ],
                  }),
                  (0, t.jsx)(_, { value: f, className: "h-2" }),
                ],
              }),
              (0, t.jsxs)("div", {
                className: "space-y-6 animate-in fade-in duration-300",
                children: [
                  1 === e &&
                    (0, t.jsxs)(d.Card, {
                      className: "p-8",
                      children: [
                        (0, t.jsxs)("div", {
                          className: "flex items-start gap-4 mb-6",
                          children: [
                            (0, t.jsx)("div", {
                              className:
                                "flex-shrink-0 w-12 h-12 rounded-full bg-red-500/10 flex items-center justify-center",
                              children: (0, t.jsx)(l.AlertTriangle, {
                                className: "h-6 w-6 text-red-500",
                              }),
                            }),
                            (0, t.jsxs)("div", {
                              children: [
                                (0, t.jsx)("h2", {
                                  className:
                                    "text-2xl font-bold mb-2 text-foreground",
                                  children: "Important Notice",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children: "Before starting the setup",
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, t.jsxs)(c.Alert, {
                          className: "mb-6 border-red-500/50 bg-red-500/10",
                          children: [
                            (0, t.jsx)(l.AlertTriangle, {
                              className: "h-4 w-4 text-red-500",
                            }),
                            (0, t.jsx)(c.AlertDescription, {
                              className: "text-red-500",
                              children:
                                "Make sure the Game Launcher and Game are completely closed before starting",
                            }),
                          ],
                        }),
                        (0, t.jsxs)("div", {
                          className: "space-y-4 bg-secondary/30 rounded-lg p-6",
                          children: [
                            (0, t.jsxs)("div", {
                              className: "flex items-start gap-3",
                              children: [
                                (0, t.jsx)(o, {
                                  className:
                                    "h-5 w-5 text-primary mt-0.5 flex-shrink-0",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children:
                                    "Close Delta Force game if it's running",
                                }),
                              ],
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex items-start gap-3",
                              children: [
                                (0, t.jsx)(o, {
                                  className:
                                    "h-5 w-5 text-primary mt-0.5 flex-shrink-0",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children:
                                    "Close the game launcher completely",
                                }),
                              ],
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex items-start gap-3",
                              children: [
                                (0, t.jsx)(o, {
                                  className:
                                    "h-5 w-5 text-primary mt-0.5 flex-shrink-0",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children:
                                    "Make sure no game processes are running in Task Manager",
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  2 === e &&
                    (0, t.jsxs)(d.Card, {
                      className: "p-8",
                      children: [
                        (0, t.jsxs)("div", {
                          className: "flex items-start gap-4 mb-6",
                          children: [
                            (0, t.jsx)("div", {
                              className:
                                "flex-shrink-0 w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center",
                              children: (0, t.jsx)("span", {
                                className: "text-2xl font-bold text-blue-500",
                                children: "2",
                              }),
                            }),
                            (0, t.jsxs)("div", {
                              children: [
                                (0, t.jsx)("h2", {
                                  className:
                                    "text-2xl font-bold mb-2 text-foreground",
                                  children: "Install NordVPN",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children:
                                    "Required for security (Free to use)",
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, t.jsxs)(c.Alert, {
                          className: "mb-6 border-primary/50 bg-primary/10",
                          children: [
                            (0, t.jsx)(l.AlertTriangle, {
                              className: "h-4 w-4 text-primary",
                            }),
                            (0, t.jsx)(c.AlertDescription, {
                              className: "text-foreground",
                              children:
                                "IMPORTANT: Install NordVPN and keep it open when using the cheat. No need to buy it, just install and run - it's free!",
                            }),
                          ],
                        }),
                        (0, t.jsxs)("div", {
                          className: "space-y-4",
                          children: [
                            (0, t.jsxs)("div", {
                              className:
                                "bg-secondary/30 rounded-lg p-6 space-y-3",
                              children: [
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children:
                                    "→ Download and install NordVPN from their official website",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children:
                                    "→ Open NordVPN (no account or payment needed)",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children:
                                    "→ Keep NordVPN running in the background",
                                }),
                              ],
                            }),
                            (0, t.jsx)(i.Button, {
                              asChild: !0,
                              className: "w-full",
                              size: "lg",
                              children: (0, t.jsxs)("a", {
                                href: "https://nordvpn.com/",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: [
                                  (0, t.jsx)(a.Download, {
                                    className: "mr-2 h-5 w-5",
                                  }),
                                  "Download NordVPN",
                                ],
                              }),
                            }),
                          ],
                        }),
                      ],
                    }),
                  3 === e &&
                    (0, t.jsxs)(d.Card, {
                      className: "p-8",
                      children: [
                        (0, t.jsxs)("div", {
                          className: "flex items-start gap-4 mb-6",
                          children: [
                            (0, t.jsx)("div", {
                              className:
                                "flex-shrink-0 w-12 h-12 rounded-full bg-purple-500/10 flex items-center justify-center",
                              children: (0, t.jsx)("span", {
                                className: "text-2xl font-bold text-purple-500",
                                children: "3",
                              }),
                            }),
                            (0, t.jsxs)("div", {
                              children: [
                                (0, t.jsx)("h2", {
                                  className:
                                    "text-2xl font-bold mb-2 text-foreground",
                                  children: "Install and Run Loader",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children: "Download and extract the loader",
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, t.jsxs)("div", {
                          className: "space-y-4",
                          children: [
                            (0, t.jsxs)("div", {
                              className:
                                "bg-secondary/30 rounded-lg p-6 space-y-3",
                              children: [
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children:
                                    "→ Download the loader from the link below",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children: "→ Extract the files to a folder",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children: "→ Run the loader as Administrator",
                                }),
                              ],
                            }),
                            (0, t.jsx)(i.Button, {
                              asChild: !0,
                              className: "w-full",
                              size: "lg",
                              children: (0, t.jsxs)("a", {
                                href: "https://mega.nz/folder/I21UGKpI#wiZrUW-hgkt_G3ay7pZ8NA",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: [
                                  (0, t.jsx)(a.Download, {
                                    className: "mr-2 h-5 w-5",
                                  }),
                                  "Download Loader",
                                ],
                              }),
                            }),
                          ],
                        }),
                      ],
                    }),
                  4 === e &&
                    (0, t.jsxs)(d.Card, {
                      className: "p-8",
                      children: [
                        (0, t.jsxs)("div", {
                          className: "flex items-start gap-4 mb-6",
                          children: [
                            (0, t.jsx)("div", {
                              className:
                                "flex-shrink-0 w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center",
                              children: (0, t.jsx)("span", {
                                className: "text-2xl font-bold text-green-500",
                                children: "4",
                              }),
                            }),
                            (0, t.jsxs)("div", {
                              children: [
                                (0, t.jsx)("h2", {
                                  className:
                                    "text-2xl font-bold mb-2 text-foreground",
                                  children: "Launch Game & Enjoy",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children: "Start playing with the cheat",
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, t.jsxs)("div", {
                          className: "space-y-6",
                          children: [
                            (0, t.jsxs)("div", {
                              className:
                                "bg-secondary/30 rounded-lg p-6 space-y-3",
                              children: [
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children:
                                    "→ With the loader running, start Delta Force",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children: "→ Wait for the game to fully load",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children:
                                    "→ The cheat should automatically inject",
                                }),
                              ],
                            }),
                            (0, t.jsxs)(c.Alert, {
                              className: "border-green-500/50 bg-green-500/10",
                              children: [
                                (0, t.jsx)(o, {
                                  className: "h-4 w-4 text-green-500",
                                }),
                                (0, t.jsxs)(c.AlertDescription, {
                                  className: "text-foreground",
                                  children: [
                                    (0, t.jsx)("strong", {
                                      children: "Important:",
                                    }),
                                    " Make sure your game resolution is set to Borderless Window mode",
                                  ],
                                }),
                              ],
                            }),
                            (0, t.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6",
                              children: [
                                (0, t.jsx)("h3", {
                                  className:
                                    "font-semibold mb-3 text-foreground",
                                  children: "Menu Controls",
                                }),
                                (0, t.jsx)("div", {
                                  className: "space-y-2",
                                  children: (0, t.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [
                                      (0, t.jsx)("kbd", {
                                        className:
                                          "px-3 py-1.5 text-sm font-semibold bg-secondary border border-border rounded",
                                        children: "INSERT",
                                      }),
                                      (0, t.jsx)("span", {
                                        className: "text-muted-foreground",
                                        children: "Open / Close menu",
                                      }),
                                    ],
                                  }),
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  5 === e &&
                    (0, t.jsxs)(d.Card, {
                      className: "p-8",
                      children: [
                        (0, t.jsxs)("div", {
                          className: "flex items-start gap-4 mb-6",
                          children: [
                            (0, t.jsx)("div", {
                              className:
                                "flex-shrink-0 w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center",
                              children: (0, t.jsx)(l.AlertTriangle, {
                                className: "h-6 w-6 text-amber-500",
                              }),
                            }),
                            (0, t.jsxs)("div", {
                              children: [
                                (0, t.jsx)("h2", {
                                  className:
                                    "text-2xl font-bold mb-2 text-foreground",
                                  children: "Error Fix & Troubleshooting",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground",
                                  children: "Common issues and solutions",
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, t.jsxs)(c.Alert, {
                          className: "mb-6 border-amber-500/50 bg-amber-500/10",
                          children: [
                            (0, t.jsx)(l.AlertTriangle, {
                              className: "h-4 w-4 text-amber-500",
                            }),
                            (0, t.jsx)(c.AlertDescription, {
                              className: "text-amber-500",
                              children:
                                "If you're having issues launching the cheat or it's not working in the game",
                            }),
                          ],
                        }),
                        (0, t.jsxs)("div", {
                          className: "space-y-4",
                          children: [
                            (0, t.jsxs)("div", {
                              className: "bg-secondary/30 rounded-lg p-6",
                              children: [
                                (0, t.jsx)("h3", {
                                  className:
                                    "font-semibold mb-4 text-foreground",
                                  children: "Diagnostic Tool",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground mb-4",
                                  children:
                                    "Download this diagnostic file, run it, and send a screenshot to our support ticket for assistance:",
                                }),
                                (0, t.jsx)(i.Button, {
                                  asChild: !0,
                                  className: "w-full bg-transparent",
                                  variant: "outline",
                                  size: "lg",
                                  children: (0, t.jsxs)("a", {
                                    href: "https://mega.nz/file/FzclQSDC#2iKnZBOmkBOwttKpnRa-BLo21LOZfgFPS_HkDG7DveU",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, t.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Diagnostic Tool",
                                    ],
                                  }),
                                }),
                              ],
                            }),
                            (0, t.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6",
                              children: [
                                (0, t.jsx)("h3", {
                                  className:
                                    "font-semibold mb-3 text-foreground",
                                  children: "Common Fixes",
                                }),
                                (0, t.jsxs)("ul", {
                                  className: "space-y-2 text-muted-foreground",
                                  children: [
                                    (0, t.jsxs)("li", {
                                      className: "flex items-start gap-2",
                                      children: [
                                        (0, t.jsx)("span", {
                                          className: "text-primary mt-1",
                                          children: "•",
                                        }),
                                        (0, t.jsx)("span", {
                                          children:
                                            "Make sure NordVPN is running",
                                        }),
                                      ],
                                    }),
                                    (0, t.jsxs)("li", {
                                      className: "flex items-start gap-2",
                                      children: [
                                        (0, t.jsx)("span", {
                                          className: "text-primary mt-1",
                                          children: "•",
                                        }),
                                        (0, t.jsx)("span", {
                                          children:
                                            "Run the loader as Administrator",
                                        }),
                                      ],
                                    }),
                                    (0, t.jsxs)("li", {
                                      className: "flex items-start gap-2",
                                      children: [
                                        (0, t.jsx)("span", {
                                          className: "text-primary mt-1",
                                          children: "•",
                                        }),
                                        (0, t.jsx)("span", {
                                          children:
                                            "Disable antivirus software temporarily",
                                        }),
                                      ],
                                    }),
                                    (0, t.jsxs)("li", {
                                      className: "flex items-start gap-2",
                                      children: [
                                        (0, t.jsx)("span", {
                                          className: "text-primary mt-1",
                                          children: "•",
                                        }),
                                        (0, t.jsx)("span", {
                                          children:
                                            "Make sure game is in Borderless Window mode",
                                        }),
                                      ],
                                    }),
                                    (0, t.jsxs)("li", {
                                      className: "flex items-start gap-2",
                                      children: [
                                        (0, t.jsx)("span", {
                                          className: "text-primary mt-1",
                                          children: "•",
                                        }),
                                        (0, t.jsx)("span", {
                                          children:
                                            "Restart your PC and try again",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                ],
              }),
              (0, t.jsxs)("div", {
                className:
                  "sticky bottom-4 mt-8 flex gap-4 bg-background/95 backdrop-blur p-4 rounded-lg border border-border",
                children: [
                  (0, t.jsxs)(i.Button, {
                    onClick: () => {
                      e > 1 &&
                        (u(e - 1),
                        window.scrollTo({ top: 0, behavior: "smooth" }));
                    },
                    disabled: 1 === e,
                    variant: "outline",
                    className: "flex-1 bg-transparent",
                    size: "lg",
                    children: [
                      (0, t.jsx)(n.ArrowLeft, { className: "mr-2 h-4 w-4" }),
                      "Back",
                    ],
                  }),
                  (0, t.jsxs)(i.Button, {
                    onClick: () => {
                      e < 5 &&
                        (u(e + 1),
                        window.scrollTo({ top: 0, behavior: "smooth" }));
                    },
                    disabled: 5 === e,
                    className: "flex-1",
                    size: "lg",
                    children: [
                      5 === e ? "Completed" : "Continue",
                      5 !== e && (0, t.jsx)(o, { className: "ml-2 h-4 w-4" }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      });
    }
    e.s(["default", () => O], 93115);
  },
]);
