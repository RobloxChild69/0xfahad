(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  60835,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "warnOnce", {
        enumerable: !0,
        get: function () {
          return s;
        },
      });
    let s = (e) => {};
  },
  85260,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      assign: function () {
        return i;
      },
      searchParamsToUrlQuery: function () {
        return n;
      },
      urlQueryToSearchParams: function () {
        return o;
      },
    };
    for (var a in s) Object.defineProperty(r, a, { enumerable: !0, get: s[a] });
    function n(e) {
      let t = {};
      for (let [r, s] of e.entries()) {
        let e = t[r];
        void 0 === e
          ? (t[r] = s)
          : Array.isArray(e)
          ? e.push(s)
          : (t[r] = [e, s]);
      }
      return t;
    }
    function l(e) {
      return "string" == typeof e
        ? e
        : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e
        ? ""
        : String(e);
    }
    function o(e) {
      let t = new URLSearchParams();
      for (let [r, s] of Object.entries(e))
        if (Array.isArray(s)) for (let e of s) t.append(r, l(e));
        else t.set(r, l(s));
      return t;
    }
    function i(e, ...t) {
      for (let r of t) {
        for (let t of r.keys()) e.delete(t);
        for (let [t, s] of r.entries()) e.append(t, s);
      }
      return e;
    }
  },
  91552,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      formatUrl: function () {
        return o;
      },
      formatWithValidation: function () {
        return d;
      },
      urlObjectKeys: function () {
        return i;
      },
    };
    for (var a in s) Object.defineProperty(r, a, { enumerable: !0, get: s[a] });
    let n = e.r(44066)._(e.r(85260)),
      l = /https?|ftp|gopher|file/;
    function o(e) {
      let { auth: t, hostname: r } = e,
        s = e.protocol || "",
        a = e.pathname || "",
        o = e.hash || "",
        i = e.query || "",
        d = !1;
      (t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : ""),
        e.host
          ? (d = t + e.host)
          : r &&
            ((d = t + (~r.indexOf(":") ? `[${r}]` : r)),
            e.port && (d += ":" + e.port)),
        i && "object" == typeof i && (i = String(n.urlQueryToSearchParams(i)));
      let c = e.search || (i && `?${i}`) || "";
      return (
        s && !s.endsWith(":") && (s += ":"),
        e.slashes || ((!s || l.test(s)) && !1 !== d)
          ? ((d = "//" + (d || "")), a && "/" !== a[0] && (a = "/" + a))
          : d || (d = ""),
        o && "#" !== o[0] && (o = "#" + o),
        c && "?" !== c[0] && (c = "?" + c),
        (a = a.replace(/[?#]/g, encodeURIComponent)),
        (c = c.replace("#", "%23")),
        `${s}${d}${a}${c}${o}`
      );
    }
    let i = [
      "auth",
      "hash",
      "host",
      "hostname",
      "href",
      "path",
      "pathname",
      "port",
      "protocol",
      "query",
      "search",
      "slashes",
    ];
    function d(e) {
      return o(e);
    }
  },
  60203,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    let s = e.r(80883);
    function a(e, t) {
      let r = (0, s.useRef)(null),
        a = (0, s.useRef)(null);
      return (0, s.useCallback)(
        (s) => {
          if (null === s) {
            let e = r.current;
            e && ((r.current = null), e());
            let t = a.current;
            t && ((a.current = null), t());
          } else e && (r.current = n(e, s)), t && (a.current = n(t, s));
        },
        [e, t]
      );
    }
    function n(e, t) {
      if ("function" != typeof e)
        return (
          (e.current = t),
          () => {
            e.current = null;
          }
        );
      {
        let r = e(t);
        return "function" == typeof r ? r : () => e(null);
      }
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  6898,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      DecodeError: function () {
        return g;
      },
      MiddlewareNotFoundError: function () {
        return y;
      },
      MissingStaticPage: function () {
        return N;
      },
      NormalizeError: function () {
        return b;
      },
      PageNotFoundError: function () {
        return j;
      },
      SP: function () {
        return f;
      },
      ST: function () {
        return p;
      },
      WEB_VITALS: function () {
        return n;
      },
      execOnce: function () {
        return l;
      },
      getDisplayName: function () {
        return x;
      },
      getLocationOrigin: function () {
        return d;
      },
      getURL: function () {
        return c;
      },
      isAbsoluteUrl: function () {
        return i;
      },
      isResSent: function () {
        return u;
      },
      loadGetInitialProps: function () {
        return h;
      },
      normalizeRepeatedSlashes: function () {
        return m;
      },
      stringifyError: function () {
        return v;
      },
    };
    for (var a in s) Object.defineProperty(r, a, { enumerable: !0, get: s[a] });
    let n = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];
    function l(e) {
      let t,
        r = !1;
      return (...s) => (r || ((r = !0), (t = e(...s))), t);
    }
    let o = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
      i = (e) => o.test(e);
    function d() {
      let { protocol: e, hostname: t, port: r } = window.location;
      return `${e}//${t}${r ? ":" + r : ""}`;
    }
    function c() {
      let { href: e } = window.location,
        t = d();
      return e.substring(t.length);
    }
    function x(e) {
      return "string" == typeof e ? e : e.displayName || e.name || "Unknown";
    }
    function u(e) {
      return e.finished || e.headersSent;
    }
    function m(e) {
      let t = e.split("?");
      return (
        t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") +
        (t[1] ? `?${t.slice(1).join("?")}` : "")
      );
    }
    async function h(e, t) {
      let r = t.res || (t.ctx && t.ctx.res);
      if (!e.getInitialProps)
        return t.ctx && t.Component
          ? { pageProps: await h(t.Component, t.ctx) }
          : {};
      let s = await e.getInitialProps(t);
      if (r && u(r)) return s;
      if (!s)
        throw Object.defineProperty(
          Error(
            `"${x(
              e
            )}.getInitialProps()" should resolve to an object. But found "${s}" instead.`
          ),
          "__NEXT_ERROR_CODE",
          { value: "E394", enumerable: !1, configurable: !0 }
        );
      return s;
    }
    let f = "undefined" != typeof performance,
      p =
        f &&
        ["mark", "measure", "getEntriesByName"].every(
          (e) => "function" == typeof performance[e]
        );
    class g extends Error {}
    class b extends Error {}
    class j extends Error {
      constructor(e) {
        super(),
          (this.code = "ENOENT"),
          (this.name = "PageNotFoundError"),
          (this.message = `Cannot find module for page: ${e}`);
      }
    }
    class N extends Error {
      constructor(e, t) {
        super(),
          (this.message = `Failed to load static file for page: ${e} ${t}`);
      }
    }
    class y extends Error {
      constructor() {
        super(),
          (this.code = "ENOENT"),
          (this.message = "Cannot find the middleware module");
      }
    }
    function v(e) {
      return JSON.stringify({ message: e.message, stack: e.stack });
    }
  },
  73350,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let s = e.r(6898),
      a = e.r(56075);
    function n(e) {
      if (!(0, s.isAbsoluteUrl)(e)) return !0;
      try {
        let t = (0, s.getLocationOrigin)(),
          r = new URL(e, t);
        return r.origin === t && (0, a.hasBasePath)(r.pathname);
      } catch (e) {
        return !1;
      }
    }
  },
  95136,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "errorOnce", {
        enumerable: !0,
        get: function () {
          return s;
        },
      });
    let s = (e) => {};
  },
  61021,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      default: function () {
        return g;
      },
      useLinkStatus: function () {
        return j;
      },
    };
    for (var a in s) Object.defineProperty(r, a, { enumerable: !0, get: s[a] });
    let n = e.r(44066),
      l = e.r(93046),
      o = n._(e.r(80883)),
      i = e.r(91552),
      d = e.r(89260),
      c = e.r(60203),
      x = e.r(6898),
      u = e.r(63118);
    e.r(60835);
    let m = e.r(68193),
      h = e.r(73350),
      f = e.r(50696);
    function p(e) {
      return "string" == typeof e ? e : (0, i.formatUrl)(e);
    }
    function g(t) {
      var r;
      let s,
        a,
        n,
        [i, g] = (0, o.useOptimistic)(m.IDLE_LINK_STATUS),
        j = (0, o.useRef)(null),
        {
          href: N,
          as: y,
          children: v,
          prefetch: w = null,
          passHref: C,
          replace: k,
          shallow: D,
          scroll: S,
          onClick: P,
          onMouseEnter: O,
          onTouchStart: T,
          legacyBehavior: M = !1,
          onNavigate: _,
          ref: A,
          unstable_dynamicOnHover: E,
          ...I
        } = t;
      (s = v),
        M &&
          ("string" == typeof s || "number" == typeof s) &&
          (s = (0, l.jsx)("a", { children: s }));
      let B = o.default.useContext(d.AppRouterContext),
        L = !1 !== w,
        R =
          !1 !== w
            ? null === (r = w) || "auto" === r
              ? f.FetchStrategy.PPR
              : f.FetchStrategy.Full
            : f.FetchStrategy.PPR,
        { href: z, as: F } = o.default.useMemo(() => {
          let e = p(N);
          return { href: e, as: y ? p(y) : e };
        }, [N, y]);
      if (M) {
        if (s?.$$typeof === Symbol.for("react.lazy"))
          throw Object.defineProperty(
            Error(
              "`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."
            ),
            "__NEXT_ERROR_CODE",
            { value: "E863", enumerable: !1, configurable: !0 }
          );
        a = o.default.Children.only(s);
      }
      let U = M ? a && "object" == typeof a && a.ref : A,
        $ = o.default.useCallback(
          (e) => (
            null !== B &&
              (j.current = (0, m.mountLinkInstance)(e, z, B, R, L, g)),
            () => {
              j.current &&
                ((0, m.unmountLinkForCurrentNavigation)(j.current),
                (j.current = null)),
                (0, m.unmountPrefetchableInstance)(e);
            }
          ),
          [L, z, B, R, g]
        ),
        V = {
          ref: (0, c.useMergedRef)($, U),
          onClick(t) {
            M || "function" != typeof P || P(t),
              M &&
                a.props &&
                "function" == typeof a.props.onClick &&
                a.props.onClick(t),
              !B ||
                t.defaultPrevented ||
                (function (t, r, s, a, n, l, i) {
                  if ("undefined" != typeof window) {
                    let d,
                      { nodeName: c } = t.currentTarget;
                    if (
                      ("A" === c.toUpperCase() &&
                        (((d = t.currentTarget.getAttribute("target")) &&
                          "_self" !== d) ||
                          t.metaKey ||
                          t.ctrlKey ||
                          t.shiftKey ||
                          t.altKey ||
                          (t.nativeEvent && 2 === t.nativeEvent.which))) ||
                      t.currentTarget.hasAttribute("download")
                    )
                      return;
                    if (!(0, h.isLocalURL)(r)) {
                      n && (t.preventDefault(), location.replace(r));
                      return;
                    }
                    if ((t.preventDefault(), i)) {
                      let e = !1;
                      if (
                        (i({
                          preventDefault: () => {
                            e = !0;
                          },
                        }),
                        e)
                      )
                        return;
                    }
                    let { dispatchNavigateAction: x } = e.r(56797);
                    o.default.startTransition(() => {
                      x(s || r, n ? "replace" : "push", l ?? !0, a.current);
                    });
                  }
                })(t, z, F, j, k, S, _);
          },
          onMouseEnter(e) {
            M || "function" != typeof O || O(e),
              M &&
                a.props &&
                "function" == typeof a.props.onMouseEnter &&
                a.props.onMouseEnter(e),
              B && L && (0, m.onNavigationIntent)(e.currentTarget, !0 === E);
          },
          onTouchStart: function (e) {
            M || "function" != typeof T || T(e),
              M &&
                a.props &&
                "function" == typeof a.props.onTouchStart &&
                a.props.onTouchStart(e),
              B && L && (0, m.onNavigationIntent)(e.currentTarget, !0 === E);
          },
        };
      return (
        (0, x.isAbsoluteUrl)(F)
          ? (V.href = F)
          : (M && !C && ("a" !== a.type || "href" in a.props)) ||
            (V.href = (0, u.addBasePath)(F)),
        (n = M
          ? o.default.cloneElement(a, V)
          : (0, l.jsx)("a", { ...I, ...V, children: s })),
        (0, l.jsx)(b.Provider, { value: i, children: n })
      );
    }
    e.r(95136);
    let b = (0, o.createContext)(m.IDLE_LINK_STATUS),
      j = () => (0, o.useContext)(b);
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  84675,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("ArrowLeft", [
      ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
      ["path", { d: "M19 12H5", key: "x3x0zl" }],
    ]);
    e.s(["ArrowLeft", () => t], 84675);
  },
  13637,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Download", [
      [
        "path",
        { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
      ],
      ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
      ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }],
    ]);
    e.s(["Download", () => t], 13637);
  },
  81947,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(94237),
      s = e.i(47163);
    let a = (0, r.cva)(
      "relative w-full rounded-lg border px-4 py-3 text-sm grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current",
      {
        variants: {
          variant: {
            default: "bg-card text-card-foreground",
            destructive:
              "text-destructive bg-card [&>svg]:text-current *:data-[slot=alert-description]:text-destructive/90",
          },
        },
        defaultVariants: { variant: "default" },
      }
    );
    function n({ className: e, variant: r, ...n }) {
      return (0, t.jsx)("div", {
        "data-slot": "alert",
        role: "alert",
        className: (0, s.cn)(a({ variant: r }), e),
        ...n,
      });
    }
    function l({ className: e, ...r }) {
      return (0, t.jsx)("div", {
        "data-slot": "alert-description",
        className: (0, s.cn)(
          "text-muted-foreground col-start-2 grid justify-items-start gap-1 text-sm [&_p]:leading-relaxed",
          e
        ),
        ...r,
      });
    }
    e.s(["Alert", () => n, "AlertDescription", () => l]);
  },
  64877,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("TriangleAlert", [
      [
        "path",
        {
          d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
          key: "wmoenq",
        },
      ],
      ["path", { d: "M12 9v4", key: "juzpu7" }],
      ["path", { d: "M12 17h.01", key: "p32p05" }],
    ]);
    e.s(["AlertTriangle", () => t], 64877);
  },
  70065,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(47163);
    function s({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card",
        className: (0, r.cn)(
          "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",
          e
        ),
        ...s,
      });
    }
    function a({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-header",
        className: (0, r.cn)(
          "@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6",
          e
        ),
        ...s,
      });
    }
    function n({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-title",
        className: (0, r.cn)("leading-none font-semibold", e),
        ...s,
      });
    }
    function l({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-description",
        className: (0, r.cn)("text-muted-foreground text-sm", e),
        ...s,
      });
    }
    function o({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-content",
        className: (0, r.cn)("px-6", e),
        ...s,
      });
    }
    e.s([
      "Card",
      () => s,
      "CardContent",
      () => o,
      "CardDescription",
      () => l,
      "CardHeader",
      () => a,
      "CardTitle",
      () => n,
    ]);
  },
  17508,
  52910,
  (e) => {
    "use strict";
    var t = e.i(10965);
    let r = (0, t.default)("ChevronRight", [
      ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }],
    ]);
    e.s(["ChevronRight", () => r], 17508);
    let s = (0, t.default)("ChevronLeft", [
      ["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }],
    ]);
    e.s(["ChevronLeft", () => s], 52910);
  },
  88297,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("CircleCheckBig", [
      ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
      ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }],
    ]);
    e.s(["CheckCircle", () => t], 88297);
  },
  13293,
  76841,
  (e) => {
    "use strict";
    var t = e.i(93046);
    let r = (0, e.i(10965).default)("Ghost", [
      ["path", { d: "M9 10h.01", key: "qbtxuw" }],
      ["path", { d: "M15 10h.01", key: "1qmjsl" }],
      [
        "path",
        {
          d: "M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z",
          key: "uwwb07",
        },
      ],
    ]);
    var s = e.i(67881);
    function a() {
      return (0, t.jsx)("header", {
        className:
          "border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50",
        children: (0, t.jsxs)("div", {
          className:
            "container mx-auto px-4 py-4 flex items-center justify-between",
          children: [
            (0, t.jsxs)("div", {
              className: "flex items-center gap-2",
              children: [
                (0, t.jsx)(r, { className: "h-8 w-8 text-primary" }),
                (0, t.jsx)("span", {
                  className: "text-2xl font-bold text-foreground",
                  children: "GHOSTY Services",
                }),
              ],
            }),
            (0, t.jsxs)("nav", {
              className: "hidden md:flex items-center gap-6",
              children: [
                (0, t.jsx)("a", {
                  href: "#products",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Products",
                }),
                (0, t.jsx)("a", {
                  href: "#guides",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Guides",
                }),
                (0, t.jsx)("a", {
                  href: "#support",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Support",
                }),
                (0, t.jsx)(s.Button, {
                  size: "sm",
                  className:
                    "bg-primary hover:bg-primary/90 text-primary-foreground",
                  children: "Get Started",
                }),
              ],
            }),
          ],
        }),
      });
    }
    function n() {
      return (0, t.jsx)("footer", {
        className: "border-t border-border bg-card/50 py-12 px-4",
        children: (0, t.jsxs)("div", {
          className: "container mx-auto",
          children: [
            (0, t.jsxs)("div", {
              className: "grid grid-cols-1 md:grid-cols-4 gap-8 mb-8",
              children: [
                (0, t.jsxs)("div", {
                  className: "space-y-4",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-2",
                      children: [
                        (0, t.jsx)(r, { className: "h-6 w-6 text-primary" }),
                        (0, t.jsx)("span", {
                          className: "text-xl font-bold text-foreground",
                          children: "GHOSTY Services",
                        }),
                      ],
                    }),
                    (0, t.jsx)("p", {
                      className:
                        "text-muted-foreground text-sm leading-relaxed",
                      children:
                        "Your trusted source for gaming guides, tutorials, and professional services.",
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  children: [
                    (0, t.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Products",
                    }),
                    (0, t.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "All Guides",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "FPS Games",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Battle Royale",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Services",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  children: [
                    (0, t.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Support",
                    }),
                    (0, t.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Help Center",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Contact Us",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "FAQ",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Discord",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  children: [
                    (0, t.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Legal",
                    }),
                    (0, t.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Terms of Service",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Privacy Policy",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Refund Policy",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            (0, t.jsx)("div", {
              className:
                "border-t border-border pt-8 text-center text-sm text-muted-foreground",
              children: (0, t.jsx)("p", {
                children: "© 2025 GHOSTY Services. All rights reserved.",
              }),
            }),
          ],
        }),
      });
    }
    e.s(["Header", () => a], 13293), e.s(["Footer", () => n], 76841);
  },
  42838,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Shield", [
      [
        "path",
        {
          d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
          key: "oel41y",
        },
      ],
    ]);
    e.s(["Shield", () => t], 42838);
  },
  49056,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Settings", [
      [
        "path",
        {
          d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
          key: "1qme2f",
        },
      ],
      ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
    ]);
    e.s(["Settings", () => t], 49056);
  },
  75299,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(80883),
      s = e.i(61021),
      a = e.i(84675),
      n = e.i(13637),
      l = e.i(42838),
      o = e.i(10965);
    let i = (0, o.default)("Network", [
      [
        "rect",
        { x: "16", y: "16", width: "6", height: "6", rx: "1", key: "4q2zg0" },
      ],
      [
        "rect",
        { x: "2", y: "16", width: "6", height: "6", rx: "1", key: "8cvhb9" },
      ],
      [
        "rect",
        { x: "9", y: "2", width: "6", height: "6", rx: "1", key: "1egb70" },
      ],
      [
        "path",
        { d: "M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3", key: "1jsf9p" },
      ],
      ["path", { d: "M12 12V8", key: "2874zd" }],
    ]);
    var d = e.i(49056);
    let c = (0, o.default)("Cpu", [
        [
          "rect",
          { width: "16", height: "16", x: "4", y: "4", rx: "2", key: "14l7u7" },
        ],
        [
          "rect",
          { width: "6", height: "6", x: "9", y: "9", rx: "1", key: "5aljv4" },
        ],
        ["path", { d: "M15 2v2", key: "13l42r" }],
        ["path", { d: "M15 20v2", key: "15mkzm" }],
        ["path", { d: "M2 15h2", key: "1gxd5l" }],
        ["path", { d: "M2 9h2", key: "1bbxkp" }],
        ["path", { d: "M20 15h2", key: "19e6y8" }],
        ["path", { d: "M20 9h2", key: "19tzq7" }],
        ["path", { d: "M9 2v2", key: "165o2o" }],
        ["path", { d: "M9 20v2", key: "i2bqo8" }],
      ]),
      x = (0, o.default)("HardDrive", [
        ["line", { x1: "22", x2: "2", y1: "12", y2: "12", key: "1y58io" }],
        [
          "path",
          {
            d: "M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
            key: "oot6mr",
          },
        ],
        ["line", { x1: "6", x2: "6.01", y1: "16", y2: "16", key: "sgf278" }],
        ["line", { x1: "10", x2: "10.01", y1: "16", y2: "16", key: "1l4acy" }],
      ]);
    var u = e.i(17508),
      m = e.i(52910),
      h = e.i(88297),
      f = e.i(64877),
      p = e.i(67881),
      g = e.i(81947),
      b = e.i(13293),
      j = e.i(76841),
      N = e.i(70065);
    function y() {
      let [e, o] = (0, r.useState)(1),
        y = (e / 8) * 100;
      return (0, t.jsxs)("div", {
        className: "min-h-screen bg-background",
        children: [
          (0, t.jsx)(b.Header, {}),
          (0, t.jsx)("section", {
            className:
              "py-12 px-4 bg-gradient-to-b from-primary/10 to-background border-b border-border",
            children: (0, t.jsxs)("div", {
              className: "container mx-auto max-w-4xl",
              children: [
                (0, t.jsxs)(s.default, {
                  href: "/",
                  className:
                    "inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-6",
                  children: [
                    (0, t.jsx)(a.ArrowLeft, { className: "h-5 w-5" }),
                    (0, t.jsx)("span", {
                      className: "font-semibold",
                      children: "Back to Home",
                    }),
                  ],
                }),
                (0, t.jsx)("h1", {
                  className: "text-5xl font-bold mb-4 text-foreground",
                  children: "BO6 Warzone External Cheat Setup",
                }),
                (0, t.jsx)("p", {
                  className: "text-muted-foreground text-xl text-pretty",
                  children:
                    "Complete setup instructions for Call of Duty Black Ops 6 and Warzone external cheat",
                }),
              ],
            }),
          }),
          (0, t.jsx)("section", {
            className:
              "sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border py-4 px-4",
            children: (0, t.jsxs)("div", {
              className: "container mx-auto max-w-4xl",
              children: [
                (0, t.jsxs)("div", {
                  className: "flex items-center justify-between mb-3",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "text-sm font-medium text-foreground",
                      children: ["Step ", e, " of ", 8],
                    }),
                    (0, t.jsxs)("div", {
                      className: "text-sm text-muted-foreground",
                      children: [y.toFixed(0), "% Complete"],
                    }),
                  ],
                }),
                (0, t.jsx)("div", {
                  className: "h-2 bg-muted rounded-full overflow-hidden",
                  children: (0, t.jsx)("div", {
                    className:
                      "h-full bg-primary transition-all duration-500 ease-out",
                    style: { width: `${y}%` },
                  }),
                }),
              ],
            }),
          }),
          (0, t.jsxs)("main", {
            className: "container mx-auto px-4 py-12 max-w-4xl min-h-[600px]",
            children: [
              1 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-blue-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-blue-500/30",
                          children: "1",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Turn Off Virus & Threat Protection",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children: "Disable Windows Security protection",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsx)(N.Card, {
                      className:
                        "border-blue-500/30 bg-blue-500/5 backdrop-blur",
                      children: (0, t.jsx)(N.CardContent, {
                        className: "pt-8",
                        children: (0, t.jsxs)("div", {
                          className: "flex items-start gap-4",
                          children: [
                            (0, t.jsx)(l.Shield, {
                              className: "h-8 w-8 text-blue-500 mt-1 shrink-0",
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex-1 space-y-4",
                              children: [
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-blue-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Open Windows Security",
                                  ],
                                }),
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-blue-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Go to Virus & Threat Protection",
                                  ],
                                }),
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-blue-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Click on Manage Settings",
                                  ],
                                }),
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-blue-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Disable everything in this section",
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    }),
                  ],
                }),
              2 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-purple-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-purple-500/30",
                          children: "2",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Disable Firewall & Network Protection",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children: "Turn off all network protection",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsx)(N.Card, {
                      className:
                        "border-purple-500/30 bg-purple-500/5 backdrop-blur",
                      children: (0, t.jsx)(N.CardContent, {
                        className: "pt-8",
                        children: (0, t.jsxs)("div", {
                          className: "flex items-start gap-4",
                          children: [
                            (0, t.jsx)(i, {
                              className:
                                "h-8 w-8 text-purple-500 mt-1 shrink-0",
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex-1 space-y-4",
                              children: [
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-purple-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Open Firewall & Network Protection",
                                  ],
                                }),
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-purple-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Disable the following: Domain Network, Private Network, Public Network",
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    }),
                  ],
                }),
              3 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-primary flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-primary/30",
                          children: "3",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Turn Off Apps & Browser Control",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children: "Disable all app and browser controls",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsx)(N.Card, {
                      className: "border-primary/30 bg-primary/5 backdrop-blur",
                      children: (0, t.jsx)(N.CardContent, {
                        className: "pt-8",
                        children: (0, t.jsxs)("div", {
                          className: "flex items-start gap-4",
                          children: [
                            (0, t.jsx)(d.Settings, {
                              className: "h-8 w-8 text-primary mt-1 shrink-0",
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex-1 space-y-4",
                              children: [
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-primary font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Open Apps & Browser Control",
                                  ],
                                }),
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-primary font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Disable all options in this section",
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    }),
                  ],
                }),
              4 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-orange-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-orange-500/30",
                          children: "4",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Install dControl",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children: "Disable Windows Defender completely",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsx)(N.Card, {
                      className:
                        "border-orange-500/30 bg-orange-500/5 backdrop-blur",
                      children: (0, t.jsx)(N.CardContent, {
                        className: "pt-8",
                        children: (0, t.jsxs)("div", {
                          className: "space-y-6",
                          children: [
                            (0, t.jsxs)("div", {
                              className: "space-y-4",
                              children: [
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-orange-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Download & Install dControl",
                                  ],
                                }),
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-orange-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "This will disable Windows Defender completely",
                                  ],
                                }),
                              ],
                            }),
                            (0, t.jsx)(p.Button, {
                              asChild: !0,
                              className:
                                "w-full sm:w-auto h-14 text-base bg-orange-500 hover:bg-orange-600",
                              children: (0, t.jsxs)("a", {
                                href: "https://www.sordum.org/downloads/?dcontrol",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: [
                                  (0, t.jsx)(n.Download, {
                                    className: "mr-2 h-5 w-5",
                                  }),
                                  "Download dControl",
                                ],
                              }),
                            }),
                          ],
                        }),
                      }),
                    }),
                  ],
                }),
              5 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-red-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-red-500/30",
                          children: "5",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Disable Memory Integrity",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children: "Turn off core isolation features",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsx)(N.Card, {
                      className: "border-red-500/30 bg-red-500/5 backdrop-blur",
                      children: (0, t.jsx)(N.CardContent, {
                        className: "pt-8",
                        children: (0, t.jsxs)("div", {
                          className: "flex items-start gap-4",
                          children: [
                            (0, t.jsx)(x, {
                              className: "h-8 w-8 text-red-500 mt-1 shrink-0",
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex-1 space-y-4",
                              children: [
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-red-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Open Windows Security",
                                  ],
                                }),
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-red-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Navigate to Device Security",
                                  ],
                                }),
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-red-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Disable Memory Integrity",
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    }),
                  ],
                }),
              6 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-green-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-green-500/30",
                          children: "6",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Confirm Virtualization is Enabled",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children: "Check virtualization status",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsx)(N.Card, {
                      className:
                        "border-green-500/30 bg-green-500/5 backdrop-blur",
                      children: (0, t.jsx)(N.CardContent, {
                        className: "pt-8",
                        children: (0, t.jsxs)("div", {
                          className: "flex items-start gap-4",
                          children: [
                            (0, t.jsx)(c, {
                              className: "h-8 w-8 text-green-500 mt-1 shrink-0",
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex-1 space-y-4",
                              children: [
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-green-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Open Task Manager",
                                  ],
                                }),
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-green-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Click on the Performance tab",
                                  ],
                                }),
                                (0, t.jsxs)("p", {
                                  className:
                                    "text-muted-foreground flex items-start gap-3 text-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        "text-green-500 font-bold text-xl",
                                      children: "→",
                                    }),
                                    "Check if Virtualization is enabled",
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    }),
                  ],
                }),
              7 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-cyan-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-cyan-500/30",
                          children: "7",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Download Dependencies & Loader",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children: "Install required software",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsxs)("div", {
                      className: "space-y-6",
                      children: [
                        (0, t.jsx)(N.Card, {
                          className:
                            "border-cyan-500/30 bg-cyan-500/5 backdrop-blur",
                          children: (0, t.jsxs)(N.CardContent, {
                            className: "pt-8",
                            children: [
                              (0, t.jsx)("h3", {
                                className:
                                  "text-2xl font-semibold mb-6 text-foreground",
                                children: "Required Dependencies",
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground mb-6 text-lg",
                                children:
                                  "Download and install the required dependencies for the cheat to function properly.",
                              }),
                              (0, t.jsxs)("div", {
                                className: "flex flex-col sm:flex-row gap-4",
                                children: [
                                  (0, t.jsx)(p.Button, {
                                    asChild: !0,
                                    variant: "default",
                                    className: "h-14 text-base",
                                    children: (0, t.jsxs)("a", {
                                      href: "https://www.microsoft.com/en-us/download/details.aspx?id=35",
                                      target: "_blank",
                                      rel: "noopener noreferrer",
                                      children: [
                                        (0, t.jsx)(n.Download, {
                                          className: "mr-2 h-5 w-5",
                                        }),
                                        "Download DirectX",
                                      ],
                                    }),
                                  }),
                                  (0, t.jsx)(p.Button, {
                                    asChild: !0,
                                    variant: "outline",
                                    className: "h-14 text-base bg-transparent",
                                    children: (0, t.jsxs)("a", {
                                      href: "https://www.techpowerup.com/download/visual-c-redistributable-runtime-package-all-in-one/",
                                      target: "_blank",
                                      rel: "noopener noreferrer",
                                      children: [
                                        (0, t.jsx)(n.Download, {
                                          className: "mr-2 h-5 w-5",
                                        }),
                                        "Download Visual C++",
                                      ],
                                    }),
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        (0, t.jsx)(N.Card, {
                          className: "border-primary/30 bg-primary/10",
                          children: (0, t.jsxs)(N.CardContent, {
                            className: "pt-8",
                            children: [
                              (0, t.jsx)("h3", {
                                className:
                                  "text-2xl font-semibold mb-4 text-foreground",
                                children: "Loader Download",
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground mb-6 text-lg",
                                children:
                                  "Download the ZeroAim loader for BO6/Warzone",
                              }),
                              (0, t.jsx)(p.Button, {
                                asChild: !0,
                                className: "w-full sm:w-auto h-14 text-base",
                                children: (0, t.jsxs)("a", {
                                  href: "https://gofile.io/d/gWuJQp",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  children: [
                                    (0, t.jsx)(n.Download, {
                                      className: "mr-2 h-5 w-5",
                                    }),
                                    "Download ZeroAim Loader",
                                  ],
                                }),
                              }),
                            ],
                          }),
                        }),
                        (0, t.jsx)(g.Alert, {
                          children: (0, t.jsx)(g.AlertDescription, {
                            className: "text-muted-foreground text-base",
                            children:
                              "Make sure to follow all steps in order. If you encounter any issues, check the troubleshooting section in the next step.",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              8 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-amber-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-amber-500/30",
                          children: "8",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Troubleshooting & Fixes",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children: "Common issues and solutions",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsxs)("div", {
                      className: "space-y-6",
                      children: [
                        (0, t.jsx)(N.Card, {
                          className: "border-red-500/30 bg-red-500/5",
                          children: (0, t.jsxs)(N.CardContent, {
                            className: "pt-8",
                            children: [
                              (0, t.jsxs)("div", {
                                className: "flex items-start gap-4 mb-4",
                                children: [
                                  (0, t.jsx)(f.AlertTriangle, {
                                    className:
                                      "h-6 w-6 text-red-500 mt-1 shrink-0",
                                  }),
                                  (0, t.jsx)("h3", {
                                    className:
                                      "text-2xl font-semibold text-foreground",
                                    children: "Blue Screen (BSOD) Issues",
                                  }),
                                ],
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground mb-6 text-lg",
                                children:
                                  "If you experience blue screens, you need to disable virtualization features in your BIOS.",
                              }),
                              (0, t.jsxs)("div", {
                                className: "space-y-3 mb-4",
                                children: [
                                  (0, t.jsx)("p", {
                                    className:
                                      "text-foreground font-semibold text-lg",
                                    children:
                                      "Disabling SVM Mode (AMD) or VT-X (Intel):",
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-red-500 font-bold",
                                        children: "→",
                                      }),
                                      "Restart your PC and enter BIOS/UEFI settings (press Delete, F2, or another key during startup)",
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-red-500 font-bold",
                                        children: "→",
                                      }),
                                      "Navigate to CPU Configuration or similar section",
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-red-500 font-bold",
                                        children: "→",
                                      }),
                                      "Find SVM Mode (AMD) or VT-X (Intel) and disable it",
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-red-500 font-bold",
                                        children: "→",
                                      }),
                                      "Save settings and exit BIOS",
                                    ],
                                  }),
                                ],
                              }),
                              (0, t.jsx)(g.Alert, {
                                className:
                                  "bg-amber-500/10 border-amber-500/30",
                                children: (0, t.jsx)(g.AlertDescription, {
                                  className: "text-muted-foreground",
                                  children:
                                    "Note: This disables all virtualization features including virtual machines. Only use if you don't need virtualization.",
                                }),
                              }),
                            ],
                          }),
                        }),
                        (0, t.jsx)(N.Card, {
                          className: "border-blue-500/30 bg-blue-500/5",
                          children: (0, t.jsxs)(N.CardContent, {
                            className: "pt-8",
                            children: [
                              (0, t.jsxs)("div", {
                                className: "flex items-start gap-4 mb-4",
                                children: [
                                  (0, t.jsx)(f.AlertTriangle, {
                                    className:
                                      "h-6 w-6 text-blue-500 mt-1 shrink-0",
                                  }),
                                  (0, t.jsx)("h3", {
                                    className:
                                      "text-2xl font-semibold text-foreground",
                                    children: "Menu Does Not Show",
                                  }),
                                ],
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground mb-6 text-lg",
                                children:
                                  "If the cheat menu doesn't appear, install DirectX.",
                              }),
                              (0, t.jsx)(p.Button, {
                                asChild: !0,
                                variant: "default",
                                className: "h-12 text-base",
                                children: (0, t.jsxs)("a", {
                                  href: "https://www.microsoft.com/en-us/download/details.aspx?id=35",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  children: [
                                    (0, t.jsx)(n.Download, {
                                      className: "mr-2 h-5 w-5",
                                    }),
                                    "Download DirectX",
                                  ],
                                }),
                              }),
                            ],
                          }),
                        }),
                        (0, t.jsx)(N.Card, {
                          className: "border-purple-500/30 bg-purple-500/5",
                          children: (0, t.jsxs)(N.CardContent, {
                            className: "pt-8",
                            children: [
                              (0, t.jsxs)("div", {
                                className: "flex items-start gap-4 mb-4",
                                children: [
                                  (0, t.jsx)(f.AlertTriangle, {
                                    className:
                                      "h-6 w-6 text-purple-500 mt-1 shrink-0",
                                  }),
                                  (0, t.jsx)("h3", {
                                    className:
                                      "text-2xl font-semibold text-foreground",
                                    children: "Controller Issue Fix",
                                  }),
                                ],
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground mb-6 text-lg",
                                children:
                                  "If you're having controller issues, follow these steps with DS4:",
                              }),
                              (0, t.jsxs)("div", {
                                className: "space-y-3 mb-6",
                                children: [
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-purple-500 font-bold",
                                        children: "1.",
                                      }),
                                      "Pull up the cheat menu",
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-purple-500 font-bold",
                                        children: "2.",
                                      }),
                                      "Unplug controller and make sure it's off",
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-purple-500 font-bold",
                                        children: "3.",
                                      }),
                                      "Turn on aimbot for controller in Controller tab",
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-purple-500 font-bold",
                                        children: "4.",
                                      }),
                                      'Should say "reconnecting"',
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-purple-500 font-bold",
                                        children: "5.",
                                      }),
                                      "Replug controller in",
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-purple-500 font-bold",
                                        children: "6.",
                                      }),
                                      "Should be connected!",
                                    ],
                                  }),
                                ],
                              }),
                              (0, t.jsx)(p.Button, {
                                asChild: !0,
                                variant: "default",
                                className: "h-12 text-base",
                                children: (0, t.jsxs)("a", {
                                  href: "https://vigembusdriver.com",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  children: [
                                    (0, t.jsx)(n.Download, {
                                      className: "mr-2 h-5 w-5",
                                    }),
                                    "Install ViGEmBus Driver",
                                  ],
                                }),
                              }),
                            ],
                          }),
                        }),
                        (0, t.jsx)(N.Card, {
                          className: "border-orange-500/30 bg-orange-500/5",
                          children: (0, t.jsxs)(N.CardContent, {
                            className: "pt-8",
                            children: [
                              (0, t.jsxs)("div", {
                                className: "flex items-start gap-4 mb-4",
                                children: [
                                  (0, t.jsx)(f.AlertTriangle, {
                                    className:
                                      "h-6 w-6 text-orange-500 mt-1 shrink-0",
                                  }),
                                  (0, t.jsx)("h3", {
                                    className:
                                      "text-2xl font-semibold text-foreground",
                                    children: "Failed to Load Driver 1",
                                  }),
                                ],
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground mb-6 text-lg",
                                children:
                                  'If you get "Failed to load driver" error:',
                              }),
                              (0, t.jsxs)("div", {
                                className: "space-y-3 mb-6",
                                children: [
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-orange-500 font-bold",
                                        children: "→",
                                      }),
                                      "Enable Windows Defender with Dcontrol",
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-orange-500 font-bold",
                                        children: "→",
                                      }),
                                      "Restart PC",
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-orange-500 font-bold",
                                        children: "→",
                                      }),
                                      "Disable Windows Defender manually (all options should be off)",
                                    ],
                                  }),
                                  (0, t.jsxs)("p", {
                                    className:
                                      "text-muted-foreground flex items-start gap-3 text-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-orange-500 font-bold",
                                        children: "→",
                                      }),
                                      "Disable Windows Defender with Dcontrol again",
                                    ],
                                  }),
                                ],
                              }),
                              (0, t.jsx)(p.Button, {
                                asChild: !0,
                                variant: "default",
                                className: "h-12 text-base",
                                children: (0, t.jsxs)("a", {
                                  href: "https://gofile.io/d/y64FSN",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  children: [
                                    (0, t.jsx)(n.Download, {
                                      className: "mr-2 h-5 w-5",
                                    }),
                                    "Download Fix Files",
                                  ],
                                }),
                              }),
                            ],
                          }),
                        }),
                        (0, t.jsx)(N.Card, {
                          className: "border-green-500/30 bg-green-500/5",
                          children: (0, t.jsxs)(N.CardContent, {
                            className: "pt-8",
                            children: [
                              (0, t.jsxs)("div", {
                                className: "flex items-start gap-4 mb-4",
                                children: [
                                  (0, t.jsx)(f.AlertTriangle, {
                                    className:
                                      "h-6 w-6 text-green-500 mt-1 shrink-0",
                                  }),
                                  (0, t.jsx)("h3", {
                                    className:
                                      "text-2xl font-semibold text-foreground",
                                    children: "Loader Stuck on Connecting",
                                  }),
                                ],
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground mb-6 text-lg",
                                children:
                                  'If the loader gets stuck on "Connecting", change your DNS to Cloudflare\'s 1.1.1.1',
                              }),
                              (0, t.jsx)(p.Button, {
                                asChild: !0,
                                variant: "default",
                                className: "h-12 text-base",
                                children: (0, t.jsxs)("a", {
                                  href: "https://one.one.one.one/",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  children: [
                                    (0, t.jsx)(n.Download, {
                                      className: "mr-2 h-5 w-5",
                                    }),
                                    "Get Cloudflare DNS",
                                  ],
                                }),
                              }),
                            ],
                          }),
                        }),
                        (0, t.jsx)(g.Alert, {
                          className: "bg-primary/10 border-primary/30",
                          children: (0, t.jsx)(g.AlertDescription, {
                            className: "text-muted-foreground text-base",
                            children:
                              "If you still have issues after trying these fixes, please contact support on our Discord server for personalized assistance.",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
            ],
          }),
          (0, t.jsx)("section", {
            className:
              "sticky bottom-0 bg-background/95 backdrop-blur border-t border-border py-6 px-4",
            children: (0, t.jsx)("div", {
              className: "container mx-auto max-w-4xl",
              children: (0, t.jsxs)("div", {
                className: "flex items-center justify-between gap-4",
                children: [
                  (0, t.jsxs)(p.Button, {
                    variant: "outline",
                    size: "lg",
                    onClick: () => {
                      e > 1 &&
                        (o(e - 1),
                        window.scrollTo({ top: 0, behavior: "smooth" }));
                    },
                    disabled: 1 === e,
                    className: "h-14 px-8 text-base bg-transparent",
                    children: [
                      (0, t.jsx)(m.ChevronLeft, { className: "mr-2 h-5 w-5" }),
                      "Back",
                    ],
                  }),
                  (0, t.jsxs)("div", {
                    className: "text-center",
                    children: [
                      (0, t.jsx)("p", {
                        className: "text-sm text-muted-foreground mb-1",
                        children: "Step Progress",
                      }),
                      (0, t.jsxs)("p", {
                        className: "text-lg font-semibold text-foreground",
                        children: [e, " / ", 8],
                      }),
                    ],
                  }),
                  (0, t.jsx)(p.Button, {
                    size: "lg",
                    onClick: () => {
                      e < 8 &&
                        (o(e + 1),
                        window.scrollTo({ top: 0, behavior: "smooth" }));
                    },
                    disabled: 8 === e,
                    className:
                      "h-14 px-8 text-base bg-primary hover:bg-primary/90",
                    children:
                      8 === e
                        ? (0, t.jsxs)(t.Fragment, {
                            children: [
                              (0, t.jsx)(h.CheckCircle, {
                                className: "mr-2 h-5 w-5",
                              }),
                              "Complete",
                            ],
                          })
                        : (0, t.jsxs)(t.Fragment, {
                            children: [
                              "Continue",
                              (0, t.jsx)(u.ChevronRight, {
                                className: "ml-2 h-5 w-5",
                              }),
                            ],
                          }),
                  }),
                ],
              }),
            }),
          }),
          (0, t.jsx)(j.Footer, {}),
        ],
      });
    }
    e.s(["default", () => y], 75299);
  },
]);
