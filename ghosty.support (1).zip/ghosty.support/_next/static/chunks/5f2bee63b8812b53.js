(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  60835,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "warnOnce", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let n = (e) => {};
  },
  85260,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      assign: function () {
        return l;
      },
      searchParamsToUrlQuery: function () {
        return o;
      },
      urlQueryToSearchParams: function () {
        return i;
      },
    };
    for (var a in n) Object.defineProperty(r, a, { enumerable: !0, get: n[a] });
    function o(e) {
      let t = {};
      for (let [r, n] of e.entries()) {
        let e = t[r];
        void 0 === e
          ? (t[r] = n)
          : Array.isArray(e)
          ? e.push(n)
          : (t[r] = [e, n]);
      }
      return t;
    }
    function s(e) {
      return "string" == typeof e
        ? e
        : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e
        ? ""
        : String(e);
    }
    function i(e) {
      let t = new URLSearchParams();
      for (let [r, n] of Object.entries(e))
        if (Array.isArray(n)) for (let e of n) t.append(r, s(e));
        else t.set(r, s(n));
      return t;
    }
    function l(e, ...t) {
      for (let r of t) {
        for (let t of r.keys()) e.delete(t);
        for (let [t, n] of r.entries()) e.append(t, n);
      }
      return e;
    }
  },
  91552,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      formatUrl: function () {
        return i;
      },
      formatWithValidation: function () {
        return c;
      },
      urlObjectKeys: function () {
        return l;
      },
    };
    for (var a in n) Object.defineProperty(r, a, { enumerable: !0, get: n[a] });
    let o = e.r(44066)._(e.r(85260)),
      s = /https?|ftp|gopher|file/;
    function i(e) {
      let { auth: t, hostname: r } = e,
        n = e.protocol || "",
        a = e.pathname || "",
        i = e.hash || "",
        l = e.query || "",
        c = !1;
      (t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : ""),
        e.host
          ? (c = t + e.host)
          : r &&
            ((c = t + (~r.indexOf(":") ? `[${r}]` : r)),
            e.port && (c += ":" + e.port)),
        l && "object" == typeof l && (l = String(o.urlQueryToSearchParams(l)));
      let u = e.search || (l && `?${l}`) || "";
      return (
        n && !n.endsWith(":") && (n += ":"),
        e.slashes || ((!n || s.test(n)) && !1 !== c)
          ? ((c = "//" + (c || "")), a && "/" !== a[0] && (a = "/" + a))
          : c || (c = ""),
        i && "#" !== i[0] && (i = "#" + i),
        u && "?" !== u[0] && (u = "?" + u),
        (a = a.replace(/[?#]/g, encodeURIComponent)),
        (u = u.replace("#", "%23")),
        `${n}${c}${a}${u}${i}`
      );
    }
    let l = [
      "auth",
      "hash",
      "host",
      "hostname",
      "href",
      "path",
      "pathname",
      "port",
      "protocol",
      "query",
      "search",
      "slashes",
    ];
    function c(e) {
      return i(e);
    }
  },
  60203,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    let n = e.r(80883);
    function a(e, t) {
      let r = (0, n.useRef)(null),
        a = (0, n.useRef)(null);
      return (0, n.useCallback)(
        (n) => {
          if (null === n) {
            let e = r.current;
            e && ((r.current = null), e());
            let t = a.current;
            t && ((a.current = null), t());
          } else e && (r.current = o(e, n)), t && (a.current = o(t, n));
        },
        [e, t]
      );
    }
    function o(e, t) {
      if ("function" != typeof e)
        return (
          (e.current = t),
          () => {
            e.current = null;
          }
        );
      {
        let r = e(t);
        return "function" == typeof r ? r : () => e(null);
      }
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  6898,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      DecodeError: function () {
        return x;
      },
      MiddlewareNotFoundError: function () {
        return j;
      },
      MissingStaticPage: function () {
        return b;
      },
      NormalizeError: function () {
        return v;
      },
      PageNotFoundError: function () {
        return y;
      },
      SP: function () {
        return m;
      },
      ST: function () {
        return g;
      },
      WEB_VITALS: function () {
        return o;
      },
      execOnce: function () {
        return s;
      },
      getDisplayName: function () {
        return d;
      },
      getLocationOrigin: function () {
        return c;
      },
      getURL: function () {
        return u;
      },
      isAbsoluteUrl: function () {
        return l;
      },
      isResSent: function () {
        return f;
      },
      loadGetInitialProps: function () {
        return h;
      },
      normalizeRepeatedSlashes: function () {
        return p;
      },
      stringifyError: function () {
        return N;
      },
    };
    for (var a in n) Object.defineProperty(r, a, { enumerable: !0, get: n[a] });
    let o = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];
    function s(e) {
      let t,
        r = !1;
      return (...n) => (r || ((r = !0), (t = e(...n))), t);
    }
    let i = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
      l = (e) => i.test(e);
    function c() {
      let { protocol: e, hostname: t, port: r } = window.location;
      return `${e}//${t}${r ? ":" + r : ""}`;
    }
    function u() {
      let { href: e } = window.location,
        t = c();
      return e.substring(t.length);
    }
    function d(e) {
      return "string" == typeof e ? e : e.displayName || e.name || "Unknown";
    }
    function f(e) {
      return e.finished || e.headersSent;
    }
    function p(e) {
      let t = e.split("?");
      return (
        t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") +
        (t[1] ? `?${t.slice(1).join("?")}` : "")
      );
    }
    async function h(e, t) {
      let r = t.res || (t.ctx && t.ctx.res);
      if (!e.getInitialProps)
        return t.ctx && t.Component
          ? { pageProps: await h(t.Component, t.ctx) }
          : {};
      let n = await e.getInitialProps(t);
      if (r && f(r)) return n;
      if (!n)
        throw Object.defineProperty(
          Error(
            `"${d(
              e
            )}.getInitialProps()" should resolve to an object. But found "${n}" instead.`
          ),
          "__NEXT_ERROR_CODE",
          { value: "E394", enumerable: !1, configurable: !0 }
        );
      return n;
    }
    let m = "undefined" != typeof performance,
      g =
        m &&
        ["mark", "measure", "getEntriesByName"].every(
          (e) => "function" == typeof performance[e]
        );
    class x extends Error {}
    class v extends Error {}
    class y extends Error {
      constructor(e) {
        super(),
          (this.code = "ENOENT"),
          (this.name = "PageNotFoundError"),
          (this.message = `Cannot find module for page: ${e}`);
      }
    }
    class b extends Error {
      constructor(e, t) {
        super(),
          (this.message = `Failed to load static file for page: ${e} ${t}`);
      }
    }
    class j extends Error {
      constructor() {
        super(),
          (this.code = "ENOENT"),
          (this.message = "Cannot find the middleware module");
      }
    }
    function N(e) {
      return JSON.stringify({ message: e.message, stack: e.stack });
    }
  },
  73350,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function () {
          return o;
        },
      });
    let n = e.r(6898),
      a = e.r(56075);
    function o(e) {
      if (!(0, n.isAbsoluteUrl)(e)) return !0;
      try {
        let t = (0, n.getLocationOrigin)(),
          r = new URL(e, t);
        return r.origin === t && (0, a.hasBasePath)(r.pathname);
      } catch (e) {
        return !1;
      }
    }
  },
  95136,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "errorOnce", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let n = (e) => {};
  },
  61021,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      default: function () {
        return x;
      },
      useLinkStatus: function () {
        return y;
      },
    };
    for (var a in n) Object.defineProperty(r, a, { enumerable: !0, get: n[a] });
    let o = e.r(44066),
      s = e.r(93046),
      i = o._(e.r(80883)),
      l = e.r(91552),
      c = e.r(89260),
      u = e.r(60203),
      d = e.r(6898),
      f = e.r(63118);
    e.r(60835);
    let p = e.r(68193),
      h = e.r(73350),
      m = e.r(50696);
    function g(e) {
      return "string" == typeof e ? e : (0, l.formatUrl)(e);
    }
    function x(t) {
      var r;
      let n,
        a,
        o,
        [l, x] = (0, i.useOptimistic)(p.IDLE_LINK_STATUS),
        y = (0, i.useRef)(null),
        {
          href: b,
          as: j,
          children: N,
          prefetch: P = null,
          passHref: k,
          replace: S,
          shallow: C,
          scroll: _,
          onClick: w,
          onMouseEnter: O,
          onTouchStart: E,
          legacyBehavior: T = !1,
          onNavigate: M,
          ref: A,
          unstable_dynamicOnHover: L,
          ...R
        } = t;
      (n = N),
        T &&
          ("string" == typeof n || "number" == typeof n) &&
          (n = (0, s.jsx)("a", { children: n }));
      let U = i.default.useContext(c.AppRouterContext),
        z = !1 !== P,
        $ =
          !1 !== P
            ? null === (r = P) || "auto" === r
              ? m.FetchStrategy.PPR
              : m.FetchStrategy.Full
            : m.FetchStrategy.PPR,
        { href: I, as: D } = i.default.useMemo(() => {
          let e = g(b);
          return { href: e, as: j ? g(j) : e };
        }, [b, j]);
      if (T) {
        if (n?.$$typeof === Symbol.for("react.lazy"))
          throw Object.defineProperty(
            Error(
              "`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."
            ),
            "__NEXT_ERROR_CODE",
            { value: "E863", enumerable: !1, configurable: !0 }
          );
        a = i.default.Children.only(n);
      }
      let F = T ? a && "object" == typeof a && a.ref : A,
        B = i.default.useCallback(
          (e) => (
            null !== U &&
              (y.current = (0, p.mountLinkInstance)(e, I, U, $, z, x)),
            () => {
              y.current &&
                ((0, p.unmountLinkForCurrentNavigation)(y.current),
                (y.current = null)),
                (0, p.unmountPrefetchableInstance)(e);
            }
          ),
          [z, I, U, $, x]
        ),
        V = {
          ref: (0, u.useMergedRef)(B, F),
          onClick(t) {
            T || "function" != typeof w || w(t),
              T &&
                a.props &&
                "function" == typeof a.props.onClick &&
                a.props.onClick(t),
              !U ||
                t.defaultPrevented ||
                (function (t, r, n, a, o, s, l) {
                  if ("undefined" != typeof window) {
                    let c,
                      { nodeName: u } = t.currentTarget;
                    if (
                      ("A" === u.toUpperCase() &&
                        (((c = t.currentTarget.getAttribute("target")) &&
                          "_self" !== c) ||
                          t.metaKey ||
                          t.ctrlKey ||
                          t.shiftKey ||
                          t.altKey ||
                          (t.nativeEvent && 2 === t.nativeEvent.which))) ||
                      t.currentTarget.hasAttribute("download")
                    )
                      return;
                    if (!(0, h.isLocalURL)(r)) {
                      o && (t.preventDefault(), location.replace(r));
                      return;
                    }
                    if ((t.preventDefault(), l)) {
                      let e = !1;
                      if (
                        (l({
                          preventDefault: () => {
                            e = !0;
                          },
                        }),
                        e)
                      )
                        return;
                    }
                    let { dispatchNavigateAction: d } = e.r(56797);
                    i.default.startTransition(() => {
                      d(n || r, o ? "replace" : "push", s ?? !0, a.current);
                    });
                  }
                })(t, I, D, y, S, _, M);
          },
          onMouseEnter(e) {
            T || "function" != typeof O || O(e),
              T &&
                a.props &&
                "function" == typeof a.props.onMouseEnter &&
                a.props.onMouseEnter(e),
              U && z && (0, p.onNavigationIntent)(e.currentTarget, !0 === L);
          },
          onTouchStart: function (e) {
            T || "function" != typeof E || E(e),
              T &&
                a.props &&
                "function" == typeof a.props.onTouchStart &&
                a.props.onTouchStart(e),
              U && z && (0, p.onNavigationIntent)(e.currentTarget, !0 === L);
          },
        };
      return (
        (0, d.isAbsoluteUrl)(D)
          ? (V.href = D)
          : (T && !k && ("a" !== a.type || "href" in a.props)) ||
            (V.href = (0, f.addBasePath)(D)),
        (o = T
          ? i.default.cloneElement(a, V)
          : (0, s.jsx)("a", { ...R, ...V, children: n })),
        (0, s.jsx)(v.Provider, { value: l, children: o })
      );
    }
    e.r(95136);
    let v = (0, i.createContext)(p.IDLE_LINK_STATUS),
      y = () => (0, i.useContext)(v);
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  84675,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("ArrowLeft", [
      ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
      ["path", { d: "M19 12H5", key: "x3x0zl" }],
    ]);
    e.s(["ArrowLeft", () => t], 84675);
  },
  81947,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(94237),
      n = e.i(47163);
    let a = (0, r.cva)(
      "relative w-full rounded-lg border px-4 py-3 text-sm grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current",
      {
        variants: {
          variant: {
            default: "bg-card text-card-foreground",
            destructive:
              "text-destructive bg-card [&>svg]:text-current *:data-[slot=alert-description]:text-destructive/90",
          },
        },
        defaultVariants: { variant: "default" },
      }
    );
    function o({ className: e, variant: r, ...o }) {
      return (0, t.jsx)("div", {
        "data-slot": "alert",
        role: "alert",
        className: (0, n.cn)(a({ variant: r }), e),
        ...o,
      });
    }
    function s({ className: e, ...r }) {
      return (0, t.jsx)("div", {
        "data-slot": "alert-description",
        className: (0, n.cn)(
          "text-muted-foreground col-start-2 grid justify-items-start gap-1 text-sm [&_p]:leading-relaxed",
          e
        ),
        ...r,
      });
    }
    e.s(["Alert", () => o, "AlertDescription", () => s]);
  },
  13637,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Download", [
      [
        "path",
        { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
      ],
      ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
      ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }],
    ]);
    e.s(["Download", () => t], 13637);
  },
  64877,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("TriangleAlert", [
      [
        "path",
        {
          d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
          key: "wmoenq",
        },
      ],
      ["path", { d: "M12 9v4", key: "juzpu7" }],
      ["path", { d: "M12 17h.01", key: "p32p05" }],
    ]);
    e.s(["AlertTriangle", () => t], 64877);
  },
  70065,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(47163);
    function n({ className: e, ...n }) {
      return (0, t.jsx)("div", {
        "data-slot": "card",
        className: (0, r.cn)(
          "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",
          e
        ),
        ...n,
      });
    }
    function a({ className: e, ...n }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-header",
        className: (0, r.cn)(
          "@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6",
          e
        ),
        ...n,
      });
    }
    function o({ className: e, ...n }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-title",
        className: (0, r.cn)("leading-none font-semibold", e),
        ...n,
      });
    }
    function s({ className: e, ...n }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-description",
        className: (0, r.cn)("text-muted-foreground text-sm", e),
        ...n,
      });
    }
    function i({ className: e, ...n }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-content",
        className: (0, r.cn)("px-6", e),
        ...n,
      });
    }
    e.s([
      "Card",
      () => n,
      "CardContent",
      () => i,
      "CardDescription",
      () => s,
      "CardHeader",
      () => a,
      "CardTitle",
      () => o,
    ]);
  },
  48054,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Package", [
      [
        "path",
        {
          d: "M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",
          key: "1a0edw",
        },
      ],
      ["path", { d: "M12 22V12", key: "d0xqtd" }],
      [
        "path",
        { d: "m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7", key: "yx3hmr" },
      ],
      ["path", { d: "m7.5 4.27 9 5.15", key: "1c824w" }],
    ]);
    e.s(["Package", () => t], 48054);
  },
  94179,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(87576),
      n = e.i(94237),
      a = e.i(47163);
    let o = (0, n.cva)(
      "inline-flex items-center justify-center rounded-md border px-2 py-0.5 text-xs font-medium w-fit whitespace-nowrap shrink-0 [&>svg]:size-3 gap-1 [&>svg]:pointer-events-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive transition-[color,box-shadow] overflow-hidden",
      {
        variants: {
          variant: {
            default:
              "border-transparent bg-primary text-primary-foreground [a&]:hover:bg-primary/90",
            secondary:
              "border-transparent bg-secondary text-secondary-foreground [a&]:hover:bg-secondary/90",
            destructive:
              "border-transparent bg-destructive text-white [a&]:hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline:
              "text-foreground [a&]:hover:bg-accent [a&]:hover:text-accent-foreground",
          },
        },
        defaultVariants: { variant: "default" },
      }
    );
    function s({ className: e, variant: n, asChild: s = !1, ...i }) {
      let l = s ? r.Slot : "span";
      return (0, t.jsx)(l, {
        "data-slot": "badge",
        className: (0, a.cn)(o({ variant: n }), e),
        ...i,
      });
    }
    e.s(["Badge", () => s]);
  },
  17508,
  52910,
  (e) => {
    "use strict";
    var t = e.i(10965);
    let r = (0, t.default)("ChevronRight", [
      ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }],
    ]);
    e.s(["ChevronRight", () => r], 17508);
    let n = (0, t.default)("ChevronLeft", [
      ["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }],
    ]);
    e.s(["ChevronLeft", () => n], 52910);
  },
  13293,
  76841,
  (e) => {
    "use strict";
    var t = e.i(93046);
    let r = (0, e.i(10965).default)("Ghost", [
      ["path", { d: "M9 10h.01", key: "qbtxuw" }],
      ["path", { d: "M15 10h.01", key: "1qmjsl" }],
      [
        "path",
        {
          d: "M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z",
          key: "uwwb07",
        },
      ],
    ]);
    var n = e.i(67881);
    function a() {
      return (0, t.jsx)("header", {
        className:
          "border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50",
        children: (0, t.jsxs)("div", {
          className:
            "container mx-auto px-4 py-4 flex items-center justify-between",
          children: [
            (0, t.jsxs)("div", {
              className: "flex items-center gap-2",
              children: [
                (0, t.jsx)(r, { className: "h-8 w-8 text-primary" }),
                (0, t.jsx)("span", {
                  className: "text-2xl font-bold text-foreground",
                  children: "GHOSTY Services",
                }),
              ],
            }),
            (0, t.jsxs)("nav", {
              className: "hidden md:flex items-center gap-6",
              children: [
                (0, t.jsx)("a", {
                  href: "#products",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Products",
                }),
                (0, t.jsx)("a", {
                  href: "#guides",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Guides",
                }),
                (0, t.jsx)("a", {
                  href: "#support",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Support",
                }),
                (0, t.jsx)(n.Button, {
                  size: "sm",
                  className:
                    "bg-primary hover:bg-primary/90 text-primary-foreground",
                  children: "Get Started",
                }),
              ],
            }),
          ],
        }),
      });
    }
    function o() {
      return (0, t.jsx)("footer", {
        className: "border-t border-border bg-card/50 py-12 px-4",
        children: (0, t.jsxs)("div", {
          className: "container mx-auto",
          children: [
            (0, t.jsxs)("div", {
              className: "grid grid-cols-1 md:grid-cols-4 gap-8 mb-8",
              children: [
                (0, t.jsxs)("div", {
                  className: "space-y-4",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-2",
                      children: [
                        (0, t.jsx)(r, { className: "h-6 w-6 text-primary" }),
                        (0, t.jsx)("span", {
                          className: "text-xl font-bold text-foreground",
                          children: "GHOSTY Services",
                        }),
                      ],
                    }),
                    (0, t.jsx)("p", {
                      className:
                        "text-muted-foreground text-sm leading-relaxed",
                      children:
                        "Your trusted source for gaming guides, tutorials, and professional services.",
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  children: [
                    (0, t.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Products",
                    }),
                    (0, t.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "All Guides",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "FPS Games",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Battle Royale",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Services",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  children: [
                    (0, t.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Support",
                    }),
                    (0, t.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Help Center",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Contact Us",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "FAQ",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Discord",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  children: [
                    (0, t.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Legal",
                    }),
                    (0, t.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Terms of Service",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Privacy Policy",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Refund Policy",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            (0, t.jsx)("div", {
              className:
                "border-t border-border pt-8 text-center text-sm text-muted-foreground",
              children: (0, t.jsx)("p", {
                children: "© 2025 GHOSTY Services. All rights reserved.",
              }),
            }),
          ],
        }),
      });
    }
    e.s(["Header", () => a], 13293), e.s(["Footer", () => o], 76841);
  },
  88297,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("CircleCheckBig", [
      ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
      ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }],
    ]);
    e.s(["CheckCircle", () => t], 88297);
  },
  42838,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Shield", [
      [
        "path",
        {
          d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
          key: "oel41y",
        },
      ],
    ]);
    e.s(["Shield", () => t], 42838);
  },
  49056,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Settings", [
      [
        "path",
        {
          d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
          key: "1qme2f",
        },
      ],
      ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
    ]);
    e.s(["Settings", () => t], 49056);
  },
]);
