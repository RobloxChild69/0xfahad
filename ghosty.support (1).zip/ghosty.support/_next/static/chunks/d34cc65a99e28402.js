(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  48956,
  (e, t, s) => {
    "use strict";
    function r({
      widthInt: e,
      heightInt: t,
      blurWidth: s,
      blurHeight: r,
      blurDataURL: a,
      objectFit: l,
    }) {
      let n = s ? 40 * s : e,
        i = r ? 40 * r : t,
        d = n && i ? `viewBox='0 0 ${n} ${i}'` : "";
      return `%3Csvg xmlns='http://www.w3.org/2000/svg' ${d}%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3CfeColorMatrix values='1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 100 -1' result='s'/%3E%3CfeFlood x='0' y='0' width='100%25' height='100%25'/%3E%3CfeComposite operator='out' in='s'/%3E%3CfeComposite in2='SourceGraphic'/%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3C/filter%3E%3Cimage width='100%25' height='100%25' x='0' y='0' preserveAspectRatio='${
        d
          ? "none"
          : "contain" === l
          ? "xMidYMid"
          : "cover" === l
          ? "xMidYMid slice"
          : "none"
      }' style='filter: url(%23b);' href='${a}'/%3E%3C/svg%3E`;
    }
    Object.defineProperty(s, "__esModule", { value: !0 }),
      Object.defineProperty(s, "getImageBlurSvg", {
        enumerable: !0,
        get: function () {
          return r;
        },
      });
  },
  84489,
  (e, t, s) => {
    "use strict";
    Object.defineProperty(s, "__esModule", { value: !0 });
    var r = {
      VALID_LOADERS: function () {
        return l;
      },
      imageConfigDefault: function () {
        return n;
      },
    };
    for (var a in r) Object.defineProperty(s, a, { enumerable: !0, get: r[a] });
    let l = ["default", "imgix", "cloudinary", "akamai", "custom"],
      n = {
        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
        imageSizes: [32, 48, 64, 96, 128, 256, 384],
        path: "/_next/image",
        loader: "default",
        loaderFile: "",
        domains: [],
        disableStaticImages: !1,
        minimumCacheTTL: 14400,
        formats: ["image/webp"],
        maximumRedirects: 3,
        dangerouslyAllowLocalIP: !1,
        dangerouslyAllowSVG: !1,
        contentSecurityPolicy: "script-src 'none'; frame-src 'none'; sandbox;",
        contentDispositionType: "attachment",
        localPatterns: void 0,
        remotePatterns: [],
        qualities: [75],
        unoptimized: !1,
      };
  },
  93420,
  (e, t, s) => {
    "use strict";
    Object.defineProperty(s, "__esModule", { value: !0 }),
      Object.defineProperty(s, "getImgProps", {
        enumerable: !0,
        get: function () {
          return o;
        },
      }),
      e.r(60835);
    let r = e.r(4226),
      a = e.r(48956),
      l = e.r(84489),
      n = ["-moz-initial", "fill", "none", "scale-down", void 0];
    function i(e) {
      return void 0 !== e.default;
    }
    function d(e) {
      return void 0 === e
        ? e
        : "number" == typeof e
        ? Number.isFinite(e)
          ? e
          : NaN
        : "string" == typeof e && /^[0-9]+$/.test(e)
        ? parseInt(e, 10)
        : NaN;
    }
    function o(
      {
        src: e,
        sizes: t,
        unoptimized: s = !1,
        priority: o = !1,
        preload: c = !1,
        loading: m,
        className: x,
        quality: u,
        width: h,
        height: p,
        fill: f = !1,
        style: g,
        overrideSrc: b,
        onLoad: j,
        onLoadingComplete: N,
        placeholder: y = "empty",
        blurDataURL: v,
        fetchPriority: w,
        decoding: C = "async",
        layout: _,
        objectFit: k,
        objectPosition: P,
        lazyBoundary: S,
        lazyRoot: O,
        ...R
      },
      E
    ) {
      var D;
      let T,
        M,
        z,
        { imgConf: I, showAltText: A, blurComplete: F, defaultLoader: $ } = E,
        B = I || l.imageConfigDefault;
      if ("allSizes" in B) T = B;
      else {
        let e = [...B.deviceSizes, ...B.imageSizes].sort((e, t) => e - t),
          t = B.deviceSizes.sort((e, t) => e - t),
          s = B.qualities?.sort((e, t) => e - t);
        T = { ...B, allSizes: e, deviceSizes: t, qualities: s };
      }
      if (void 0 === $)
        throw Object.defineProperty(
          Error(
            "images.loaderFile detected but the file is missing default export.\nRead more: https://nextjs.org/docs/messages/invalid-images-config"
          ),
          "__NEXT_ERROR_CODE",
          { value: "E163", enumerable: !1, configurable: !0 }
        );
      let L = R.loader || $;
      delete R.loader, delete R.srcSet;
      let W = "__next_img_default" in L;
      if (W) {
        if ("custom" === T.loader)
          throw Object.defineProperty(
            Error(`Image with src "${e}" is missing "loader" prop.
Read more: https://nextjs.org/docs/messages/next-image-missing-loader`),
            "__NEXT_ERROR_CODE",
            { value: "E252", enumerable: !1, configurable: !0 }
          );
      } else {
        let e = L;
        L = (t) => {
          let { config: s, ...r } = t;
          return e(r);
        };
      }
      if (_) {
        "fill" === _ && (f = !0);
        let e = {
          intrinsic: { maxWidth: "100%", height: "auto" },
          responsive: { width: "100%", height: "auto" },
        }[_];
        e && (g = { ...g, ...e });
        let s = { responsive: "100vw", fill: "100vw" }[_];
        s && !t && (t = s);
      }
      let U = "",
        V = d(h),
        G = d(p);
      if ((D = e) && "object" == typeof D && (i(D) || void 0 !== D.src)) {
        let t = i(e) ? e.default : e;
        if (!t.src)
          throw Object.defineProperty(
            Error(
              `An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(
                t
              )}`
            ),
            "__NEXT_ERROR_CODE",
            { value: "E460", enumerable: !1, configurable: !0 }
          );
        if (!t.height || !t.width)
          throw Object.defineProperty(
            Error(
              `An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(
                t
              )}`
            ),
            "__NEXT_ERROR_CODE",
            { value: "E48", enumerable: !1, configurable: !0 }
          );
        if (
          ((M = t.blurWidth),
          (z = t.blurHeight),
          (v = v || t.blurDataURL),
          (U = t.src),
          !f)
        )
          if (V || G) {
            if (V && !G) {
              let e = V / t.width;
              G = Math.round(t.height * e);
            } else if (!V && G) {
              let e = G / t.height;
              V = Math.round(t.width * e);
            }
          } else (V = t.width), (G = t.height);
      }
      let q = !o && !c && ("lazy" === m || void 0 === m);
      (!(e = "string" == typeof e ? e : U) ||
        e.startsWith("data:") ||
        e.startsWith("blob:")) &&
        ((s = !0), (q = !1)),
        T.unoptimized && (s = !0),
        W &&
          !T.dangerouslyAllowSVG &&
          e.split("?", 1)[0].endsWith(".svg") &&
          (s = !0);
      let H = d(u),
        X = Object.assign(
          f
            ? {
                position: "absolute",
                height: "100%",
                width: "100%",
                left: 0,
                top: 0,
                right: 0,
                bottom: 0,
                objectFit: k,
                objectPosition: P,
              }
            : {},
          A ? {} : { color: "transparent" },
          g
        ),
        J =
          F || "empty" === y
            ? null
            : "blur" === y
            ? `url("data:image/svg+xml;charset=utf-8,${(0, a.getImageBlurSvg)({
                widthInt: V,
                heightInt: G,
                blurWidth: M,
                blurHeight: z,
                blurDataURL: v || "",
                objectFit: X.objectFit,
              })}")`
            : `url("${y}")`,
        K = n.includes(X.objectFit)
          ? "fill" === X.objectFit
            ? "100% 100%"
            : "cover"
          : X.objectFit,
        Q = J
          ? {
              backgroundSize: K,
              backgroundPosition: X.objectPosition || "50% 50%",
              backgroundRepeat: "no-repeat",
              backgroundImage: J,
            }
          : {},
        Y = (function ({
          config: e,
          src: t,
          unoptimized: s,
          width: a,
          quality: l,
          sizes: n,
          loader: i,
        }) {
          if (s) {
            let e = (0, r.getDeploymentId)();
            if (t.startsWith("/") && !t.startsWith("//") && e) {
              let s = t.includes("?") ? "&" : "?";
              t = `${t}${s}dpl=${e}`;
            }
            return { src: t, srcSet: void 0, sizes: void 0 };
          }
          let { widths: d, kind: o } = (function (
              { deviceSizes: e, allSizes: t },
              s,
              r
            ) {
              if (r) {
                let s = /(^|\s)(1?\d?\d)vw/g,
                  a = [];
                for (let e; (e = s.exec(r)); ) a.push(parseInt(e[2]));
                if (a.length) {
                  let s = 0.01 * Math.min(...a);
                  return { widths: t.filter((t) => t >= e[0] * s), kind: "w" };
                }
                return { widths: t, kind: "w" };
              }
              return "number" != typeof s
                ? { widths: e, kind: "w" }
                : {
                    widths: [
                      ...new Set(
                        [s, 2 * s].map(
                          (e) => t.find((t) => t >= e) || t[t.length - 1]
                        )
                      ),
                    ],
                    kind: "x",
                  };
            })(e, a, n),
            c = d.length - 1;
          return {
            sizes: n || "w" !== o ? n : "100vw",
            srcSet: d
              .map(
                (s, r) =>
                  `${i({ config: e, src: t, quality: l, width: s })} ${
                    "w" === o ? s : r + 1
                  }${o}`
              )
              .join(", "),
            src: i({ config: e, src: t, quality: l, width: d[c] }),
          };
        })({
          config: T,
          src: e,
          unoptimized: s,
          width: V,
          quality: H,
          sizes: t,
          loader: L,
        }),
        Z = q ? "lazy" : m;
      return {
        props: {
          ...R,
          loading: Z,
          fetchPriority: w,
          width: V,
          height: G,
          decoding: C,
          className: x,
          style: { ...X, ...Q },
          sizes: Y.sizes,
          srcSet: Y.srcSet,
          src: b || Y.src,
        },
        meta: { unoptimized: s, preload: c || o, placeholder: y, fill: f },
      };
    }
  },
  87478,
  (e, t, s) => {
    "use strict";
    Object.defineProperty(s, "__esModule", { value: !0 }),
      Object.defineProperty(s, "default", {
        enumerable: !0,
        get: function () {
          return i;
        },
      });
    let r = e.r(80883),
      a = "undefined" == typeof window,
      l = a ? () => {} : r.useLayoutEffect,
      n = a ? () => {} : r.useEffect;
    function i(e) {
      let { headManager: t, reduceComponentsToState: s } = e;
      function i() {
        if (t && t.mountedInstances) {
          let e = r.Children.toArray(
            Array.from(t.mountedInstances).filter(Boolean)
          );
          t.updateHead(s(e));
        }
      }
      return (
        a && (t?.mountedInstances?.add(e.children), i()),
        l(
          () => (
            t?.mountedInstances?.add(e.children),
            () => {
              t?.mountedInstances?.delete(e.children);
            }
          )
        ),
        l(
          () => (
            t && (t._pendingUpdate = i),
            () => {
              t && (t._pendingUpdate = i);
            }
          )
        ),
        n(
          () => (
            t &&
              t._pendingUpdate &&
              (t._pendingUpdate(), (t._pendingUpdate = null)),
            () => {
              t &&
                t._pendingUpdate &&
                (t._pendingUpdate(), (t._pendingUpdate = null));
            }
          )
        ),
        null
      );
    }
  },
  50561,
  (e, t, s) => {
    "use strict";
    Object.defineProperty(s, "__esModule", { value: !0 });
    var r = {
      default: function () {
        return p;
      },
      defaultHead: function () {
        return m;
      },
    };
    for (var a in r) Object.defineProperty(s, a, { enumerable: !0, get: r[a] });
    let l = e.r(81258),
      n = e.r(44066),
      i = e.r(93046),
      d = n._(e.r(80883)),
      o = l._(e.r(87478)),
      c = e.r(76361);
    function m() {
      return [
        (0, i.jsx)("meta", { charSet: "utf-8" }, "charset"),
        (0, i.jsx)(
          "meta",
          { name: "viewport", content: "width=device-width" },
          "viewport"
        ),
      ];
    }
    function x(e, t) {
      return "string" == typeof t || "number" == typeof t
        ? e
        : t.type === d.default.Fragment
        ? e.concat(
            d.default.Children.toArray(t.props.children).reduce(
              (e, t) =>
                "string" == typeof t || "number" == typeof t ? e : e.concat(t),
              []
            )
          )
        : e.concat(t);
    }
    e.r(60835);
    let u = ["name", "httpEquiv", "charSet", "itemProp"];
    function h(e) {
      let t, s, r, a;
      return e
        .reduce(x, [])
        .reverse()
        .concat(m().reverse())
        .filter(
          ((t = new Set()),
          (s = new Set()),
          (r = new Set()),
          (a = {}),
          (e) => {
            let l = !0,
              n = !1;
            if (e.key && "number" != typeof e.key && e.key.indexOf("$") > 0) {
              n = !0;
              let s = e.key.slice(e.key.indexOf("$") + 1);
              t.has(s) ? (l = !1) : t.add(s);
            }
            switch (e.type) {
              case "title":
              case "base":
                s.has(e.type) ? (l = !1) : s.add(e.type);
                break;
              case "meta":
                for (let t = 0, s = u.length; t < s; t++) {
                  let s = u[t];
                  if (e.props.hasOwnProperty(s))
                    if ("charSet" === s) r.has(s) ? (l = !1) : r.add(s);
                    else {
                      let t = e.props[s],
                        r = a[s] || new Set();
                      ("name" !== s || !n) && r.has(t)
                        ? (l = !1)
                        : (r.add(t), (a[s] = r));
                    }
                }
            }
            return l;
          })
        )
        .reverse()
        .map((e, t) => {
          let s = e.key || t;
          return d.default.cloneElement(e, { key: s });
        });
    }
    let p = function ({ children: e }) {
      let t = (0, d.useContext)(c.HeadManagerContext);
      return (0, i.jsx)(o.default, {
        reduceComponentsToState: h,
        headManager: t,
        children: e,
      });
    };
    ("function" == typeof s.default ||
      ("object" == typeof s.default && null !== s.default)) &&
      void 0 === s.default.__esModule &&
      (Object.defineProperty(s.default, "__esModule", { value: !0 }),
      Object.assign(s.default, s),
      (t.exports = s.default));
  },
  85266,
  (e, t, s) => {
    "use strict";
    Object.defineProperty(s, "__esModule", { value: !0 }),
      Object.defineProperty(s, "ImageConfigContext", {
        enumerable: !0,
        get: function () {
          return l;
        },
      });
    let r = e.r(81258)._(e.r(80883)),
      a = e.r(84489),
      l = r.default.createContext(a.imageConfigDefault);
  },
  45251,
  (e, t, s) => {
    "use strict";
    Object.defineProperty(s, "__esModule", { value: !0 }),
      Object.defineProperty(s, "RouterContext", {
        enumerable: !0,
        get: function () {
          return r;
        },
      });
    let r = e.r(81258)._(e.r(80883)).default.createContext(null);
  },
  84821,
  (e, t, s) => {
    "use strict";
    function r(e, t) {
      let s = e || 75;
      return t?.qualities?.length
        ? t.qualities.reduce(
            (e, t) => (Math.abs(t - s) < Math.abs(e - s) ? t : e),
            0
          )
        : s;
    }
    Object.defineProperty(s, "__esModule", { value: !0 }),
      Object.defineProperty(s, "findClosestQuality", {
        enumerable: !0,
        get: function () {
          return r;
        },
      });
  },
  99772,
  (e, t, s) => {
    "use strict";
    Object.defineProperty(s, "__esModule", { value: !0 }),
      Object.defineProperty(s, "default", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let r = e.r(84821),
      a = e.r(4226);
    function l({ config: e, src: t, width: s, quality: l }) {
      if (
        t.startsWith("/") &&
        t.includes("?") &&
        e.localPatterns?.length === 1 &&
        "**" === e.localPatterns[0].pathname &&
        "" === e.localPatterns[0].search
      )
        throw Object.defineProperty(
          Error(`Image with src "${t}" is using a query string which is not configured in images.localPatterns.
Read more: https://nextjs.org/docs/messages/next-image-unconfigured-localpatterns`),
          "__NEXT_ERROR_CODE",
          { value: "E871", enumerable: !1, configurable: !0 }
        );
      let n = (0, r.findClosestQuality)(l, e),
        i = (0, a.getDeploymentId)();
      return `${e.path}?url=${encodeURIComponent(t)}&w=${s}&q=${n}${
        t.startsWith("/") && i ? `&dpl=${i}` : ""
      }`;
    }
    l.__next_img_default = !0;
    let n = l;
  },
  20673,
  (e, t, s) => {
    "use strict";
    Object.defineProperty(s, "__esModule", { value: !0 }),
      Object.defineProperty(s, "Image", {
        enumerable: !0,
        get: function () {
          return N;
        },
      });
    let r = e.r(81258),
      a = e.r(44066),
      l = e.r(93046),
      n = a._(e.r(80883)),
      i = r._(e.r(36425)),
      d = r._(e.r(50561)),
      o = e.r(93420),
      c = e.r(84489),
      m = e.r(85266);
    e.r(60835);
    let x = e.r(45251),
      u = r._(e.r(99772)),
      h = e.r(60203),
      p = {
        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
        imageSizes: [32, 48, 64, 96, 128, 256, 384],
        qualities: [75],
        path: "/_next/image",
        loader: "default",
        dangerouslyAllowSVG: !1,
        unoptimized: !0,
      };
    function f(e, t, s, r, a, l, n) {
      let i = e?.src;
      e &&
        e["data-loaded-src"] !== i &&
        ((e["data-loaded-src"] = i),
        ("decode" in e ? e.decode() : Promise.resolve())
          .catch(() => {})
          .then(() => {
            if (e.parentElement && e.isConnected) {
              if (("empty" !== t && a(!0), s?.current)) {
                let t = new Event("load");
                Object.defineProperty(t, "target", { writable: !1, value: e });
                let r = !1,
                  a = !1;
                s.current({
                  ...t,
                  nativeEvent: t,
                  currentTarget: e,
                  target: e,
                  isDefaultPrevented: () => r,
                  isPropagationStopped: () => a,
                  persist: () => {},
                  preventDefault: () => {
                    (r = !0), t.preventDefault();
                  },
                  stopPropagation: () => {
                    (a = !0), t.stopPropagation();
                  },
                });
              }
              r?.current && r.current(e);
            }
          }));
    }
    function g(e) {
      return n.use ? { fetchPriority: e } : { fetchpriority: e };
    }
    "undefined" == typeof window && (globalThis.__NEXT_IMAGE_IMPORTED = !0);
    let b = (0, n.forwardRef)(
      (
        {
          src: e,
          srcSet: t,
          sizes: s,
          height: r,
          width: a,
          decoding: i,
          className: d,
          style: o,
          fetchPriority: c,
          placeholder: m,
          loading: x,
          unoptimized: u,
          fill: p,
          onLoadRef: b,
          onLoadingCompleteRef: j,
          setBlurComplete: N,
          setShowAltText: y,
          sizesInput: v,
          onLoad: w,
          onError: C,
          ..._
        },
        k
      ) => {
        let P = (0, n.useCallback)(
            (e) => {
              e && (C && (e.src = e.src), e.complete && f(e, m, b, j, N, u, v));
            },
            [e, m, b, j, N, C, u, v]
          ),
          S = (0, h.useMergedRef)(k, P);
        return (0, l.jsx)("img", {
          ..._,
          ...g(c),
          loading: x,
          width: a,
          height: r,
          decoding: i,
          "data-nimg": p ? "fill" : "1",
          className: d,
          style: o,
          sizes: s,
          srcSet: t,
          src: e,
          ref: S,
          onLoad: (e) => {
            f(e.currentTarget, m, b, j, N, u, v);
          },
          onError: (e) => {
            y(!0), "empty" !== m && N(!0), C && C(e);
          },
        });
      }
    );
    function j({ isAppRouter: e, imgAttributes: t }) {
      let s = {
        as: "image",
        imageSrcSet: t.srcSet,
        imageSizes: t.sizes,
        crossOrigin: t.crossOrigin,
        referrerPolicy: t.referrerPolicy,
        ...g(t.fetchPriority),
      };
      return e && i.default.preload
        ? (i.default.preload(t.src, s), null)
        : (0, l.jsx)(d.default, {
            children: (0, l.jsx)(
              "link",
              { rel: "preload", href: t.srcSet ? void 0 : t.src, ...s },
              "__nimg-" + t.src + t.srcSet + t.sizes
            ),
          });
    }
    let N = (0, n.forwardRef)((e, t) => {
      let s = (0, n.useContext)(x.RouterContext),
        r = (0, n.useContext)(m.ImageConfigContext),
        a = (0, n.useMemo)(() => {
          let e = p || r || c.imageConfigDefault,
            t = [...e.deviceSizes, ...e.imageSizes].sort((e, t) => e - t),
            s = e.deviceSizes.sort((e, t) => e - t),
            a = e.qualities?.sort((e, t) => e - t);
          return {
            ...e,
            allSizes: t,
            deviceSizes: s,
            qualities: a,
            localPatterns:
              "undefined" == typeof window ? r?.localPatterns : e.localPatterns,
          };
        }, [r]),
        { onLoad: i, onLoadingComplete: d } = e,
        h = (0, n.useRef)(i);
      (0, n.useEffect)(() => {
        h.current = i;
      }, [i]);
      let f = (0, n.useRef)(d);
      (0, n.useEffect)(() => {
        f.current = d;
      }, [d]);
      let [g, N] = (0, n.useState)(!1),
        [y, v] = (0, n.useState)(!1),
        { props: w, meta: C } = (0, o.getImgProps)(e, {
          defaultLoader: u.default,
          imgConf: a,
          blurComplete: g,
          showAltText: y,
        });
      return (0, l.jsxs)(l.Fragment, {
        children: [
          (0, l.jsx)(b, {
            ...w,
            unoptimized: C.unoptimized,
            placeholder: C.placeholder,
            fill: C.fill,
            onLoadRef: h,
            onLoadingCompleteRef: f,
            setBlurComplete: N,
            setShowAltText: v,
            sizesInput: e.sizes,
            ref: t,
          }),
          C.preload
            ? (0, l.jsx)(j, { isAppRouter: !s, imgAttributes: w })
            : null,
        ],
      });
    });
    ("function" == typeof s.default ||
      ("object" == typeof s.default && null !== s.default)) &&
      void 0 === s.default.__esModule &&
      (Object.defineProperty(s.default, "__esModule", { value: !0 }),
      Object.assign(s.default, s),
      (t.exports = s.default));
  },
  93867,
  (e, t, s) => {
    "use strict";
    Object.defineProperty(s, "__esModule", { value: !0 });
    var r = {
      default: function () {
        return c;
      },
      getImageProps: function () {
        return o;
      },
    };
    for (var a in r) Object.defineProperty(s, a, { enumerable: !0, get: r[a] });
    let l = e.r(81258),
      n = e.r(93420),
      i = e.r(20673),
      d = l._(e.r(99772));
    function o(e) {
      let { props: t } = (0, n.getImgProps)(e, {
        defaultLoader: d.default,
        imgConf: {
          deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
          imageSizes: [32, 48, 64, 96, 128, 256, 384],
          qualities: [75],
          path: "/_next/image",
          loader: "default",
          dangerouslyAllowSVG: !1,
          unoptimized: !0,
        },
      });
      for (let [e, s] of Object.entries(t)) void 0 === s && delete t[e];
      return { props: t };
    }
    let c = i.Image;
  },
  5295,
  (e, t, s) => {
    t.exports = e.r(93867);
  },
  33366,
  (e) => {
    "use strict";
    var t = e.i(93046),
      s = e.i(80883),
      r = e.i(13293),
      a = e.i(76841),
      l = e.i(94179),
      n = e.i(70065),
      i = e.i(81947),
      d = e.i(67881),
      o = e.i(84675),
      c = e.i(13637),
      m = e.i(10965);
    let x = (0, m.default)("ExternalLink", [
      ["path", { d: "M15 3h6v6", key: "1q9fwt" }],
      ["path", { d: "M10 14 21 3", key: "gplh6r" }],
      [
        "path",
        {
          d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",
          key: "a6xqqp",
        },
      ],
    ]);
    var u = e.i(42838),
      h = e.i(49056),
      p = e.i(48054);
    let f = (0, m.default)("Wrench", [
      [
        "path",
        {
          d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z",
          key: "cbrjhi",
        },
      ],
    ]);
    var g = e.i(64877);
    let b = (0, m.default)("Clock", [
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
      ["polyline", { points: "12 6 12 12 16 14", key: "68esgv" }],
    ]);
    var j = e.i(88297),
      N = e.i(17508),
      y = e.i(52910),
      v = e.i(61021),
      w = e.i(5295);
    function C() {
      let [e, m] = (0, s.useState)(1),
        [C, _] = (0, s.useState)(!1),
        k = (e / 4) * 100;
      return (0, t.jsxs)("main", {
        className: "min-h-screen bg-background",
        children: [
          (0, t.jsx)(r.Header, {}),
          (0, t.jsx)("section", {
            className:
              "relative py-20 px-4 bg-gradient-to-b from-primary/20 to-background border-b border-border",
            children: (0, t.jsxs)("div", {
              className: "container mx-auto",
              children: [
                (0, t.jsxs)(v.default, {
                  href: "/",
                  className:
                    "inline-flex items-center text-primary hover:text-primary/80 mb-6 transition-colors",
                  children: [
                    (0, t.jsx)(o.ArrowLeft, { className: "mr-2 h-4 w-4" }),
                    "Back to Products",
                  ],
                }),
                (0, t.jsxs)("div", {
                  className: "flex flex-col md:flex-row gap-8 items-center",
                  children: [
                    (0, t.jsx)("div", {
                      className:
                        "relative w-full md:w-64 h-80 rounded-lg overflow-hidden border-2 border-primary/50 shadow-lg shadow-primary/20",
                      children: (0, t.jsx)(w.default, {
                        src: "/images/image.png",
                        alt: "Valorant",
                        fill: !0,
                        className: "object-cover",
                      }),
                    }),
                    (0, t.jsxs)("div", {
                      className: "flex-1",
                      children: [
                        (0, t.jsx)(l.Badge, {
                          className:
                            "mb-4 bg-primary/90 text-primary-foreground",
                          children: "FPS Tactical",
                        }),
                        (0, t.jsx)("h1", {
                          className: "text-5xl font-bold mb-4 text-foreground",
                          children: "Valorant Setup Guide",
                        }),
                        (0, t.jsx)("p", {
                          className:
                            "text-xl text-muted-foreground leading-relaxed",
                          children:
                            "Complete step-by-step instructions for setting up and using the Valorant loader. Follow each step carefully to ensure proper installation and functionality.",
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
          }),
          (0, t.jsx)("section", {
            className:
              "sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border py-4 px-4",
            children: (0, t.jsxs)("div", {
              className: "container mx-auto max-w-5xl",
              children: [
                (0, t.jsxs)("div", {
                  className: "flex items-center justify-between mb-3",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "text-sm font-medium text-foreground",
                      children: ["Step ", e, " of ", 4],
                    }),
                    (0, t.jsxs)("div", {
                      className: "text-sm text-muted-foreground",
                      children: [k.toFixed(0), "% Complete"],
                    }),
                  ],
                }),
                (0, t.jsx)("div", {
                  className: "h-2 bg-muted rounded-full overflow-hidden",
                  children: (0, t.jsx)("div", {
                    className:
                      "h-full bg-primary transition-all duration-500 ease-out",
                    style: { width: `${k}%` },
                  }),
                }),
              ],
            }),
          }),
          (0, t.jsx)("section", {
            className: "py-16 px-4 min-h-[600px]",
            children: (0, t.jsxs)("div", {
              className: "container mx-auto max-w-5xl",
              children: [
                1 === e &&
                  (0, t.jsxs)("div", {
                    className: "animate-in fade-in duration-500",
                    children: [
                      (0, t.jsxs)("div", {
                        className: "flex items-center gap-4 mb-8",
                        children: [
                          (0, t.jsx)("div", {
                            className:
                              "w-20 h-20 rounded-2xl bg-blue-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-blue-500/30",
                            children: "1",
                          }),
                          (0, t.jsxs)("div", {
                            children: [
                              (0, t.jsx)("h2", {
                                className:
                                  "text-5xl font-bold text-foreground mb-2",
                                children: "Turn Off Antivirus",
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground text-xl",
                                children:
                                  "Stop Windows from blocking the loader",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, t.jsx)(n.Card, {
                        className:
                          "border-blue-500/30 bg-blue-500/5 backdrop-blur",
                        children: (0, t.jsxs)(n.CardContent, {
                          className: "pt-8 space-y-8",
                          children: [
                            (0, t.jsx)("div", {
                              className: "space-y-4",
                              children: (0, t.jsxs)("div", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, t.jsx)(u.Shield, {
                                    className:
                                      "h-6 w-6 text-blue-500 mt-1 shrink-0",
                                  }),
                                  (0, t.jsxs)("div", {
                                    className: "flex-1",
                                    children: [
                                      (0, t.jsx)("h4", {
                                        className:
                                          "text-xl font-semibold mb-4 text-foreground",
                                        children: "Manual Way",
                                      }),
                                      (0, t.jsxs)("div", {
                                        className:
                                          "space-y-3 text-muted-foreground",
                                        children: [
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-start gap-3 text-lg",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-blue-500 font-bold text-xl",
                                                children: "→",
                                              }),
                                              "Open",
                                              " ",
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-foreground font-medium px-2 py-1 bg-secondary rounded",
                                                children: "Windows Security",
                                              }),
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-start gap-3 text-lg",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-blue-500 font-bold text-xl",
                                                children: "→",
                                              }),
                                              "Click",
                                              " ",
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-foreground font-medium px-2 py-1 bg-secondary rounded",
                                                children:
                                                  "Virus & Threat Protection",
                                              }),
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-start gap-3 text-lg",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-blue-500 font-bold text-xl",
                                                children: "→",
                                              }),
                                              "Click",
                                              " ",
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-foreground font-medium px-2 py-1 bg-secondary rounded",
                                                children: "Manage Settings",
                                              }),
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-start gap-3 text-lg",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-blue-500 font-bold text-xl",
                                                children: "→",
                                              }),
                                              "Turn OFF everything (Real-time, Tamper, Cloud, all of it)",
                                            ],
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                            (0, t.jsx)("div", { className: "h-px bg-border" }),
                            (0, t.jsx)("div", {
                              className: "space-y-4",
                              children: (0, t.jsxs)("div", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, t.jsx)(h.Settings, {
                                    className:
                                      "h-6 w-6 text-blue-500 mt-1 shrink-0",
                                  }),
                                  (0, t.jsxs)("div", {
                                    className: "flex-1",
                                    children: [
                                      (0, t.jsx)("h4", {
                                        className:
                                          "text-xl font-semibold mb-4 text-foreground",
                                        children:
                                          "Easy Way with dControl (Better)",
                                      }),
                                      (0, t.jsxs)("div", {
                                        className:
                                          "space-y-3 text-muted-foreground mb-6",
                                        children: [
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-start gap-3 text-lg",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-blue-500 font-bold text-xl",
                                                children: "→",
                                              }),
                                              "Download dControl",
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-start gap-3 text-lg",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-blue-500 font-bold text-xl",
                                                children: "→",
                                              }),
                                              "Right-click → ",
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-foreground font-medium",
                                                children:
                                                  "Run as Administrator",
                                              }),
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-start gap-3 text-lg",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-blue-500 font-bold text-xl",
                                                children: "→",
                                              }),
                                              "Click to disable Windows Defender",
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-start gap-3 text-lg",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className:
                                                  "text-blue-500 font-bold text-xl",
                                                children: "→",
                                              }),
                                              "Make sure it says OFF",
                                            ],
                                          }),
                                        ],
                                      }),
                                      (0, t.jsxs)(i.Alert, {
                                        className:
                                          "border-blue-500/50 bg-blue-500/10",
                                        children: [
                                          (0, t.jsx)(c.Download, {
                                            className: "h-4 w-4 text-blue-500",
                                          }),
                                          (0, t.jsx)(i.AlertDescription, {
                                            children: (0, t.jsxs)("div", {
                                              className: "space-y-3",
                                              children: [
                                                (0, t.jsx)("p", {
                                                  className:
                                                    "font-semibold text-foreground text-lg",
                                                  children:
                                                    "Download dControl:",
                                                }),
                                                (0, t.jsxs)("a", {
                                                  href: "https://content.gitbook.com/content/GX215IYet7df7lTywp3p/blobs/8VIaLdTwubOA0G2iVJAR/DControl.rar",
                                                  target: "_blank",
                                                  rel: "noopener noreferrer",
                                                  className:
                                                    "text-blue-500 hover:underline flex items-center gap-1 font-medium text-lg",
                                                  children: [
                                                    "Download Here ",
                                                    (0, t.jsx)(x, {
                                                      className: "h-4 w-4",
                                                    }),
                                                  ],
                                                }),
                                                (0, t.jsxs)("p", {
                                                  className: "text-base",
                                                  children: [
                                                    "Password:",
                                                    " ",
                                                    (0, t.jsx)("span", {
                                                      className:
                                                        "font-mono bg-secondary px-2 py-1 rounded text-foreground font-semibold",
                                                      children: "sordum",
                                                    }),
                                                  ],
                                                }),
                                              ],
                                            }),
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                2 === e &&
                  (0, t.jsxs)("div", {
                    className: "animate-in fade-in duration-500",
                    children: [
                      (0, t.jsxs)("div", {
                        className: "flex items-center gap-4 mb-8",
                        children: [
                          (0, t.jsx)("div", {
                            className:
                              "w-20 h-20 rounded-2xl bg-purple-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-purple-500/30",
                            children: "2",
                          }),
                          (0, t.jsxs)("div", {
                            children: [
                              (0, t.jsx)("h2", {
                                className:
                                  "text-5xl font-bold text-foreground mb-2",
                                children: "Install Drivers",
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground text-xl",
                                children:
                                  "Download these so the loader can run",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, t.jsxs)("div", {
                        className: "grid gap-6",
                        children: [
                          (0, t.jsx)(n.Card, {
                            className:
                              "border-purple-500/30 bg-purple-500/5 backdrop-blur",
                            children: (0, t.jsx)(n.CardContent, {
                              className: "pt-8",
                              children: (0, t.jsxs)("div", {
                                className:
                                  "flex items-start justify-between gap-4",
                                children: [
                                  (0, t.jsxs)("div", {
                                    className: "flex-1",
                                    children: [
                                      (0, t.jsx)("h4", {
                                        className:
                                          "text-2xl font-semibold mb-3 text-foreground",
                                        children: "DirectX",
                                      }),
                                      (0, t.jsx)("p", {
                                        className:
                                          "text-muted-foreground mb-4 text-lg",
                                        children: "For graphics and games",
                                      }),
                                      (0, t.jsxs)("div", {
                                        className:
                                          "text-base text-muted-foreground space-y-2",
                                        children: [
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-center gap-2",
                                            children: [
                                              (0, t.jsx)(j.CheckCircle, {
                                                className:
                                                  "h-5 w-5 text-purple-500",
                                              }),
                                              "Run the installer",
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-center gap-2",
                                            children: [
                                              (0, t.jsx)(j.CheckCircle, {
                                                className:
                                                  "h-5 w-5 text-purple-500",
                                              }),
                                              "Restart if it asks",
                                            ],
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, t.jsx)(d.Button, {
                                    className:
                                      "bg-purple-500 hover:bg-purple-600 text-white shrink-0 h-12 px-6 text-base",
                                    asChild: !0,
                                    children: (0, t.jsxs)("a", {
                                      href: "https://www.microsoft.com/en-us/download/details.aspx?id=35",
                                      target: "_blank",
                                      rel: "noopener noreferrer",
                                      children: [
                                        (0, t.jsx)(c.Download, {
                                          className: "h-5 w-5 mr-2",
                                        }),
                                        "Download",
                                      ],
                                    }),
                                  }),
                                ],
                              }),
                            }),
                          }),
                          (0, t.jsx)(n.Card, {
                            className:
                              "border-purple-500/30 bg-purple-500/5 backdrop-blur",
                            children: (0, t.jsx)(n.CardContent, {
                              className: "pt-8",
                              children: (0, t.jsxs)("div", {
                                className:
                                  "flex items-start justify-between gap-4",
                                children: [
                                  (0, t.jsxs)("div", {
                                    className: "flex-1",
                                    children: [
                                      (0, t.jsx)("h4", {
                                        className:
                                          "text-2xl font-semibold mb-3 text-foreground",
                                        children: "Visual C++",
                                      }),
                                      (0, t.jsx)("p", {
                                        className:
                                          "text-muted-foreground mb-4 text-lg",
                                        children:
                                          "Needed for the loader to work",
                                      }),
                                      (0, t.jsxs)("div", {
                                        className:
                                          "text-base text-muted-foreground space-y-2",
                                        children: [
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-center gap-2",
                                            children: [
                                              (0, t.jsx)(j.CheckCircle, {
                                                className:
                                                  "h-5 w-5 text-purple-500",
                                              }),
                                              "Extract the ZIP file",
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-center gap-2",
                                            children: [
                                              (0, t.jsx)(j.CheckCircle, {
                                                className:
                                                  "h-5 w-5 text-purple-500",
                                              }),
                                              "Run installer (installs everything)",
                                            ],
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, t.jsx)(d.Button, {
                                    className:
                                      "bg-purple-500 hover:bg-purple-600 text-white shrink-0 h-12 px-6 text-base",
                                    asChild: !0,
                                    children: (0, t.jsxs)("a", {
                                      href: "https://www.techpowerup.com/download/visual-c-redistributable-runtime-package-all-in-one/",
                                      target: "_blank",
                                      rel: "noopener noreferrer",
                                      children: [
                                        (0, t.jsx)(c.Download, {
                                          className: "h-5 w-5 mr-2",
                                        }),
                                        "Download",
                                      ],
                                    }),
                                  }),
                                ],
                              }),
                            }),
                          }),
                          (0, t.jsx)(n.Card, {
                            className:
                              "border-purple-500/30 bg-purple-500/5 backdrop-blur",
                            children: (0, t.jsx)(n.CardContent, {
                              className: "pt-8",
                              children: (0, t.jsxs)("div", {
                                className:
                                  "flex items-start justify-between gap-4",
                                children: [
                                  (0, t.jsxs)("div", {
                                    className: "flex-1",
                                    children: [
                                      (0, t.jsxs)("h4", {
                                        className:
                                          "text-2xl font-semibold mb-3 text-foreground",
                                        children: [
                                          ".NET Framework",
                                          " ",
                                          (0, t.jsx)(l.Badge, {
                                            variant: "outline",
                                            className: "ml-2 text-base",
                                            children: "Optional",
                                          }),
                                        ],
                                      }),
                                      (0, t.jsx)("p", {
                                        className:
                                          "text-muted-foreground mb-4 text-lg",
                                        children:
                                          "Not required but good to have",
                                      }),
                                      (0, t.jsxs)("div", {
                                        className:
                                          "text-base text-muted-foreground space-y-2",
                                        children: [
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-center gap-2",
                                            children: [
                                              (0, t.jsx)(j.CheckCircle, {
                                                className:
                                                  "h-5 w-5 text-purple-500",
                                              }),
                                              "Run installer and wait",
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-center gap-2",
                                            children: [
                                              (0, t.jsx)(j.CheckCircle, {
                                                className:
                                                  "h-5 w-5 text-purple-500",
                                              }),
                                              "Restart if asked",
                                            ],
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, t.jsx)(d.Button, {
                                    className:
                                      "bg-purple-500 hover:bg-purple-600 text-white shrink-0 h-12 px-6 text-base",
                                    asChild: !0,
                                    children: (0, t.jsxs)("a", {
                                      href: "https://dotnet.microsoft.com/en-us/download/dotnet-framework/net481",
                                      target: "_blank",
                                      rel: "noopener noreferrer",
                                      children: [
                                        (0, t.jsx)(c.Download, {
                                          className: "h-5 w-5 mr-2",
                                        }),
                                        "Download",
                                      ],
                                    }),
                                  }),
                                ],
                              }),
                            }),
                          }),
                          (0, t.jsx)(n.Card, {
                            className:
                              "border-purple-500/30 bg-purple-500/5 backdrop-blur",
                            children: (0, t.jsx)(n.CardContent, {
                              className: "pt-8",
                              children: (0, t.jsxs)("div", {
                                children: [
                                  (0, t.jsxs)("h4", {
                                    className:
                                      "text-2xl font-semibold mb-3 text-foreground",
                                    children: [
                                      "GPU Drivers",
                                      " ",
                                      (0, t.jsx)(l.Badge, {
                                        variant: "outline",
                                        className: "ml-2 text-base",
                                        children: "If you need them",
                                      }),
                                    ],
                                  }),
                                  (0, t.jsx)("p", {
                                    className:
                                      "text-muted-foreground mb-6 text-lg",
                                    children: "Update your graphics card",
                                  }),
                                  (0, t.jsxs)("div", {
                                    className: "flex gap-4",
                                    children: [
                                      (0, t.jsx)(d.Button, {
                                        variant: "outline",
                                        className:
                                          "bg-transparent h-12 px-6 text-base",
                                        asChild: !0,
                                        children: (0, t.jsx)("a", {
                                          href: "https://www.nvidia.com/en-us/drivers",
                                          target: "_blank",
                                          rel: "noopener noreferrer",
                                          children: "NVIDIA",
                                        }),
                                      }),
                                      (0, t.jsx)(d.Button, {
                                        variant: "outline",
                                        className:
                                          "bg-transparent h-12 px-6 text-base",
                                        asChild: !0,
                                        children: (0, t.jsx)("a", {
                                          href: "https://www.amd.com/en/support/download/drivers.html",
                                          target: "_blank",
                                          rel: "noopener noreferrer",
                                          children: "AMD",
                                        }),
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                          }),
                        ],
                      }),
                    ],
                  }),
                3 === e &&
                  (0, t.jsxs)("div", {
                    className: "animate-in fade-in duration-500",
                    children: [
                      (0, t.jsxs)("div", {
                        className: "flex items-center gap-4 mb-8",
                        children: [
                          (0, t.jsx)("div", {
                            className:
                              "w-20 h-20 rounded-2xl bg-primary flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-primary/30",
                            children: "3",
                          }),
                          (0, t.jsxs)("div", {
                            children: [
                              (0, t.jsx)("h2", {
                                className:
                                  "text-5xl font-bold text-foreground mb-2",
                                children: "Fix Timezone",
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground text-xl",
                                children: "Turn on automatic time",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, t.jsx)(n.Card, {
                        className:
                          "border-primary/30 bg-primary/5 backdrop-blur",
                        children: (0, t.jsx)(n.CardContent, {
                          className: "pt-8",
                          children: (0, t.jsxs)("div", {
                            className: "space-y-6",
                            children: [
                              (0, t.jsxs)("div", {
                                className: "flex items-start gap-3",
                                children: [
                                  (0, t.jsx)(b, {
                                    className:
                                      "h-6 w-6 text-primary mt-1 shrink-0",
                                  }),
                                  (0, t.jsxs)("div", {
                                    className: "flex-1 space-y-4",
                                    children: [
                                      (0, t.jsxs)("p", {
                                        className:
                                          "text-muted-foreground flex items-start gap-3 text-lg",
                                        children: [
                                          (0, t.jsx)("span", {
                                            className:
                                              "text-primary font-bold text-xl",
                                            children: "→",
                                          }),
                                          "Open",
                                          " ",
                                          (0, t.jsx)("span", {
                                            className:
                                              "text-foreground font-medium px-2 py-1 bg-secondary rounded",
                                            children: "Settings",
                                          }),
                                          " →",
                                          " ",
                                          (0, t.jsx)("span", {
                                            className:
                                              "text-foreground font-medium px-2 py-1 bg-secondary rounded",
                                            children: "Date & Time",
                                          }),
                                        ],
                                      }),
                                      (0, t.jsxs)("p", {
                                        className:
                                          "text-muted-foreground flex items-start gap-3 text-lg",
                                        children: [
                                          (0, t.jsx)("span", {
                                            className:
                                              "text-primary font-bold text-xl",
                                            children: "→",
                                          }),
                                          "Turn ON",
                                          " ",
                                          (0, t.jsx)("span", {
                                            className:
                                              "text-foreground font-medium px-2 py-1 bg-secondary rounded",
                                            children:
                                              '"Set time automatically"',
                                          }),
                                        ],
                                      }),
                                      (0, t.jsxs)("p", {
                                        className:
                                          "text-muted-foreground flex items-start gap-3 text-lg",
                                        children: [
                                          (0, t.jsx)("span", {
                                            className:
                                              "text-primary font-bold text-xl",
                                            children: "→",
                                          }),
                                          "Turn ON",
                                          " ",
                                          (0, t.jsx)("span", {
                                            className:
                                              "text-foreground font-medium px-2 py-1 bg-secondary rounded",
                                            children:
                                              '"Set time zone automatically"',
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, t.jsxs)(i.Alert, {
                                className:
                                  "border-yellow-500/50 bg-yellow-500/10",
                                children: [
                                  (0, t.jsx)(g.AlertTriangle, {
                                    className: "h-5 w-5 text-yellow-500",
                                  }),
                                  (0, t.jsxs)(i.AlertDescription, {
                                    children: [
                                      (0, t.jsx)("p", {
                                        className:
                                          "font-semibold mb-3 text-foreground text-lg",
                                        children:
                                          "If the time zone box is grayed out:",
                                      }),
                                      (0, t.jsxs)("div", {
                                        className:
                                          "space-y-2 text-base text-muted-foreground",
                                        children: [
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-center gap-2",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className: "text-yellow-500",
                                                children: "•",
                                              }),
                                              "Search ",
                                              (0, t.jsx)("span", {
                                                className:
                                                  "font-medium text-foreground",
                                                children: "Location",
                                              }),
                                              " in Windows",
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-center gap-2",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className: "text-yellow-500",
                                                children: "•",
                                              }),
                                              "Turn on Location Access",
                                            ],
                                          }),
                                          (0, t.jsxs)("p", {
                                            className:
                                              "flex items-center gap-2",
                                            children: [
                                              (0, t.jsx)("span", {
                                                className: "text-yellow-500",
                                                children: "•",
                                              }),
                                              "Sync time and you're good",
                                            ],
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                      }),
                    ],
                  }),
                4 === e &&
                  (0, t.jsxs)("div", {
                    className: "animate-in fade-in duration-500",
                    children: [
                      (0, t.jsxs)("div", {
                        className: "flex items-center gap-4 mb-8",
                        children: [
                          (0, t.jsx)("div", {
                            className:
                              "w-20 h-20 rounded-2xl bg-green-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-green-500/30",
                            children: "4",
                          }),
                          (0, t.jsxs)("div", {
                            children: [
                              (0, t.jsx)("h2", {
                                className:
                                  "text-5xl font-bold text-foreground mb-2",
                                children: "Get the Loader",
                              }),
                              (0, t.jsx)("p", {
                                className: "text-muted-foreground text-xl",
                                children: "Download and run",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, t.jsxs)("div", {
                        className: "grid gap-6",
                        children: [
                          (0, t.jsx)(n.Card, {
                            className:
                              "border-green-500/30 bg-green-500/5 backdrop-blur",
                            children: (0, t.jsx)(n.CardContent, {
                              className: "pt-8",
                              children: (0, t.jsxs)("div", {
                                className: "space-y-4",
                                children: [
                                  (0, t.jsxs)("div", {
                                    children: [
                                      (0, t.jsxs)("h4", {
                                        className:
                                          "text-2xl font-semibold mb-3 text-foreground",
                                        children: [
                                          "Discord",
                                          " ",
                                          (0, t.jsx)(l.Badge, {
                                            variant: "default",
                                            className:
                                              "ml-2 bg-green-500 text-base",
                                            children: "Must Have",
                                          }),
                                        ],
                                      }),
                                      (0, t.jsx)("p", {
                                        className:
                                          "text-muted-foreground text-lg",
                                        children: "For the cheat menu overlay",
                                      }),
                                    ],
                                  }),
                                  (0, t.jsxs)("ul", {
                                    className:
                                      "space-y-2 text-sm text-muted-foreground",
                                    children: [
                                      (0, t.jsxs)("li", {
                                        className: "flex items-start gap-2",
                                        children: [
                                          (0, t.jsx)("span", {
                                            className:
                                              "text-green-500 font-bold mt-0.5",
                                            children: "•",
                                          }),
                                          (0, t.jsx)("span", {
                                            children:
                                              "Run Discord as Administrator",
                                          }),
                                        ],
                                      }),
                                      (0, t.jsxs)("li", {
                                        className: "flex items-start gap-2",
                                        children: [
                                          (0, t.jsx)("span", {
                                            className:
                                              "text-green-500 font-bold mt-0.5",
                                            children: "•",
                                          }),
                                          (0, t.jsx)("span", {
                                            children:
                                              "Make sure Discord overlay is enabled in settings",
                                          }),
                                        ],
                                      }),
                                      (0, t.jsxs)("li", {
                                        className: "flex items-start gap-2",
                                        children: [
                                          (0, t.jsx)("span", {
                                            className:
                                              "text-green-500 font-bold mt-0.5",
                                            children: "•",
                                          }),
                                          (0, t.jsx)("span", {
                                            children:
                                              "The overlay will be used for the cheat menu",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                          }),
                          (0, t.jsx)(n.Card, {
                            className:
                              "border-green-500/30 bg-green-500/5 backdrop-blur",
                            children: (0, t.jsx)(n.CardContent, {
                              className: "pt-8",
                              children: (0, t.jsxs)("div", {
                                className:
                                  "flex items-start justify-between gap-4",
                                children: [
                                  (0, t.jsxs)("div", {
                                    className: "flex-1",
                                    children: [
                                      (0, t.jsx)("h4", {
                                        className:
                                          "text-2xl font-semibold mb-3 text-foreground",
                                        children: "WinRAR",
                                      }),
                                      (0, t.jsx)("p", {
                                        className:
                                          "text-muted-foreground text-lg",
                                        children: "To extract the loader",
                                      }),
                                    ],
                                  }),
                                  (0, t.jsx)(d.Button, {
                                    className:
                                      "bg-green-500 hover:bg-green-600 text-white shrink-0 h-12 px-6 text-base",
                                    asChild: !0,
                                    children: (0, t.jsxs)("a", {
                                      href: "https://www.win-rar.com/download.html",
                                      target: "_blank",
                                      rel: "noopener noreferrer",
                                      children: [
                                        (0, t.jsx)(c.Download, {
                                          className: "h-5 w-5 mr-2",
                                        }),
                                        "Download",
                                      ],
                                    }),
                                  }),
                                ],
                              }),
                            }),
                          }),
                          (0, t.jsx)(n.Card, {
                            className:
                              "border-green-500/30 bg-green-500/5 backdrop-blur",
                            children: (0, t.jsx)(n.CardContent, {
                              className: "pt-8",
                              children: (0, t.jsxs)("div", {
                                className: "space-y-6",
                                children: [
                                  (0, t.jsxs)("div", {
                                    className: "flex items-start gap-4",
                                    children: [
                                      (0, t.jsx)(p.Package, {
                                        className:
                                          "h-8 w-8 text-green-500 mt-1 shrink-0",
                                      }),
                                      (0, t.jsxs)("div", {
                                        className: "flex-1",
                                        children: [
                                          (0, t.jsx)("h4", {
                                            className:
                                              "text-2xl font-semibold mb-3 text-foreground",
                                            children: "Valorant Loader",
                                          }),
                                          (0, t.jsx)("p", {
                                            className:
                                              "text-muted-foreground mb-4 text-lg",
                                            children:
                                              "Download the latest loader:",
                                          }),
                                          (0, t.jsxs)("div", {
                                            className: "space-y-3",
                                            children: [
                                              (0, t.jsxs)("a", {
                                                href: "https://workupload.com/file/NQ6KmCSSbde",
                                                target: "_blank",
                                                rel: "noopener noreferrer",
                                                className:
                                                  "inline-flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition-colors",
                                                children: [
                                                  (0, t.jsx)(c.Download, {
                                                    className: "h-5 w-5",
                                                  }),
                                                  "Download Valorant Loader",
                                                ],
                                              }),
                                              (0, t.jsxs)("div", {
                                                className:
                                                  "flex items-center gap-2",
                                                children: [
                                                  (0, t.jsx)("button", {
                                                    onClick: () => _(!C),
                                                    className:
                                                      "text-sm text-muted-foreground hover:text-foreground underline transition-colors",
                                                    children: C
                                                      ? "Hide password"
                                                      : "Click to see password",
                                                  }),
                                                  C &&
                                                    (0, t.jsx)("span", {
                                                      className:
                                                        "text-sm font-mono bg-muted px-3 py-1 rounded",
                                                      children: "123",
                                                    }),
                                                ],
                                              }),
                                              (0, t.jsxs)("div", {
                                                className:
                                                  "mt-6 p-4 bg-green-500/10 border border-green-500/30 rounded-lg",
                                                children: [
                                                  (0, t.jsx)("h5", {
                                                    className:
                                                      "font-semibold text-foreground mb-3",
                                                    children: "Usage:",
                                                  }),
                                                  (0, t.jsxs)("ol", {
                                                    className:
                                                      "space-y-2 text-sm text-muted-foreground list-decimal list-inside",
                                                    children: [
                                                      (0, t.jsx)("li", {
                                                        children:
                                                          "Run Loader as an administrator",
                                                      }),
                                                      (0, t.jsx)("li", {
                                                        children:
                                                          "Log in with the key you purchased",
                                                      }),
                                                      (0, t.jsx)("li", {
                                                        children:
                                                          "Wait until the bar reaches 100%",
                                                      }),
                                                      (0, t.jsx)("li", {
                                                        children:
                                                          "Press F1 to open the menu (default menu key)",
                                                      }),
                                                    ],
                                                  }),
                                                ],
                                              }),
                                            ],
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, t.jsx)("div", {
                                    className: "h-px bg-border my-6",
                                  }),
                                  (0, t.jsxs)("div", {
                                    children: [
                                      (0, t.jsxs)("div", {
                                        className:
                                          "flex items-center gap-3 mb-4",
                                        children: [
                                          (0, t.jsx)(f, {
                                            className:
                                              "h-7 w-7 text-destructive",
                                          }),
                                          (0, t.jsx)("h3", {
                                            className:
                                              "text-2xl font-bold text-foreground",
                                            children: "Problems?",
                                          }),
                                        ],
                                      }),
                                      (0, t.jsxs)("div", {
                                        className: "space-y-4",
                                        children: [
                                          (0, t.jsxs)(n.Card, {
                                            className:
                                              "border-destructive/30 bg-destructive/5",
                                            children: [
                                              (0, t.jsx)(n.CardHeader, {
                                                children: (0, t.jsxs)(
                                                  n.CardTitle,
                                                  {
                                                    className:
                                                      "text-xl flex items-center gap-2",
                                                    children: [
                                                      (0, t.jsx)(
                                                        g.AlertTriangle,
                                                        {
                                                          className:
                                                            "h-5 w-5 text-destructive",
                                                        }
                                                      ),
                                                      "Loader Won't Work / Crashes",
                                                    ],
                                                  }
                                                ),
                                              }),
                                              (0, t.jsxs)(n.CardContent, {
                                                className: "space-y-4",
                                                children: [
                                                  (0, t.jsxs)("div", {
                                                    children: [
                                                      (0, t.jsx)("h5", {
                                                        className:
                                                          "font-semibold mb-2 text-foreground",
                                                        children:
                                                          "Fix 1: Replace Host File",
                                                      }),
                                                      (0, t.jsx)("div", {
                                                        className:
                                                          "space-y-1 text-muted-foreground text-sm",
                                                        children: (0, t.jsx)(
                                                          "p",
                                                          {
                                                            children:
                                                              'Press Windows + R → Type "drivers" → Go to etc folder → Put in new host file',
                                                          }
                                                        ),
                                                      }),
                                                    ],
                                                  }),
                                                  (0, t.jsxs)("div", {
                                                    children: [
                                                      (0, t.jsx)("h5", {
                                                        className:
                                                          "font-semibold mb-2 text-foreground",
                                                        children:
                                                          "Fix 2: Use Warp VPN",
                                                      }),
                                                      (0, t.jsx)("div", {
                                                        className:
                                                          "space-y-1 text-muted-foreground text-sm",
                                                        children: (0, t.jsxs)(
                                                          "p",
                                                          {
                                                            children: [
                                                              "Get from",
                                                              " ",
                                                              (0, t.jsx)("a", {
                                                                href: "https://one.one.one.one/",
                                                                target:
                                                                  "_blank",
                                                                className:
                                                                  "text-primary hover:underline",
                                                                rel: "noreferrer",
                                                                children:
                                                                  "https://one.one.one.one/",
                                                              }),
                                                              " ",
                                                              "→ Connect → Try loader",
                                                            ],
                                                          }
                                                        ),
                                                      }),
                                                    ],
                                                  }),
                                                ],
                                              }),
                                            ],
                                          }),
                                          (0, t.jsxs)(n.Card, {
                                            className:
                                              "border-destructive/30 bg-destructive/5",
                                            children: [
                                              (0, t.jsx)(n.CardHeader, {
                                                children: (0, t.jsxs)(
                                                  n.CardTitle,
                                                  {
                                                    className:
                                                      "text-xl flex items-center gap-2",
                                                    children: [
                                                      (0, t.jsx)(h.Settings, {
                                                        className:
                                                          "h-5 w-5 text-destructive",
                                                      }),
                                                      "Menu Looks Wrong",
                                                    ],
                                                  }
                                                ),
                                              }),
                                              (0, t.jsx)(n.CardContent, {
                                                children: (0, t.jsx)("p", {
                                                  className:
                                                    "text-muted-foreground text-sm",
                                                  children:
                                                    "Settings → Display → Change scale to 100% → Restart game",
                                                }),
                                              }),
                                            ],
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                          }),
                        ],
                      }),
                    ],
                  }),
              ],
            }),
          }),
          (0, t.jsx)("section", {
            className:
              "sticky bottom-0 bg-background/95 backdrop-blur border-t border-border py-6 px-4",
            children: (0, t.jsx)("div", {
              className: "container mx-auto max-w-5xl",
              children: (0, t.jsxs)("div", {
                className: "flex items-center justify-between gap-4",
                children: [
                  (0, t.jsxs)(d.Button, {
                    variant: "outline",
                    size: "lg",
                    onClick: () => {
                      e > 1 &&
                        (m(e - 1),
                        window.scrollTo({ top: 0, behavior: "smooth" }));
                    },
                    disabled: 1 === e,
                    className: "h-14 px-8 text-base bg-transparent",
                    children: [
                      (0, t.jsx)(y.ChevronLeft, { className: "mr-2 h-5 w-5" }),
                      "Back",
                    ],
                  }),
                  (0, t.jsxs)("div", {
                    className: "text-center",
                    children: [
                      (0, t.jsx)("p", {
                        className: "text-sm text-muted-foreground mb-1",
                        children: "Step Progress",
                      }),
                      (0, t.jsxs)("p", {
                        className: "text-lg font-semibold text-foreground",
                        children: [e, " / ", 4],
                      }),
                    ],
                  }),
                  (0, t.jsx)(d.Button, {
                    size: "lg",
                    onClick: () => {
                      e < 4 &&
                        (m(e + 1),
                        window.scrollTo({ top: 0, behavior: "smooth" }));
                    },
                    disabled: 4 === e,
                    className:
                      "h-14 px-8 text-base bg-primary hover:bg-primary/90",
                    children:
                      4 === e
                        ? (0, t.jsxs)(t.Fragment, {
                            children: [
                              (0, t.jsx)(j.CheckCircle, {
                                className: "mr-2 h-5 w-5",
                              }),
                              "Complete",
                            ],
                          })
                        : (0, t.jsxs)(t.Fragment, {
                            children: [
                              "Continue",
                              (0, t.jsx)(N.ChevronRight, {
                                className: "ml-2 h-5 w-5",
                              }),
                            ],
                          }),
                  }),
                ],
              }),
            }),
          }),
          (0, t.jsx)(a.Footer, {}),
        ],
      });
    }
    e.s(["default", () => C], 33366);
  },
]);
