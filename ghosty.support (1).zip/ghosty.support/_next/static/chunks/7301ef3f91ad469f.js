(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  60835,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "warnOnce", {
        enumerable: !0,
        get: function () {
          return s;
        },
      });
    let s = (e) => {};
  },
  85260,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      assign: function () {
        return o;
      },
      searchParamsToUrlQuery: function () {
        return a;
      },
      urlQueryToSearchParams: function () {
        return i;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    function a(e) {
      let t = {};
      for (let [r, s] of e.entries()) {
        let e = t[r];
        void 0 === e
          ? (t[r] = s)
          : Array.isArray(e)
          ? e.push(s)
          : (t[r] = [e, s]);
      }
      return t;
    }
    function l(e) {
      return "string" == typeof e
        ? e
        : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e
        ? ""
        : String(e);
    }
    function i(e) {
      let t = new URLSearchParams();
      for (let [r, s] of Object.entries(e))
        if (Array.isArray(s)) for (let e of s) t.append(r, l(e));
        else t.set(r, l(s));
      return t;
    }
    function o(e, ...t) {
      for (let r of t) {
        for (let t of r.keys()) e.delete(t);
        for (let [t, s] of r.entries()) e.append(t, s);
      }
      return e;
    }
  },
  91552,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      formatUrl: function () {
        return i;
      },
      formatWithValidation: function () {
        return d;
      },
      urlObjectKeys: function () {
        return o;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    let a = e.r(44066)._(e.r(85260)),
      l = /https?|ftp|gopher|file/;
    function i(e) {
      let { auth: t, hostname: r } = e,
        s = e.protocol || "",
        n = e.pathname || "",
        i = e.hash || "",
        o = e.query || "",
        d = !1;
      (t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : ""),
        e.host
          ? (d = t + e.host)
          : r &&
            ((d = t + (~r.indexOf(":") ? `[${r}]` : r)),
            e.port && (d += ":" + e.port)),
        o && "object" == typeof o && (o = String(a.urlQueryToSearchParams(o)));
      let c = e.search || (o && `?${o}`) || "";
      return (
        s && !s.endsWith(":") && (s += ":"),
        e.slashes || ((!s || l.test(s)) && !1 !== d)
          ? ((d = "//" + (d || "")), n && "/" !== n[0] && (n = "/" + n))
          : d || (d = ""),
        i && "#" !== i[0] && (i = "#" + i),
        c && "?" !== c[0] && (c = "?" + c),
        (n = n.replace(/[?#]/g, encodeURIComponent)),
        (c = c.replace("#", "%23")),
        `${s}${d}${n}${c}${i}`
      );
    }
    let o = [
      "auth",
      "hash",
      "host",
      "hostname",
      "href",
      "path",
      "pathname",
      "port",
      "protocol",
      "query",
      "search",
      "slashes",
    ];
    function d(e) {
      return i(e);
    }
  },
  60203,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let s = e.r(80883);
    function n(e, t) {
      let r = (0, s.useRef)(null),
        n = (0, s.useRef)(null);
      return (0, s.useCallback)(
        (s) => {
          if (null === s) {
            let e = r.current;
            e && ((r.current = null), e());
            let t = n.current;
            t && ((n.current = null), t());
          } else e && (r.current = a(e, s)), t && (n.current = a(t, s));
        },
        [e, t]
      );
    }
    function a(e, t) {
      if ("function" != typeof e)
        return (
          (e.current = t),
          () => {
            e.current = null;
          }
        );
      {
        let r = e(t);
        return "function" == typeof r ? r : () => e(null);
      }
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  6898,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      DecodeError: function () {
        return g;
      },
      MiddlewareNotFoundError: function () {
        return N;
      },
      MissingStaticPage: function () {
        return y;
      },
      NormalizeError: function () {
        return j;
      },
      PageNotFoundError: function () {
        return b;
      },
      SP: function () {
        return x;
      },
      ST: function () {
        return p;
      },
      WEB_VITALS: function () {
        return a;
      },
      execOnce: function () {
        return l;
      },
      getDisplayName: function () {
        return u;
      },
      getLocationOrigin: function () {
        return d;
      },
      getURL: function () {
        return c;
      },
      isAbsoluteUrl: function () {
        return o;
      },
      isResSent: function () {
        return m;
      },
      loadGetInitialProps: function () {
        return f;
      },
      normalizeRepeatedSlashes: function () {
        return h;
      },
      stringifyError: function () {
        return v;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    let a = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];
    function l(e) {
      let t,
        r = !1;
      return (...s) => (r || ((r = !0), (t = e(...s))), t);
    }
    let i = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
      o = (e) => i.test(e);
    function d() {
      let { protocol: e, hostname: t, port: r } = window.location;
      return `${e}//${t}${r ? ":" + r : ""}`;
    }
    function c() {
      let { href: e } = window.location,
        t = d();
      return e.substring(t.length);
    }
    function u(e) {
      return "string" == typeof e ? e : e.displayName || e.name || "Unknown";
    }
    function m(e) {
      return e.finished || e.headersSent;
    }
    function h(e) {
      let t = e.split("?");
      return (
        t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") +
        (t[1] ? `?${t.slice(1).join("?")}` : "")
      );
    }
    async function f(e, t) {
      let r = t.res || (t.ctx && t.ctx.res);
      if (!e.getInitialProps)
        return t.ctx && t.Component
          ? { pageProps: await f(t.Component, t.ctx) }
          : {};
      let s = await e.getInitialProps(t);
      if (r && m(r)) return s;
      if (!s)
        throw Object.defineProperty(
          Error(
            `"${u(
              e
            )}.getInitialProps()" should resolve to an object. But found "${s}" instead.`
          ),
          "__NEXT_ERROR_CODE",
          { value: "E394", enumerable: !1, configurable: !0 }
        );
      return s;
    }
    let x = "undefined" != typeof performance,
      p =
        x &&
        ["mark", "measure", "getEntriesByName"].every(
          (e) => "function" == typeof performance[e]
        );
    class g extends Error {}
    class j extends Error {}
    class b extends Error {
      constructor(e) {
        super(),
          (this.code = "ENOENT"),
          (this.name = "PageNotFoundError"),
          (this.message = `Cannot find module for page: ${e}`);
      }
    }
    class y extends Error {
      constructor(e, t) {
        super(),
          (this.message = `Failed to load static file for page: ${e} ${t}`);
      }
    }
    class N extends Error {
      constructor() {
        super(),
          (this.code = "ENOENT"),
          (this.message = "Cannot find the middleware module");
      }
    }
    function v(e) {
      return JSON.stringify({ message: e.message, stack: e.stack });
    }
  },
  73350,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    let s = e.r(6898),
      n = e.r(56075);
    function a(e) {
      if (!(0, s.isAbsoluteUrl)(e)) return !0;
      try {
        let t = (0, s.getLocationOrigin)(),
          r = new URL(e, t);
        return r.origin === t && (0, n.hasBasePath)(r.pathname);
      } catch (e) {
        return !1;
      }
    }
  },
  95136,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "errorOnce", {
        enumerable: !0,
        get: function () {
          return s;
        },
      });
    let s = (e) => {};
  },
  61021,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      default: function () {
        return g;
      },
      useLinkStatus: function () {
        return b;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    let a = e.r(44066),
      l = e.r(93046),
      i = a._(e.r(80883)),
      o = e.r(91552),
      d = e.r(89260),
      c = e.r(60203),
      u = e.r(6898),
      m = e.r(63118);
    e.r(60835);
    let h = e.r(68193),
      f = e.r(73350),
      x = e.r(50696);
    function p(e) {
      return "string" == typeof e ? e : (0, o.formatUrl)(e);
    }
    function g(t) {
      var r;
      let s,
        n,
        a,
        [o, g] = (0, i.useOptimistic)(h.IDLE_LINK_STATUS),
        b = (0, i.useRef)(null),
        {
          href: y,
          as: N,
          children: v,
          prefetch: w = null,
          passHref: C,
          replace: k,
          shallow: T,
          scroll: P,
          onClick: _,
          onMouseEnter: A,
          onTouchStart: R,
          legacyBehavior: S = !1,
          onNavigate: O,
          ref: D,
          unstable_dynamicOnHover: E,
          ...M
        } = t;
      (s = v),
        S &&
          ("string" == typeof s || "number" == typeof s) &&
          (s = (0, l.jsx)("a", { children: s }));
      let L = i.default.useContext(d.AppRouterContext),
        I = !1 !== w,
        U =
          !1 !== w
            ? null === (r = w) || "auto" === r
              ? x.FetchStrategy.PPR
              : x.FetchStrategy.Full
            : x.FetchStrategy.PPR,
        { href: F, as: B } = i.default.useMemo(() => {
          let e = p(y);
          return { href: e, as: N ? p(N) : e };
        }, [y, N]);
      if (S) {
        if (s?.$$typeof === Symbol.for("react.lazy"))
          throw Object.defineProperty(
            Error(
              "`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."
            ),
            "__NEXT_ERROR_CODE",
            { value: "E863", enumerable: !1, configurable: !0 }
          );
        n = i.default.Children.only(s);
      }
      let $ = S ? n && "object" == typeof n && n.ref : D,
        W = i.default.useCallback(
          (e) => (
            null !== L &&
              (b.current = (0, h.mountLinkInstance)(e, F, L, U, I, g)),
            () => {
              b.current &&
                ((0, h.unmountLinkForCurrentNavigation)(b.current),
                (b.current = null)),
                (0, h.unmountPrefetchableInstance)(e);
            }
          ),
          [I, F, L, U, g]
        ),
        z = {
          ref: (0, c.useMergedRef)(W, $),
          onClick(t) {
            S || "function" != typeof _ || _(t),
              S &&
                n.props &&
                "function" == typeof n.props.onClick &&
                n.props.onClick(t),
              !L ||
                t.defaultPrevented ||
                (function (t, r, s, n, a, l, o) {
                  if ("undefined" != typeof window) {
                    let d,
                      { nodeName: c } = t.currentTarget;
                    if (
                      ("A" === c.toUpperCase() &&
                        (((d = t.currentTarget.getAttribute("target")) &&
                          "_self" !== d) ||
                          t.metaKey ||
                          t.ctrlKey ||
                          t.shiftKey ||
                          t.altKey ||
                          (t.nativeEvent && 2 === t.nativeEvent.which))) ||
                      t.currentTarget.hasAttribute("download")
                    )
                      return;
                    if (!(0, f.isLocalURL)(r)) {
                      a && (t.preventDefault(), location.replace(r));
                      return;
                    }
                    if ((t.preventDefault(), o)) {
                      let e = !1;
                      if (
                        (o({
                          preventDefault: () => {
                            e = !0;
                          },
                        }),
                        e)
                      )
                        return;
                    }
                    let { dispatchNavigateAction: u } = e.r(56797);
                    i.default.startTransition(() => {
                      u(s || r, a ? "replace" : "push", l ?? !0, n.current);
                    });
                  }
                })(t, F, B, b, k, P, O);
          },
          onMouseEnter(e) {
            S || "function" != typeof A || A(e),
              S &&
                n.props &&
                "function" == typeof n.props.onMouseEnter &&
                n.props.onMouseEnter(e),
              L && I && (0, h.onNavigationIntent)(e.currentTarget, !0 === E);
          },
          onTouchStart: function (e) {
            S || "function" != typeof R || R(e),
              S &&
                n.props &&
                "function" == typeof n.props.onTouchStart &&
                n.props.onTouchStart(e),
              L && I && (0, h.onNavigationIntent)(e.currentTarget, !0 === E);
          },
        };
      return (
        (0, u.isAbsoluteUrl)(B)
          ? (z.href = B)
          : (S && !C && ("a" !== n.type || "href" in n.props)) ||
            (z.href = (0, m.addBasePath)(B)),
        (a = S
          ? i.default.cloneElement(n, z)
          : (0, l.jsx)("a", { ...M, ...z, children: s })),
        (0, l.jsx)(j.Provider, { value: o, children: a })
      );
    }
    e.r(95136);
    let j = (0, i.createContext)(h.IDLE_LINK_STATUS),
      b = () => (0, i.useContext)(j);
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  84675,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("ArrowLeft", [
      ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
      ["path", { d: "M19 12H5", key: "x3x0zl" }],
    ]);
    e.s(["ArrowLeft", () => t], 84675);
  },
  13637,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Download", [
      [
        "path",
        { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
      ],
      ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
      ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }],
    ]);
    e.s(["Download", () => t], 13637);
  },
  81947,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(94237),
      s = e.i(47163);
    let n = (0, r.cva)(
      "relative w-full rounded-lg border px-4 py-3 text-sm grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current",
      {
        variants: {
          variant: {
            default: "bg-card text-card-foreground",
            destructive:
              "text-destructive bg-card [&>svg]:text-current *:data-[slot=alert-description]:text-destructive/90",
          },
        },
        defaultVariants: { variant: "default" },
      }
    );
    function a({ className: e, variant: r, ...a }) {
      return (0, t.jsx)("div", {
        "data-slot": "alert",
        role: "alert",
        className: (0, s.cn)(n({ variant: r }), e),
        ...a,
      });
    }
    function l({ className: e, ...r }) {
      return (0, t.jsx)("div", {
        "data-slot": "alert-description",
        className: (0, s.cn)(
          "text-muted-foreground col-start-2 grid justify-items-start gap-1 text-sm [&_p]:leading-relaxed",
          e
        ),
        ...r,
      });
    }
    e.s(["Alert", () => a, "AlertDescription", () => l]);
  },
  64877,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("TriangleAlert", [
      [
        "path",
        {
          d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
          key: "wmoenq",
        },
      ],
      ["path", { d: "M12 9v4", key: "juzpu7" }],
      ["path", { d: "M12 17h.01", key: "p32p05" }],
    ]);
    e.s(["AlertTriangle", () => t], 64877);
  },
  70065,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(47163);
    function s({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card",
        className: (0, r.cn)(
          "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",
          e
        ),
        ...s,
      });
    }
    function n({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-header",
        className: (0, r.cn)(
          "@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6",
          e
        ),
        ...s,
      });
    }
    function a({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-title",
        className: (0, r.cn)("leading-none font-semibold", e),
        ...s,
      });
    }
    function l({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-description",
        className: (0, r.cn)("text-muted-foreground text-sm", e),
        ...s,
      });
    }
    function i({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-content",
        className: (0, r.cn)("px-6", e),
        ...s,
      });
    }
    e.s([
      "Card",
      () => s,
      "CardContent",
      () => i,
      "CardDescription",
      () => l,
      "CardHeader",
      () => n,
      "CardTitle",
      () => a,
    ]);
  },
  35301,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("CircleCheck", [
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
      ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }],
    ]);
    e.s(["CheckCircle2", () => t], 35301);
  },
  95751,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("ArrowRight", [
      ["path", { d: "M5 12h14", key: "1ays0h" }],
      ["path", { d: "m12 5 7 7-7 7", key: "xquz4c" }],
    ]);
    e.s(["ArrowRight", () => t], 95751);
  },
  89919,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(80883),
      s = e.i(61021),
      n = e.i(84675),
      a = e.i(95751),
      l = e.i(35301),
      i = e.i(13637),
      o = e.i(64877),
      d = e.i(67881),
      c = e.i(70065),
      u = e.i(81947);
    function m() {
      let [e, m] = (0, r.useState)(0);
      return (0, t.jsx)("div", {
        className: "min-h-screen bg-background",
        children: (0, t.jsxs)("div", {
          className: "container mx-auto px-4 py-8",
          children: [
            (0, t.jsxs)(s.default, {
              href: "/#products",
              className:
                "inline-flex items-center text-primary hover:underline mb-6",
              children: [
                (0, t.jsx)(n.ArrowLeft, { className: "mr-2 h-4 w-4" }),
                "Back to Products",
              ],
            }),
            (0, t.jsxs)("div", {
              className: "max-w-4xl mx-auto",
              children: [
                (0, t.jsxs)("div", {
                  className: "mb-8",
                  children: [
                    (0, t.jsx)("h1", {
                      className: "text-4xl font-bold mb-2",
                      children: "War Thunder Setup Guide",
                    }),
                    (0, t.jsx)("p", {
                      className: "text-muted-foreground",
                      children:
                        "Follow these steps to install and configure War Thunder cheat",
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  className: "mb-8",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center justify-between mb-2",
                      children: [
                        (0, t.jsx)("span", {
                          className: "text-sm font-medium",
                          children: "Progress",
                        }),
                        (0, t.jsxs)("span", {
                          className: "text-sm text-muted-foreground",
                          children: ["Step ", e + 1, " of ", 6],
                        }),
                      ],
                    }),
                    (0, t.jsx)("div", {
                      className:
                        "h-2 bg-secondary rounded-full overflow-hidden",
                      children: (0, t.jsx)("div", {
                        className:
                          "h-full bg-primary transition-all duration-300",
                        style: { width: `${((e + 1) / 6) * 100}%` },
                      }),
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  className: "mb-8 animate-in fade-in duration-300",
                  children: [
                    0 === e &&
                      (0, t.jsxs)(c.Card, {
                        children: [
                          (0, t.jsxs)(c.CardHeader, {
                            children: [
                              (0, t.jsxs)(c.CardTitle, {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, t.jsx)("span", {
                                    className:
                                      "flex items-center justify-center w-10 h-10 rounded-full bg-red-500/10 text-red-500 text-xl font-bold",
                                    children: "!",
                                  }),
                                  "Important Information - Read Before Starting",
                                ],
                              }),
                              (0, t.jsx)(c.CardDescription, {
                                children:
                                  "Critical information about using War Thunder cheat",
                              }),
                            ],
                          }),
                          (0, t.jsxs)(c.CardContent, {
                            className: "space-y-4",
                            children: [
                              (0, t.jsxs)(u.Alert, {
                                className: "border-red-500/50 bg-red-500/10",
                                children: [
                                  (0, t.jsx)(o.AlertTriangle, {
                                    className: "h-4 w-4 text-red-500",
                                  }),
                                  (0, t.jsx)(u.AlertDescription, {
                                    className: "text-red-500 font-medium",
                                    children:
                                      "Before activating the key, install Visual C++ Redistributable",
                                  }),
                                ],
                              }),
                              (0, t.jsx)("div", {
                                className: "text-center py-4",
                                children: (0, t.jsx)("a", {
                                  href: "https://aka.ms/vs/17/release/vc_redist.x64.exe",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  className: "inline-block",
                                  children: (0, t.jsxs)(d.Button, {
                                    size: "lg",
                                    className: "gap-2",
                                    children: [
                                      (0, t.jsx)(i.Download, {
                                        className: "h-4 w-4",
                                      }),
                                      "Download Visual C++ Redistributable",
                                    ],
                                  }),
                                }),
                              }),
                              (0, t.jsxs)("div", {
                                className:
                                  "bg-secondary/50 p-4 rounded-lg space-y-2",
                                children: [
                                  (0, t.jsx)("h3", {
                                    className: "font-semibold text-yellow-500",
                                    children: "Important Reminders:",
                                  }),
                                  (0, t.jsxs)("ul", {
                                    className:
                                      "space-y-1 text-sm text-muted-foreground",
                                    children: [
                                      (0, t.jsx)("li", {
                                        children:
                                          "• Restart your computer before launching the software (mandatory)",
                                      }),
                                      (0, t.jsx)("li", {
                                        children:
                                          "• Using software is always a risk - use at your own discretion",
                                      }),
                                      (0, t.jsx)("li", {
                                        children:
                                          "• Undetected status does not guarantee 100% protection against blocking",
                                      }),
                                      (0, t.jsx)("li", {
                                        children:
                                          "• If there's a game update, wait for the software update",
                                      }),
                                      (0, t.jsx)("li", {
                                        children:
                                          "• DO NOT use on your main account",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                    1 === e &&
                      (0, t.jsxs)(c.Card, {
                        children: [
                          (0, t.jsxs)(c.CardHeader, {
                            children: [
                              (0, t.jsxs)(c.CardTitle, {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, t.jsx)("span", {
                                    className:
                                      "flex items-center justify-center w-10 h-10 rounded-full bg-red-500/10 text-red-500 text-xl font-bold",
                                    children: "1",
                                  }),
                                  "Remove/Disable Security Software",
                                ],
                              }),
                              (0, t.jsx)(c.CardDescription, {
                                children: "Critical step - Must be completed",
                              }),
                            ],
                          }),
                          (0, t.jsxs)(c.CardContent, {
                            className: "space-y-4",
                            children: [
                              (0, t.jsxs)(u.Alert, {
                                className:
                                  "border-yellow-500/50 bg-yellow-500/10",
                                children: [
                                  (0, t.jsx)(o.AlertTriangle, {
                                    className: "h-4 w-4 text-yellow-500",
                                  }),
                                  (0, t.jsx)(u.AlertDescription, {
                                    className: "text-yellow-500 font-medium",
                                    children:
                                      "All security software must be disabled or removed",
                                  }),
                                ],
                              }),
                              (0, t.jsxs)("div", {
                                className: "space-y-3",
                                children: [
                                  (0, t.jsxs)("div", {
                                    className:
                                      "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-lg",
                                        children: "🛡️",
                                      }),
                                      (0, t.jsxs)("div", {
                                        children: [
                                          (0, t.jsx)("p", {
                                            className: "font-medium",
                                            children: "Remove Antivirus",
                                          }),
                                          (0, t.jsx)("p", {
                                            className:
                                              "text-sm text-muted-foreground",
                                            children:
                                              "Uninstall all third-party antivirus software",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, t.jsxs)("div", {
                                    className:
                                      "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-lg",
                                        children: "⚠️",
                                      }),
                                      (0, t.jsxs)("div", {
                                        children: [
                                          (0, t.jsx)("p", {
                                            className: "font-medium",
                                            children: "Disable SmartScreen",
                                          }),
                                          (0, t.jsx)("p", {
                                            className:
                                              "text-sm text-muted-foreground",
                                            children:
                                              "Turn off Windows SmartScreen protection",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, t.jsxs)("div", {
                                    className:
                                      "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-lg",
                                        children: "🔒",
                                      }),
                                      (0, t.jsxs)("div", {
                                        children: [
                                          (0, t.jsx)("p", {
                                            className: "font-medium",
                                            children:
                                              "Disable Windows Defender",
                                          }),
                                          (0, t.jsx)("p", {
                                            className:
                                              "text-sm text-muted-foreground",
                                            children:
                                              "Turn off real-time protection",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, t.jsxs)("div", {
                                    className:
                                      "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-lg",
                                        children: "🗑️",
                                      }),
                                      (0, t.jsxs)("div", {
                                        children: [
                                          (0, t.jsx)("p", {
                                            className: "font-medium",
                                            children:
                                              "Delete FaceIt and Vanguard",
                                          }),
                                          (0, t.jsx)("p", {
                                            className:
                                              "text-sm text-muted-foreground",
                                            children:
                                              "FaceIt (CS:GO anti-cheat) and Vanguard (Valorant anti-cheat) must be removed",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                    2 === e &&
                      (0, t.jsxs)(c.Card, {
                        children: [
                          (0, t.jsxs)(c.CardHeader, {
                            children: [
                              (0, t.jsxs)(c.CardTitle, {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, t.jsx)("span", {
                                    className:
                                      "flex items-center justify-center w-10 h-10 rounded-full bg-blue-500/10 text-blue-500 text-xl font-bold",
                                    children: "2",
                                  }),
                                  "Download War Thunder Loader",
                                ],
                              }),
                              (0, t.jsx)(c.CardDescription, {
                                children:
                                  "Get the latest loader and prepare installation",
                              }),
                            ],
                          }),
                          (0, t.jsxs)(c.CardContent, {
                            className: "space-y-4",
                            children: [
                              (0, t.jsx)("div", {
                                className: "text-center py-6",
                                children: (0, t.jsx)("a", {
                                  href: "https://storage.e-arcane.com/LoaderArcane.zip",
                                  target: "_blank",
                                  rel: "noopener noreferrer",
                                  className: "inline-block",
                                  children: (0, t.jsxs)(d.Button, {
                                    size: "lg",
                                    className:
                                      "gap-2 bg-green-600 hover:bg-green-700",
                                    children: [
                                      (0, t.jsx)(i.Download, {
                                        className: "h-5 w-5",
                                      }),
                                      "Download War Thunder Loader",
                                    ],
                                  }),
                                }),
                              }),
                              (0, t.jsxs)("div", {
                                className:
                                  "bg-secondary/50 p-4 rounded-lg space-y-2",
                                children: [
                                  (0, t.jsx)("h3", {
                                    className: "font-semibold",
                                    children: "After Downloading:",
                                  }),
                                  (0, t.jsxs)("ul", {
                                    className:
                                      "space-y-1 text-sm text-muted-foreground",
                                    children: [
                                      (0, t.jsx)("li", {
                                        children:
                                          "• Place the loader in a separate folder",
                                      }),
                                      (0, t.jsx)("li", {
                                        children:
                                          "• Extract the ZIP file if needed",
                                      }),
                                      (0, t.jsx)("li", {
                                        children:
                                          "• Make sure the folder location is easy to access",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                    3 === e &&
                      (0, t.jsxs)(c.Card, {
                        children: [
                          (0, t.jsxs)(c.CardHeader, {
                            children: [
                              (0, t.jsxs)(c.CardTitle, {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, t.jsx)("span", {
                                    className:
                                      "flex items-center justify-center w-10 h-10 rounded-full bg-purple-500/10 text-purple-500 text-xl font-bold",
                                    children: "3",
                                  }),
                                  "Initial Setup",
                                ],
                              }),
                              (0, t.jsx)(c.CardDescription, {
                                children: "First time installation process",
                              }),
                            ],
                          }),
                          (0, t.jsxs)(c.CardContent, {
                            className: "space-y-4",
                            children: [
                              (0, t.jsxs)("div", {
                                className: "space-y-3",
                                children: [
                                  (0, t.jsxs)("div", {
                                    className:
                                      "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-lg",
                                        children: "1️⃣",
                                      }),
                                      (0, t.jsxs)("div", {
                                        children: [
                                          (0, t.jsx)("p", {
                                            className: "font-medium",
                                            children: "Run as Administrator",
                                          }),
                                          (0, t.jsx)("p", {
                                            className:
                                              "text-sm text-muted-foreground",
                                            children:
                                              'Right-click the loader file and select "Run as administrator"',
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, t.jsxs)("div", {
                                    className:
                                      "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-lg",
                                        children: "2️⃣",
                                      }),
                                      (0, t.jsxs)("div", {
                                        children: [
                                          (0, t.jsx)("p", {
                                            className: "font-medium",
                                            children: "Wait for Update",
                                          }),
                                          (0, t.jsx)("p", {
                                            className:
                                              "text-sm text-muted-foreground",
                                            children:
                                              "After the loader updates, run the new file again as administrator",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, t.jsxs)("div", {
                                    className:
                                      "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-lg",
                                        children: "3️⃣",
                                      }),
                                      (0, t.jsxs)("div", {
                                        children: [
                                          (0, t.jsx)("p", {
                                            className: "font-medium",
                                            children: "Enter Your Key",
                                          }),
                                          (0, t.jsx)("p", {
                                            className:
                                              "text-sm text-muted-foreground",
                                            children:
                                              "Use RIGHT mouse button to paste your key in CMD, then press Enter",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, t.jsxs)("div", {
                                    className:
                                      "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className: "text-lg",
                                        children: "4️⃣",
                                      }),
                                      (0, t.jsxs)("div", {
                                        children: [
                                          (0, t.jsx)("p", {
                                            className: "font-medium",
                                            children: "Restart PC",
                                          }),
                                          (0, t.jsx)("p", {
                                            className:
                                              "text-sm text-muted-foreground",
                                            children:
                                              "The loader will ask you to restart - this is normal and required",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, t.jsx)(u.Alert, {
                                className: "border-blue-500/50 bg-blue-500/10",
                                children: (0, t.jsx)(u.AlertDescription, {
                                  className: "text-blue-400",
                                  children:
                                    "The loader may request up to 3 restarts during initial setup - this is completely normal",
                                }),
                              }),
                            ],
                          }),
                        ],
                      }),
                    4 === e &&
                      (0, t.jsxs)(c.Card, {
                        children: [
                          (0, t.jsxs)(c.CardHeader, {
                            children: [
                              (0, t.jsxs)(c.CardTitle, {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, t.jsx)("span", {
                                    className:
                                      "flex items-center justify-center w-10 h-10 rounded-full bg-green-500/10 text-green-500 text-xl font-bold",
                                    children: "4",
                                  }),
                                  "Launch Game & Use Menu",
                                ],
                              }),
                              (0, t.jsx)(c.CardDescription, {
                                children:
                                  "Final steps to start using War Thunder cheat",
                              }),
                            ],
                          }),
                          (0, t.jsx)(c.CardContent, {
                            className: "space-y-4",
                            children: (0, t.jsxs)("div", {
                              className: "space-y-3",
                              children: [
                                (0, t.jsxs)("div", {
                                  className:
                                    "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className: "text-lg",
                                      children: "✅",
                                    }),
                                    (0, t.jsxs)("div", {
                                      children: [
                                        (0, t.jsx)("p", {
                                          className: "font-medium",
                                          children: "After Final Restart",
                                        }),
                                        (0, t.jsx)("p", {
                                          className:
                                            "text-sm text-muted-foreground",
                                          children:
                                            "Reopen the loader and wait for it to finish loading completely",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                (0, t.jsxs)("div", {
                                  className:
                                    "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className: "text-lg",
                                      children: "🎮",
                                    }),
                                    (0, t.jsxs)("div", {
                                      children: [
                                        (0, t.jsx)("p", {
                                          className: "font-medium",
                                          children: "Loader Will Auto-Close",
                                        }),
                                        (0, t.jsx)("p", {
                                          className:
                                            "text-sm text-muted-foreground",
                                          children:
                                            "When successful, the loader closes automatically",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                (0, t.jsxs)("div", {
                                  className:
                                    "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className: "text-lg",
                                      children: "🚀",
                                    }),
                                    (0, t.jsxs)("div", {
                                      children: [
                                        (0, t.jsx)("p", {
                                          className: "font-medium",
                                          children: "Launch Your Game",
                                        }),
                                        (0, t.jsx)("p", {
                                          className:
                                            "text-sm text-muted-foreground",
                                          children:
                                            "The menu will appear automatically when you're in-game",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                (0, t.jsxs)("div", {
                                  className:
                                    "flex items-start gap-3 p-3 bg-secondary/50 rounded-lg",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className: "text-lg",
                                      children: "⌨️",
                                    }),
                                    (0, t.jsxs)("div", {
                                      children: [
                                        (0, t.jsx)("p", {
                                          className: "font-medium",
                                          children: "Menu Controls",
                                        }),
                                        (0, t.jsxs)("p", {
                                          className:
                                            "text-sm text-muted-foreground",
                                          children: [
                                            "Press ",
                                            (0, t.jsx)("strong", {
                                              children: "Home",
                                            }),
                                            " or ",
                                            (0, t.jsx)("strong", {
                                              children: "Insert",
                                            }),
                                            " key to open/close the menu",
                                          ],
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          }),
                        ],
                      }),
                    5 === e &&
                      (0, t.jsxs)(c.Card, {
                        children: [
                          (0, t.jsxs)(c.CardHeader, {
                            children: [
                              (0, t.jsxs)(c.CardTitle, {
                                className: "flex items-center gap-2",
                                children: [
                                  (0, t.jsx)("span", {
                                    className:
                                      "flex items-center justify-center w-10 h-10 rounded-full bg-red-500/10 text-red-500 text-xl font-bold",
                                    children: "⚠️",
                                  }),
                                  "Troubleshooting Common Errors",
                                ],
                              }),
                              (0, t.jsx)(c.CardDescription, {
                                children: "Solutions for common issues",
                              }),
                            ],
                          }),
                          (0, t.jsx)(c.CardContent, {
                            className: "space-y-4",
                            children: (0, t.jsxs)("div", {
                              className: "space-y-4",
                              children: [
                                (0, t.jsxs)("div", {
                                  className:
                                    "border-l-4 border-red-500 pl-4 py-2",
                                  children: [
                                    (0, t.jsx)("h3", {
                                      className: "font-semibold mb-2",
                                      children: "Loader closes with no error",
                                    }),
                                    (0, t.jsx)("p", {
                                      className:
                                        "text-sm text-muted-foreground mb-2",
                                      children:
                                        "Install Visual C++ Redistributable:",
                                    }),
                                    (0, t.jsx)("a", {
                                      href: "https://aka.ms/vs/17/release/vc_redist.x64.exe",
                                      target: "_blank",
                                      rel: "noopener noreferrer",
                                      children: (0, t.jsxs)(d.Button, {
                                        size: "sm",
                                        variant: "outline",
                                        className: "gap-2 bg-transparent",
                                        children: [
                                          (0, t.jsx)(i.Download, {
                                            className: "h-3 w-3",
                                          }),
                                          "Download VC++ Redistributable",
                                        ],
                                      }),
                                    }),
                                  ],
                                }),
                                (0, t.jsxs)("div", {
                                  className:
                                    "border-l-4 border-yellow-500 pl-4 py-2",
                                  children: [
                                    (0, t.jsx)("h3", {
                                      className: "font-semibold mb-2",
                                      children: "Menu not clickable in game",
                                    }),
                                    (0, t.jsx)("ul", {
                                      className:
                                        "text-sm text-muted-foreground space-y-1",
                                      children: (0, t.jsx)("li", {
                                        children:
                                          "• Run the loader as administrator",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, t.jsxs)("div", {
                                  className:
                                    "border-l-4 border-orange-500 pl-4 py-2",
                                  children: [
                                    (0, t.jsx)("h3", {
                                      className: "font-semibold mb-2",
                                      children:
                                        'Windows 10: "Make sure all antiviruses are disabled"',
                                    }),
                                    (0, t.jsxs)("ul", {
                                      className:
                                        "text-sm text-muted-foreground space-y-1",
                                      children: [
                                        (0, t.jsx)("li", {
                                          children:
                                            "• Uninstall all third-party antiviruses",
                                        }),
                                        (0, t.jsx)("li", {
                                          children:
                                            "• Disable real-time protection",
                                        }),
                                        (0, t.jsx)("li", {
                                          children: "• Disable SmartScreen",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                (0, t.jsxs)("div", {
                                  className:
                                    "border-l-4 border-purple-500 pl-4 py-2",
                                  children: [
                                    (0, t.jsx)("h3", {
                                      className: "font-semibold mb-2",
                                      children:
                                        'Windows 11: "Make sure all antiviruses are disabled"',
                                    }),
                                    (0, t.jsx)("p", {
                                      className:
                                        "text-sm text-muted-foreground mb-2",
                                      children:
                                        "Download and run these registry files:",
                                    }),
                                    (0, t.jsx)("a", {
                                      href: "https://disk.yandex.ru/d/5slbv4S2AL1M0w",
                                      target: "_blank",
                                      rel: "noopener noreferrer",
                                      children: (0, t.jsxs)(d.Button, {
                                        size: "sm",
                                        variant: "outline",
                                        className: "gap-2 mb-2 bg-transparent",
                                        children: [
                                          (0, t.jsx)(i.Download, {
                                            className: "h-3 w-3",
                                          }),
                                          "Download Windows 11 Fix Files",
                                        ],
                                      }),
                                    }),
                                    (0, t.jsxs)("ul", {
                                      className:
                                        "text-sm text-muted-foreground space-y-1",
                                      children: [
                                        (0, t.jsx)("li", {
                                          children:
                                            "1. Run Turn_ON, agree to changes, restart PC",
                                        }),
                                        (0, t.jsx)("li", {
                                          children:
                                            "2. Run Turn_OFF, agree to changes, restart PC",
                                        }),
                                        (0, t.jsx)("li", {
                                          children:
                                            "3. If still not working, double-check antivirus is removed",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                (0, t.jsxs)("div", {
                                  className:
                                    "border-l-4 border-blue-500 pl-4 py-2",
                                  children: [
                                    (0, t.jsx)("h3", {
                                      className: "font-semibold mb-2",
                                      children:
                                        "Menu is visible but not clickable",
                                    }),
                                    (0, t.jsxs)("ul", {
                                      className:
                                        "text-sm text-muted-foreground space-y-1",
                                      children: [
                                        (0, t.jsx)("li", {
                                          children:
                                            "• Run Steam WITHOUT administrator rights",
                                        }),
                                        (0, t.jsx)("li", {
                                          children:
                                            "• Disable all third-party overlays (keep only Nvidia/AMD)",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                (0, t.jsxs)("div", {
                                  className:
                                    "border-l-4 border-green-500 pl-4 py-2",
                                  children: [
                                    (0, t.jsx)("h3", {
                                      className: "font-semibold mb-2",
                                      children:
                                        "Menu disappears or visuals don't work",
                                    }),
                                    (0, t.jsxs)("ul", {
                                      className:
                                        "text-sm text-muted-foreground space-y-1",
                                      children: [
                                        (0, t.jsx)("li", {
                                          children:
                                            "• If game was patched, wait for software update",
                                        }),
                                        (0, t.jsx)("li", {
                                          children:
                                            "• Verify game file integrity or reinstall the game",
                                        }),
                                        (0, t.jsx)("li", {
                                          children:
                                            "• If nothing works, contact support chat",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          }),
                        ],
                      }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  className:
                    "sticky bottom-4 flex justify-between gap-4 bg-background/80 backdrop-blur-sm p-4 rounded-lg border",
                  children: [
                    (0, t.jsxs)(d.Button, {
                      onClick: () => {
                        e > 0 && m(e - 1);
                      },
                      disabled: 0 === e,
                      variant: "outline",
                      children: [
                        (0, t.jsx)(n.ArrowLeft, { className: "mr-2 h-4 w-4" }),
                        "Previous",
                      ],
                    }),
                    5 === e
                      ? (0, t.jsx)(s.default, {
                          href: "/#products",
                          children: (0, t.jsxs)(d.Button, {
                            className: "gap-2",
                            children: [
                              (0, t.jsx)(l.CheckCircle2, {
                                className: "h-4 w-4",
                              }),
                              "Complete",
                            ],
                          }),
                        })
                      : (0, t.jsxs)(d.Button, {
                          onClick: () => {
                            e < 5 && m(e + 1);
                          },
                          children: [
                            "Next",
                            (0, t.jsx)(a.ArrowRight, {
                              className: "ml-2 h-4 w-4",
                            }),
                          ],
                        }),
                  ],
                }),
              ],
            }),
          ],
        }),
      });
    }
    e.s(["default", () => m]);
  },
]);
