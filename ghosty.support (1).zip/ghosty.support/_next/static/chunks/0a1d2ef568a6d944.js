(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  67881,
  21991,
  87576,
  94237,
  47163,
  (e) => {
    "use strict";
    var r = e.i(93046),
      t = e.i(80883);
    function o(e, r) {
      if ("function" == typeof e) return e(r);
      null != e && (e.current = r);
    }
    function n(...e) {
      return (r) => {
        let t = !1,
          n = e.map((e) => {
            let n = o(e, r);
            return t || "function" != typeof n || (t = !0), n;
          });
        if (t)
          return () => {
            for (let r = 0; r < n.length; r++) {
              let t = n[r];
              "function" == typeof t ? t() : o(e[r], null);
            }
          };
      };
    }
    function l(...e) {
      return t.useCallback(n(...e), e);
    }
    e.s(["composeRefs", () => n, "useComposedRefs", () => l], 21991);
    var s = t.forwardRef((e, o) => {
      let { children: n, ...l } = e,
        s = t.Children.toArray(n),
        a = s.find(d);
      if (a) {
        let e = a.props.children,
          n = s.map((r) =>
            r !== a
              ? r
              : t.Children.count(e) > 1
              ? t.Children.only(null)
              : t.isValidElement(e)
              ? e.props.children
              : null
          );
        return (0, r.jsx)(i, {
          ...l,
          ref: o,
          children: t.isValidElement(e) ? t.cloneElement(e, void 0, n) : null,
        });
      }
      return (0, r.jsx)(i, { ...l, ref: o, children: n });
    });
    s.displayName = "Slot";
    var i = t.forwardRef((e, r) => {
      let { children: o, ...l } = e;
      if (t.isValidElement(o)) {
        var s;
        let e,
          i,
          a =
            ((s = o),
            (i =
              (e = Object.getOwnPropertyDescriptor(s.props, "ref")?.get) &&
              "isReactWarning" in e &&
              e.isReactWarning)
              ? s.ref
              : (i =
                  (e = Object.getOwnPropertyDescriptor(s, "ref")?.get) &&
                  "isReactWarning" in e &&
                  e.isReactWarning)
              ? s.props.ref
              : s.props.ref || s.ref);
        return t.cloneElement(o, {
          ...(function (e, r) {
            let t = { ...r };
            for (let o in r) {
              let n = e[o],
                l = r[o];
              /^on[A-Z]/.test(o)
                ? n && l
                  ? (t[o] = (...e) => {
                      l(...e), n(...e);
                    })
                  : n && (t[o] = n)
                : "style" === o
                ? (t[o] = { ...n, ...l })
                : "className" === o &&
                  (t[o] = [n, l].filter(Boolean).join(" "));
            }
            return { ...e, ...t };
          })(l, o.props),
          ref: r ? n(r, a) : a,
        });
      }
      return t.Children.count(o) > 1 ? t.Children.only(null) : null;
    });
    i.displayName = "SlotClone";
    var a = ({ children: e }) => (0, r.jsx)(r.Fragment, { children: e });
    function d(e) {
      return t.isValidElement(e) && e.type === a;
    }
    function c() {
      for (var e, r, t = 0, o = "", n = arguments.length; t < n; t++)
        (e = arguments[t]) &&
          (r = (function e(r) {
            var t,
              o,
              n = "";
            if ("string" == typeof r || "number" == typeof r) n += r;
            else if ("object" == typeof r)
              if (Array.isArray(r)) {
                var l = r.length;
                for (t = 0; t < l; t++)
                  r[t] && (o = e(r[t])) && (n && (n += " "), (n += o));
              } else for (o in r) r[o] && (n && (n += " "), (n += o));
            return n;
          })(e)) &&
          (o && (o += " "), (o += r));
      return o;
    }
    e.s(["Slot", () => s], 87576);
    let u = (e) => ("boolean" == typeof e ? `${e}` : 0 === e ? "0" : e),
      p = (e, r) => (t) => {
        var o;
        if ((null == r ? void 0 : r.variants) == null)
          return c(
            e,
            null == t ? void 0 : t.class,
            null == t ? void 0 : t.className
          );
        let { variants: n, defaultVariants: l } = r,
          s = Object.keys(n).map((e) => {
            let r = null == t ? void 0 : t[e],
              o = null == l ? void 0 : l[e];
            if (null === r) return null;
            let s = u(r) || u(o);
            return n[e][s];
          }),
          i =
            t &&
            Object.entries(t).reduce((e, r) => {
              let [t, o] = r;
              return void 0 === o || (e[t] = o), e;
            }, {});
        return c(
          e,
          s,
          null == r || null == (o = r.compoundVariants)
            ? void 0
            : o.reduce((e, r) => {
                let { class: t, className: o, ...n } = r;
                return Object.entries(n).every((e) => {
                  let [r, t] = e;
                  return Array.isArray(t)
                    ? t.includes({ ...l, ...i }[r])
                    : { ...l, ...i }[r] === t;
                })
                  ? [...e, t, o]
                  : e;
              }, []),
          null == t ? void 0 : t.class,
          null == t ? void 0 : t.className
        );
      };
    e.s(["cva", 0, p], 94237);
    let b = (e, r) => {
        if (0 === e.length) return r.classGroupId;
        let t = e[0],
          o = r.nextPart.get(t),
          n = o ? b(e.slice(1), o) : void 0;
        if (n) return n;
        if (0 === r.validators.length) return;
        let l = e.join("-");
        return r.validators.find(({ validator: e }) => e(l))?.classGroupId;
      },
      f = /^\[(.+)\]$/,
      g = (e, r, t, o) => {
        e.forEach((e) => {
          if ("string" == typeof e) {
            ("" === e ? r : m(r, e)).classGroupId = t;
            return;
          }
          "function" == typeof e
            ? h(e)
              ? g(e(o), r, t, o)
              : r.validators.push({ validator: e, classGroupId: t })
            : Object.entries(e).forEach(([e, n]) => {
                g(n, m(r, e), t, o);
              });
        });
      },
      m = (e, r) => {
        let t = e;
        return (
          r.split("-").forEach((e) => {
            t.nextPart.has(e) ||
              t.nextPart.set(e, { nextPart: new Map(), validators: [] }),
              (t = t.nextPart.get(e));
          }),
          t
        );
      },
      h = (e) => e.isThemeGetter,
      v = (e, r) =>
        r
          ? e.map(([e, t]) => [
              e,
              t.map((e) =>
                "string" == typeof e
                  ? r + e
                  : "object" == typeof e
                  ? Object.fromEntries(
                      Object.entries(e).map(([e, t]) => [r + e, t])
                    )
                  : e
              ),
            ])
          : e,
      y = (e) => {
        if (e.length <= 1) return e;
        let r = [],
          t = [];
        return (
          e.forEach((e) => {
            "[" === e[0] ? (r.push(...t.sort(), e), (t = [])) : t.push(e);
          }),
          r.push(...t.sort()),
          r
        );
      },
      x = /\s+/;
    function w() {
      let e,
        r,
        t = 0,
        o = "";
      for (; t < arguments.length; )
        (e = arguments[t++]) && (r = k(e)) && (o && (o += " "), (o += r));
      return o;
    }
    let k = (e) => {
        let r;
        if ("string" == typeof e) return e;
        let t = "";
        for (let o = 0; o < e.length; o++)
          e[o] && (r = k(e[o])) && (t && (t += " "), (t += r));
        return t;
      },
      z = (e) => {
        let r = (r) => r[e] || [];
        return (r.isThemeGetter = !0), r;
      },
      j = /^\[(?:([a-z-]+):)?(.+)\]$/i,
      C = /^\d+\/\d+$/,
      N = new Set(["px", "full", "screen"]),
      R = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
      E =
        /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
      O = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,
      S = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
      P =
        /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
      $ = (e) => G(e) || N.has(e) || C.test(e),
      A = (e) => Z(e, "length", F),
      G = (e) => !!e && !Number.isNaN(Number(e)),
      W = (e) => Z(e, "number", G),
      M = (e) => !!e && Number.isInteger(Number(e)),
      I = (e) => e.endsWith("%") && G(e.slice(0, -1)),
      T = (e) => j.test(e),
      V = (e) => R.test(e),
      B = new Set(["length", "size", "percentage"]),
      _ = (e) => Z(e, B, H),
      L = (e) => Z(e, "position", H),
      q = new Set(["image", "url"]),
      D = (e) => Z(e, q, Q),
      K = (e) => Z(e, "", J),
      U = () => !0,
      Z = (e, r, t) => {
        let o = j.exec(e);
        return (
          !!o &&
          (o[1] ? ("string" == typeof r ? o[1] === r : r.has(o[1])) : t(o[2]))
        );
      },
      F = (e) => E.test(e) && !O.test(e),
      H = () => !1,
      J = (e) => S.test(e),
      Q = (e) => P.test(e),
      X = (function (e, ...r) {
        let t,
          o,
          n,
          l = function (i) {
            let a;
            return (
              (o = (t = {
                cache: ((e) => {
                  if (e < 1) return { get: () => void 0, set: () => {} };
                  let r = 0,
                    t = new Map(),
                    o = new Map(),
                    n = (n, l) => {
                      t.set(n, l),
                        ++r > e && ((r = 0), (o = t), (t = new Map()));
                    };
                  return {
                    get(e) {
                      let r = t.get(e);
                      return void 0 !== r
                        ? r
                        : void 0 !== (r = o.get(e))
                        ? (n(e, r), r)
                        : void 0;
                    },
                    set(e, r) {
                      t.has(e) ? t.set(e, r) : n(e, r);
                    },
                  };
                })((a = r.reduce((e, r) => r(e), e())).cacheSize),
                parseClassName: ((e) => {
                  let { separator: r, experimentalParseClassName: t } = e,
                    o = 1 === r.length,
                    n = r[0],
                    l = r.length,
                    s = (e) => {
                      let t,
                        s = [],
                        i = 0,
                        a = 0;
                      for (let d = 0; d < e.length; d++) {
                        let c = e[d];
                        if (0 === i) {
                          if (c === n && (o || e.slice(d, d + l) === r)) {
                            s.push(e.slice(a, d)), (a = d + l);
                            continue;
                          }
                          if ("/" === c) {
                            t = d;
                            continue;
                          }
                        }
                        "[" === c ? i++ : "]" === c && i--;
                      }
                      let d = 0 === s.length ? e : e.substring(a),
                        c = d.startsWith("!"),
                        u = c ? d.substring(1) : d;
                      return {
                        modifiers: s,
                        hasImportantModifier: c,
                        baseClassName: u,
                        maybePostfixModifierPosition:
                          t && t > a ? t - a : void 0,
                      };
                    };
                  return t ? (e) => t({ className: e, parseClassName: s }) : s;
                })(a),
                ...((e) => {
                  let r = ((e) => {
                      let { theme: r, prefix: t } = e,
                        o = { nextPart: new Map(), validators: [] };
                      return (
                        v(Object.entries(e.classGroups), t).forEach(
                          ([e, t]) => {
                            g(t, o, e, r);
                          }
                        ),
                        o
                      );
                    })(e),
                    {
                      conflictingClassGroups: t,
                      conflictingClassGroupModifiers: o,
                    } = e;
                  return {
                    getClassGroupId: (e) => {
                      let t = e.split("-");
                      return (
                        "" === t[0] && 1 !== t.length && t.shift(),
                        b(t, r) ||
                          ((e) => {
                            if (f.test(e)) {
                              let r = f.exec(e)[1],
                                t = r?.substring(0, r.indexOf(":"));
                              if (t) return "arbitrary.." + t;
                            }
                          })(e)
                      );
                    },
                    getConflictingClassGroupIds: (e, r) => {
                      let n = t[e] || [];
                      return r && o[e] ? [...n, ...o[e]] : n;
                    },
                  };
                })(a),
              }).cache.get),
              (n = t.cache.set),
              (l = s),
              s(i)
            );
          };
        function s(e) {
          let r = o(e);
          if (r) return r;
          let l = ((e, r) => {
            let {
                parseClassName: t,
                getClassGroupId: o,
                getConflictingClassGroupIds: n,
              } = r,
              l = [],
              s = e.trim().split(x),
              i = "";
            for (let e = s.length - 1; e >= 0; e -= 1) {
              let r = s[e],
                {
                  modifiers: a,
                  hasImportantModifier: d,
                  baseClassName: c,
                  maybePostfixModifierPosition: u,
                } = t(r),
                p = !!u,
                b = o(p ? c.substring(0, u) : c);
              if (!b) {
                if (!p || !(b = o(c))) {
                  i = r + (i.length > 0 ? " " + i : i);
                  continue;
                }
                p = !1;
              }
              let f = y(a).join(":"),
                g = d ? f + "!" : f,
                m = g + b;
              if (l.includes(m)) continue;
              l.push(m);
              let h = n(b, p);
              for (let e = 0; e < h.length; ++e) {
                let r = h[e];
                l.push(g + r);
              }
              i = r + (i.length > 0 ? " " + i : i);
            }
            return i;
          })(e, t);
          return n(e, l), l;
        }
        return function () {
          return l(w.apply(null, arguments));
        };
      })(() => {
        let e = z("colors"),
          r = z("spacing"),
          t = z("blur"),
          o = z("brightness"),
          n = z("borderColor"),
          l = z("borderRadius"),
          s = z("borderSpacing"),
          i = z("borderWidth"),
          a = z("contrast"),
          d = z("grayscale"),
          c = z("hueRotate"),
          u = z("invert"),
          p = z("gap"),
          b = z("gradientColorStops"),
          f = z("gradientColorStopPositions"),
          g = z("inset"),
          m = z("margin"),
          h = z("opacity"),
          v = z("padding"),
          y = z("saturate"),
          x = z("scale"),
          w = z("sepia"),
          k = z("skew"),
          j = z("space"),
          C = z("translate"),
          N = () => ["auto", "contain", "none"],
          R = () => ["auto", "hidden", "clip", "visible", "scroll"],
          E = () => ["auto", T, r],
          O = () => [T, r],
          S = () => ["", $, A],
          P = () => ["auto", G, T],
          B = () => [
            "bottom",
            "center",
            "left",
            "left-bottom",
            "left-top",
            "right",
            "right-bottom",
            "right-top",
            "top",
          ],
          q = () => ["solid", "dashed", "dotted", "double", "none"],
          Z = () => [
            "normal",
            "multiply",
            "screen",
            "overlay",
            "darken",
            "lighten",
            "color-dodge",
            "color-burn",
            "hard-light",
            "soft-light",
            "difference",
            "exclusion",
            "hue",
            "saturation",
            "color",
            "luminosity",
          ],
          F = () => [
            "start",
            "end",
            "center",
            "between",
            "around",
            "evenly",
            "stretch",
          ],
          H = () => ["", "0", T],
          J = () => [
            "auto",
            "avoid",
            "all",
            "avoid-page",
            "page",
            "left",
            "right",
            "column",
          ],
          Q = () => [G, T];
        return {
          cacheSize: 500,
          separator: ":",
          theme: {
            colors: [U],
            spacing: [$, A],
            blur: ["none", "", V, T],
            brightness: Q(),
            borderColor: [e],
            borderRadius: ["none", "", "full", V, T],
            borderSpacing: O(),
            borderWidth: S(),
            contrast: Q(),
            grayscale: H(),
            hueRotate: Q(),
            invert: H(),
            gap: O(),
            gradientColorStops: [e],
            gradientColorStopPositions: [I, A],
            inset: E(),
            margin: E(),
            opacity: Q(),
            padding: O(),
            saturate: Q(),
            scale: Q(),
            sepia: H(),
            skew: Q(),
            space: O(),
            translate: O(),
          },
          classGroups: {
            aspect: [{ aspect: ["auto", "square", "video", T] }],
            container: ["container"],
            columns: [{ columns: [V] }],
            "break-after": [{ "break-after": J() }],
            "break-before": [{ "break-before": J() }],
            "break-inside": [
              {
                "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"],
              },
            ],
            "box-decoration": [{ "box-decoration": ["slice", "clone"] }],
            box: [{ box: ["border", "content"] }],
            display: [
              "block",
              "inline-block",
              "inline",
              "flex",
              "inline-flex",
              "table",
              "inline-table",
              "table-caption",
              "table-cell",
              "table-column",
              "table-column-group",
              "table-footer-group",
              "table-header-group",
              "table-row-group",
              "table-row",
              "flow-root",
              "grid",
              "inline-grid",
              "contents",
              "list-item",
              "hidden",
            ],
            float: [{ float: ["right", "left", "none", "start", "end"] }],
            clear: [
              { clear: ["left", "right", "both", "none", "start", "end"] },
            ],
            isolation: ["isolate", "isolation-auto"],
            "object-fit": [
              { object: ["contain", "cover", "fill", "none", "scale-down"] },
            ],
            "object-position": [{ object: [...B(), T] }],
            overflow: [{ overflow: R() }],
            "overflow-x": [{ "overflow-x": R() }],
            "overflow-y": [{ "overflow-y": R() }],
            overscroll: [{ overscroll: N() }],
            "overscroll-x": [{ "overscroll-x": N() }],
            "overscroll-y": [{ "overscroll-y": N() }],
            position: ["static", "fixed", "absolute", "relative", "sticky"],
            inset: [{ inset: [g] }],
            "inset-x": [{ "inset-x": [g] }],
            "inset-y": [{ "inset-y": [g] }],
            start: [{ start: [g] }],
            end: [{ end: [g] }],
            top: [{ top: [g] }],
            right: [{ right: [g] }],
            bottom: [{ bottom: [g] }],
            left: [{ left: [g] }],
            visibility: ["visible", "invisible", "collapse"],
            z: [{ z: ["auto", M, T] }],
            basis: [{ basis: E() }],
            "flex-direction": [
              { flex: ["row", "row-reverse", "col", "col-reverse"] },
            ],
            "flex-wrap": [{ flex: ["wrap", "wrap-reverse", "nowrap"] }],
            flex: [{ flex: ["1", "auto", "initial", "none", T] }],
            grow: [{ grow: H() }],
            shrink: [{ shrink: H() }],
            order: [{ order: ["first", "last", "none", M, T] }],
            "grid-cols": [{ "grid-cols": [U] }],
            "col-start-end": [{ col: ["auto", { span: ["full", M, T] }, T] }],
            "col-start": [{ "col-start": P() }],
            "col-end": [{ "col-end": P() }],
            "grid-rows": [{ "grid-rows": [U] }],
            "row-start-end": [{ row: ["auto", { span: [M, T] }, T] }],
            "row-start": [{ "row-start": P() }],
            "row-end": [{ "row-end": P() }],
            "grid-flow": [
              {
                "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"],
              },
            ],
            "auto-cols": [{ "auto-cols": ["auto", "min", "max", "fr", T] }],
            "auto-rows": [{ "auto-rows": ["auto", "min", "max", "fr", T] }],
            gap: [{ gap: [p] }],
            "gap-x": [{ "gap-x": [p] }],
            "gap-y": [{ "gap-y": [p] }],
            "justify-content": [{ justify: ["normal", ...F()] }],
            "justify-items": [
              { "justify-items": ["start", "end", "center", "stretch"] },
            ],
            "justify-self": [
              { "justify-self": ["auto", "start", "end", "center", "stretch"] },
            ],
            "align-content": [{ content: ["normal", ...F(), "baseline"] }],
            "align-items": [
              { items: ["start", "end", "center", "baseline", "stretch"] },
            ],
            "align-self": [
              {
                self: ["auto", "start", "end", "center", "stretch", "baseline"],
              },
            ],
            "place-content": [{ "place-content": [...F(), "baseline"] }],
            "place-items": [
              {
                "place-items": [
                  "start",
                  "end",
                  "center",
                  "baseline",
                  "stretch",
                ],
              },
            ],
            "place-self": [
              { "place-self": ["auto", "start", "end", "center", "stretch"] },
            ],
            p: [{ p: [v] }],
            px: [{ px: [v] }],
            py: [{ py: [v] }],
            ps: [{ ps: [v] }],
            pe: [{ pe: [v] }],
            pt: [{ pt: [v] }],
            pr: [{ pr: [v] }],
            pb: [{ pb: [v] }],
            pl: [{ pl: [v] }],
            m: [{ m: [m] }],
            mx: [{ mx: [m] }],
            my: [{ my: [m] }],
            ms: [{ ms: [m] }],
            me: [{ me: [m] }],
            mt: [{ mt: [m] }],
            mr: [{ mr: [m] }],
            mb: [{ mb: [m] }],
            ml: [{ ml: [m] }],
            "space-x": [{ "space-x": [j] }],
            "space-x-reverse": ["space-x-reverse"],
            "space-y": [{ "space-y": [j] }],
            "space-y-reverse": ["space-y-reverse"],
            w: [
              { w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", T, r] },
            ],
            "min-w": [{ "min-w": [T, r, "min", "max", "fit"] }],
            "max-w": [
              {
                "max-w": [
                  T,
                  r,
                  "none",
                  "full",
                  "min",
                  "max",
                  "fit",
                  "prose",
                  { screen: [V] },
                  V,
                ],
              },
            ],
            h: [
              { h: [T, r, "auto", "min", "max", "fit", "svh", "lvh", "dvh"] },
            ],
            "min-h": [
              { "min-h": [T, r, "min", "max", "fit", "svh", "lvh", "dvh"] },
            ],
            "max-h": [
              { "max-h": [T, r, "min", "max", "fit", "svh", "lvh", "dvh"] },
            ],
            size: [{ size: [T, r, "auto", "min", "max", "fit"] }],
            "font-size": [{ text: ["base", V, A] }],
            "font-smoothing": ["antialiased", "subpixel-antialiased"],
            "font-style": ["italic", "not-italic"],
            "font-weight": [
              {
                font: [
                  "thin",
                  "extralight",
                  "light",
                  "normal",
                  "medium",
                  "semibold",
                  "bold",
                  "extrabold",
                  "black",
                  W,
                ],
              },
            ],
            "font-family": [{ font: [U] }],
            "fvn-normal": ["normal-nums"],
            "fvn-ordinal": ["ordinal"],
            "fvn-slashed-zero": ["slashed-zero"],
            "fvn-figure": ["lining-nums", "oldstyle-nums"],
            "fvn-spacing": ["proportional-nums", "tabular-nums"],
            "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
            tracking: [
              {
                tracking: [
                  "tighter",
                  "tight",
                  "normal",
                  "wide",
                  "wider",
                  "widest",
                  T,
                ],
              },
            ],
            "line-clamp": [{ "line-clamp": ["none", G, W] }],
            leading: [
              {
                leading: [
                  "none",
                  "tight",
                  "snug",
                  "normal",
                  "relaxed",
                  "loose",
                  $,
                  T,
                ],
              },
            ],
            "list-image": [{ "list-image": ["none", T] }],
            "list-style-type": [{ list: ["none", "disc", "decimal", T] }],
            "list-style-position": [{ list: ["inside", "outside"] }],
            "placeholder-color": [{ placeholder: [e] }],
            "placeholder-opacity": [{ "placeholder-opacity": [h] }],
            "text-alignment": [
              { text: ["left", "center", "right", "justify", "start", "end"] },
            ],
            "text-color": [{ text: [e] }],
            "text-opacity": [{ "text-opacity": [h] }],
            "text-decoration": [
              "underline",
              "overline",
              "line-through",
              "no-underline",
            ],
            "text-decoration-style": [{ decoration: [...q(), "wavy"] }],
            "text-decoration-thickness": [
              { decoration: ["auto", "from-font", $, A] },
            ],
            "underline-offset": [{ "underline-offset": ["auto", $, T] }],
            "text-decoration-color": [{ decoration: [e] }],
            "text-transform": [
              "uppercase",
              "lowercase",
              "capitalize",
              "normal-case",
            ],
            "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
            "text-wrap": [{ text: ["wrap", "nowrap", "balance", "pretty"] }],
            indent: [{ indent: O() }],
            "vertical-align": [
              {
                align: [
                  "baseline",
                  "top",
                  "middle",
                  "bottom",
                  "text-top",
                  "text-bottom",
                  "sub",
                  "super",
                  T,
                ],
              },
            ],
            whitespace: [
              {
                whitespace: [
                  "normal",
                  "nowrap",
                  "pre",
                  "pre-line",
                  "pre-wrap",
                  "break-spaces",
                ],
              },
            ],
            break: [{ break: ["normal", "words", "all", "keep"] }],
            hyphens: [{ hyphens: ["none", "manual", "auto"] }],
            content: [{ content: ["none", T] }],
            "bg-attachment": [{ bg: ["fixed", "local", "scroll"] }],
            "bg-clip": [
              { "bg-clip": ["border", "padding", "content", "text"] },
            ],
            "bg-opacity": [{ "bg-opacity": [h] }],
            "bg-origin": [{ "bg-origin": ["border", "padding", "content"] }],
            "bg-position": [{ bg: [...B(), L] }],
            "bg-repeat": [
              {
                bg: ["no-repeat", { repeat: ["", "x", "y", "round", "space"] }],
              },
            ],
            "bg-size": [{ bg: ["auto", "cover", "contain", _] }],
            "bg-image": [
              {
                bg: [
                  "none",
                  {
                    "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"],
                  },
                  D,
                ],
              },
            ],
            "bg-color": [{ bg: [e] }],
            "gradient-from-pos": [{ from: [f] }],
            "gradient-via-pos": [{ via: [f] }],
            "gradient-to-pos": [{ to: [f] }],
            "gradient-from": [{ from: [b] }],
            "gradient-via": [{ via: [b] }],
            "gradient-to": [{ to: [b] }],
            rounded: [{ rounded: [l] }],
            "rounded-s": [{ "rounded-s": [l] }],
            "rounded-e": [{ "rounded-e": [l] }],
            "rounded-t": [{ "rounded-t": [l] }],
            "rounded-r": [{ "rounded-r": [l] }],
            "rounded-b": [{ "rounded-b": [l] }],
            "rounded-l": [{ "rounded-l": [l] }],
            "rounded-ss": [{ "rounded-ss": [l] }],
            "rounded-se": [{ "rounded-se": [l] }],
            "rounded-ee": [{ "rounded-ee": [l] }],
            "rounded-es": [{ "rounded-es": [l] }],
            "rounded-tl": [{ "rounded-tl": [l] }],
            "rounded-tr": [{ "rounded-tr": [l] }],
            "rounded-br": [{ "rounded-br": [l] }],
            "rounded-bl": [{ "rounded-bl": [l] }],
            "border-w": [{ border: [i] }],
            "border-w-x": [{ "border-x": [i] }],
            "border-w-y": [{ "border-y": [i] }],
            "border-w-s": [{ "border-s": [i] }],
            "border-w-e": [{ "border-e": [i] }],
            "border-w-t": [{ "border-t": [i] }],
            "border-w-r": [{ "border-r": [i] }],
            "border-w-b": [{ "border-b": [i] }],
            "border-w-l": [{ "border-l": [i] }],
            "border-opacity": [{ "border-opacity": [h] }],
            "border-style": [{ border: [...q(), "hidden"] }],
            "divide-x": [{ "divide-x": [i] }],
            "divide-x-reverse": ["divide-x-reverse"],
            "divide-y": [{ "divide-y": [i] }],
            "divide-y-reverse": ["divide-y-reverse"],
            "divide-opacity": [{ "divide-opacity": [h] }],
            "divide-style": [{ divide: q() }],
            "border-color": [{ border: [n] }],
            "border-color-x": [{ "border-x": [n] }],
            "border-color-y": [{ "border-y": [n] }],
            "border-color-s": [{ "border-s": [n] }],
            "border-color-e": [{ "border-e": [n] }],
            "border-color-t": [{ "border-t": [n] }],
            "border-color-r": [{ "border-r": [n] }],
            "border-color-b": [{ "border-b": [n] }],
            "border-color-l": [{ "border-l": [n] }],
            "divide-color": [{ divide: [n] }],
            "outline-style": [{ outline: ["", ...q()] }],
            "outline-offset": [{ "outline-offset": [$, T] }],
            "outline-w": [{ outline: [$, A] }],
            "outline-color": [{ outline: [e] }],
            "ring-w": [{ ring: S() }],
            "ring-w-inset": ["ring-inset"],
            "ring-color": [{ ring: [e] }],
            "ring-opacity": [{ "ring-opacity": [h] }],
            "ring-offset-w": [{ "ring-offset": [$, A] }],
            "ring-offset-color": [{ "ring-offset": [e] }],
            shadow: [{ shadow: ["", "inner", "none", V, K] }],
            "shadow-color": [{ shadow: [U] }],
            opacity: [{ opacity: [h] }],
            "mix-blend": [
              { "mix-blend": [...Z(), "plus-lighter", "plus-darker"] },
            ],
            "bg-blend": [{ "bg-blend": Z() }],
            filter: [{ filter: ["", "none"] }],
            blur: [{ blur: [t] }],
            brightness: [{ brightness: [o] }],
            contrast: [{ contrast: [a] }],
            "drop-shadow": [{ "drop-shadow": ["", "none", V, T] }],
            grayscale: [{ grayscale: [d] }],
            "hue-rotate": [{ "hue-rotate": [c] }],
            invert: [{ invert: [u] }],
            saturate: [{ saturate: [y] }],
            sepia: [{ sepia: [w] }],
            "backdrop-filter": [{ "backdrop-filter": ["", "none"] }],
            "backdrop-blur": [{ "backdrop-blur": [t] }],
            "backdrop-brightness": [{ "backdrop-brightness": [o] }],
            "backdrop-contrast": [{ "backdrop-contrast": [a] }],
            "backdrop-grayscale": [{ "backdrop-grayscale": [d] }],
            "backdrop-hue-rotate": [{ "backdrop-hue-rotate": [c] }],
            "backdrop-invert": [{ "backdrop-invert": [u] }],
            "backdrop-opacity": [{ "backdrop-opacity": [h] }],
            "backdrop-saturate": [{ "backdrop-saturate": [y] }],
            "backdrop-sepia": [{ "backdrop-sepia": [w] }],
            "border-collapse": [{ border: ["collapse", "separate"] }],
            "border-spacing": [{ "border-spacing": [s] }],
            "border-spacing-x": [{ "border-spacing-x": [s] }],
            "border-spacing-y": [{ "border-spacing-y": [s] }],
            "table-layout": [{ table: ["auto", "fixed"] }],
            caption: [{ caption: ["top", "bottom"] }],
            transition: [
              {
                transition: [
                  "none",
                  "all",
                  "",
                  "colors",
                  "opacity",
                  "shadow",
                  "transform",
                  T,
                ],
              },
            ],
            duration: [{ duration: Q() }],
            ease: [{ ease: ["linear", "in", "out", "in-out", T] }],
            delay: [{ delay: Q() }],
            animate: [
              { animate: ["none", "spin", "ping", "pulse", "bounce", T] },
            ],
            transform: [{ transform: ["", "gpu", "none"] }],
            scale: [{ scale: [x] }],
            "scale-x": [{ "scale-x": [x] }],
            "scale-y": [{ "scale-y": [x] }],
            rotate: [{ rotate: [M, T] }],
            "translate-x": [{ "translate-x": [C] }],
            "translate-y": [{ "translate-y": [C] }],
            "skew-x": [{ "skew-x": [k] }],
            "skew-y": [{ "skew-y": [k] }],
            "transform-origin": [
              {
                origin: [
                  "center",
                  "top",
                  "top-right",
                  "right",
                  "bottom-right",
                  "bottom",
                  "bottom-left",
                  "left",
                  "top-left",
                  T,
                ],
              },
            ],
            accent: [{ accent: ["auto", e] }],
            appearance: [{ appearance: ["none", "auto"] }],
            cursor: [
              {
                cursor: [
                  "auto",
                  "default",
                  "pointer",
                  "wait",
                  "text",
                  "move",
                  "help",
                  "not-allowed",
                  "none",
                  "context-menu",
                  "progress",
                  "cell",
                  "crosshair",
                  "vertical-text",
                  "alias",
                  "copy",
                  "no-drop",
                  "grab",
                  "grabbing",
                  "all-scroll",
                  "col-resize",
                  "row-resize",
                  "n-resize",
                  "e-resize",
                  "s-resize",
                  "w-resize",
                  "ne-resize",
                  "nw-resize",
                  "se-resize",
                  "sw-resize",
                  "ew-resize",
                  "ns-resize",
                  "nesw-resize",
                  "nwse-resize",
                  "zoom-in",
                  "zoom-out",
                  T,
                ],
              },
            ],
            "caret-color": [{ caret: [e] }],
            "pointer-events": [{ "pointer-events": ["none", "auto"] }],
            resize: [{ resize: ["none", "y", "x", ""] }],
            "scroll-behavior": [{ scroll: ["auto", "smooth"] }],
            "scroll-m": [{ "scroll-m": O() }],
            "scroll-mx": [{ "scroll-mx": O() }],
            "scroll-my": [{ "scroll-my": O() }],
            "scroll-ms": [{ "scroll-ms": O() }],
            "scroll-me": [{ "scroll-me": O() }],
            "scroll-mt": [{ "scroll-mt": O() }],
            "scroll-mr": [{ "scroll-mr": O() }],
            "scroll-mb": [{ "scroll-mb": O() }],
            "scroll-ml": [{ "scroll-ml": O() }],
            "scroll-p": [{ "scroll-p": O() }],
            "scroll-px": [{ "scroll-px": O() }],
            "scroll-py": [{ "scroll-py": O() }],
            "scroll-ps": [{ "scroll-ps": O() }],
            "scroll-pe": [{ "scroll-pe": O() }],
            "scroll-pt": [{ "scroll-pt": O() }],
            "scroll-pr": [{ "scroll-pr": O() }],
            "scroll-pb": [{ "scroll-pb": O() }],
            "scroll-pl": [{ "scroll-pl": O() }],
            "snap-align": [{ snap: ["start", "end", "center", "align-none"] }],
            "snap-stop": [{ snap: ["normal", "always"] }],
            "snap-type": [{ snap: ["none", "x", "y", "both"] }],
            "snap-strictness": [{ snap: ["mandatory", "proximity"] }],
            touch: [{ touch: ["auto", "none", "manipulation"] }],
            "touch-x": [{ "touch-pan": ["x", "left", "right"] }],
            "touch-y": [{ "touch-pan": ["y", "up", "down"] }],
            "touch-pz": ["touch-pinch-zoom"],
            select: [{ select: ["none", "text", "all", "auto"] }],
            "will-change": [
              { "will-change": ["auto", "scroll", "contents", "transform", T] },
            ],
            fill: [{ fill: [e, "none"] }],
            "stroke-w": [{ stroke: [$, A, W] }],
            stroke: [{ stroke: [e, "none"] }],
            sr: ["sr-only", "not-sr-only"],
            "forced-color-adjust": [
              { "forced-color-adjust": ["auto", "none"] },
            ],
          },
          conflictingClassGroups: {
            overflow: ["overflow-x", "overflow-y"],
            overscroll: ["overscroll-x", "overscroll-y"],
            inset: [
              "inset-x",
              "inset-y",
              "start",
              "end",
              "top",
              "right",
              "bottom",
              "left",
            ],
            "inset-x": ["right", "left"],
            "inset-y": ["top", "bottom"],
            flex: ["basis", "grow", "shrink"],
            gap: ["gap-x", "gap-y"],
            p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
            px: ["pr", "pl"],
            py: ["pt", "pb"],
            m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
            mx: ["mr", "ml"],
            my: ["mt", "mb"],
            size: ["w", "h"],
            "font-size": ["leading"],
            "fvn-normal": [
              "fvn-ordinal",
              "fvn-slashed-zero",
              "fvn-figure",
              "fvn-spacing",
              "fvn-fraction",
            ],
            "fvn-ordinal": ["fvn-normal"],
            "fvn-slashed-zero": ["fvn-normal"],
            "fvn-figure": ["fvn-normal"],
            "fvn-spacing": ["fvn-normal"],
            "fvn-fraction": ["fvn-normal"],
            "line-clamp": ["display", "overflow"],
            rounded: [
              "rounded-s",
              "rounded-e",
              "rounded-t",
              "rounded-r",
              "rounded-b",
              "rounded-l",
              "rounded-ss",
              "rounded-se",
              "rounded-ee",
              "rounded-es",
              "rounded-tl",
              "rounded-tr",
              "rounded-br",
              "rounded-bl",
            ],
            "rounded-s": ["rounded-ss", "rounded-es"],
            "rounded-e": ["rounded-se", "rounded-ee"],
            "rounded-t": ["rounded-tl", "rounded-tr"],
            "rounded-r": ["rounded-tr", "rounded-br"],
            "rounded-b": ["rounded-br", "rounded-bl"],
            "rounded-l": ["rounded-tl", "rounded-bl"],
            "border-spacing": ["border-spacing-x", "border-spacing-y"],
            "border-w": [
              "border-w-s",
              "border-w-e",
              "border-w-t",
              "border-w-r",
              "border-w-b",
              "border-w-l",
            ],
            "border-w-x": ["border-w-r", "border-w-l"],
            "border-w-y": ["border-w-t", "border-w-b"],
            "border-color": [
              "border-color-s",
              "border-color-e",
              "border-color-t",
              "border-color-r",
              "border-color-b",
              "border-color-l",
            ],
            "border-color-x": ["border-color-r", "border-color-l"],
            "border-color-y": ["border-color-t", "border-color-b"],
            "scroll-m": [
              "scroll-mx",
              "scroll-my",
              "scroll-ms",
              "scroll-me",
              "scroll-mt",
              "scroll-mr",
              "scroll-mb",
              "scroll-ml",
            ],
            "scroll-mx": ["scroll-mr", "scroll-ml"],
            "scroll-my": ["scroll-mt", "scroll-mb"],
            "scroll-p": [
              "scroll-px",
              "scroll-py",
              "scroll-ps",
              "scroll-pe",
              "scroll-pt",
              "scroll-pr",
              "scroll-pb",
              "scroll-pl",
            ],
            "scroll-px": ["scroll-pr", "scroll-pl"],
            "scroll-py": ["scroll-pt", "scroll-pb"],
            touch: ["touch-x", "touch-y", "touch-pz"],
            "touch-x": ["touch"],
            "touch-y": ["touch"],
            "touch-pz": ["touch"],
          },
          conflictingClassGroupModifiers: { "font-size": ["leading"] },
        };
      });
    function Y(...e) {
      return X(c(e));
    }
    e.s(["cn", () => Y], 47163);
    let ee = p(
      "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
      {
        variants: {
          variant: {
            default: "bg-primary text-primary-foreground hover:bg-primary/90",
            destructive:
              "bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline:
              "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
            secondary:
              "bg-secondary text-secondary-foreground hover:bg-secondary/80",
            ghost:
              "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
            link: "text-primary underline-offset-4 hover:underline",
          },
          size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9",
            "icon-sm": "size-8",
            "icon-lg": "size-10",
          },
        },
        defaultVariants: { variant: "default", size: "default" },
      }
    );
    function er({ className: e, variant: t, size: o, asChild: n = !1, ...l }) {
      let i = n ? s : "button";
      return (0, r.jsx)(i, {
        "data-slot": "button",
        className: Y(ee({ variant: t, size: o, className: e })),
        ...l,
      });
    }
    e.s(["Button", () => er], 67881);
  },
  10965,
  (e) => {
    "use strict";
    var r = e.i(80883);
    let t = (...e) =>
      e
        .filter((e, r, t) => !!e && "" !== e.trim() && t.indexOf(e) === r)
        .join(" ")
        .trim();
    var o = {
      xmlns: "http://www.w3.org/2000/svg",
      width: 24,
      height: 24,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
    };
    let n = (0, r.forwardRef)(
        (
          {
            color: e = "currentColor",
            size: n = 24,
            strokeWidth: l = 2,
            absoluteStrokeWidth: s,
            className: i = "",
            children: a,
            iconNode: d,
            ...c
          },
          u
        ) =>
          (0, r.createElement)(
            "svg",
            {
              ref: u,
              ...o,
              width: n,
              height: n,
              stroke: e,
              strokeWidth: s ? (24 * Number(l)) / Number(n) : l,
              className: t("lucide", i),
              ...c,
            },
            [
              ...d.map(([e, t]) => (0, r.createElement)(e, t)),
              ...(Array.isArray(a) ? a : [a]),
            ]
          )
      ),
      l = (e, o) => {
        let l = (0, r.forwardRef)(({ className: l, ...s }, i) =>
          (0, r.createElement)(n, {
            ref: i,
            iconNode: o,
            className: t(
              `lucide-${e
                .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
                .toLowerCase()}`,
              l
            ),
            ...s,
          })
        );
        return (l.displayName = `${e}`), l;
      };
    e.s(["default", () => l], 10965);
  },
]);
