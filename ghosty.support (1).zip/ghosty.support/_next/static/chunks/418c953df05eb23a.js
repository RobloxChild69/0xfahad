(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  70065,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(47163);
    function s({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card",
        className: (0, r.cn)(
          "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",
          e
        ),
        ...s,
      });
    }
    function n({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-header",
        className: (0, r.cn)(
          "@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6",
          e
        ),
        ...s,
      });
    }
    function a({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-title",
        className: (0, r.cn)("leading-none font-semibold", e),
        ...s,
      });
    }
    function l({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-description",
        className: (0, r.cn)("text-muted-foreground text-sm", e),
        ...s,
      });
    }
    function o({ className: e, ...s }) {
      return (0, t.jsx)("div", {
        "data-slot": "card-content",
        className: (0, r.cn)("px-6", e),
        ...s,
      });
    }
    e.s([
      "Card",
      () => s,
      "CardContent",
      () => o,
      "CardDescription",
      () => l,
      "CardHeader",
      () => n,
      "CardTitle",
      () => a,
    ]);
  },
  13637,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Download", [
      [
        "path",
        { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
      ],
      ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
      ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }],
    ]);
    e.s(["Download", () => t], 13637);
  },
  81947,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(94237),
      s = e.i(47163);
    let n = (0, r.cva)(
      "relative w-full rounded-lg border px-4 py-3 text-sm grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current",
      {
        variants: {
          variant: {
            default: "bg-card text-card-foreground",
            destructive:
              "text-destructive bg-card [&>svg]:text-current *:data-[slot=alert-description]:text-destructive/90",
          },
        },
        defaultVariants: { variant: "default" },
      }
    );
    function a({ className: e, variant: r, ...a }) {
      return (0, t.jsx)("div", {
        "data-slot": "alert",
        role: "alert",
        className: (0, s.cn)(n({ variant: r }), e),
        ...a,
      });
    }
    function l({ className: e, ...r }) {
      return (0, t.jsx)("div", {
        "data-slot": "alert-description",
        className: (0, s.cn)(
          "text-muted-foreground col-start-2 grid justify-items-start gap-1 text-sm [&_p]:leading-relaxed",
          e
        ),
        ...r,
      });
    }
    e.s(["Alert", () => a, "AlertDescription", () => l]);
  },
  60835,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "warnOnce", {
        enumerable: !0,
        get: function () {
          return s;
        },
      });
    let s = (e) => {};
  },
  85260,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      assign: function () {
        return i;
      },
      searchParamsToUrlQuery: function () {
        return a;
      },
      urlQueryToSearchParams: function () {
        return o;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    function a(e) {
      let t = {};
      for (let [r, s] of e.entries()) {
        let e = t[r];
        void 0 === e
          ? (t[r] = s)
          : Array.isArray(e)
          ? e.push(s)
          : (t[r] = [e, s]);
      }
      return t;
    }
    function l(e) {
      return "string" == typeof e
        ? e
        : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e
        ? ""
        : String(e);
    }
    function o(e) {
      let t = new URLSearchParams();
      for (let [r, s] of Object.entries(e))
        if (Array.isArray(s)) for (let e of s) t.append(r, l(e));
        else t.set(r, l(s));
      return t;
    }
    function i(e, ...t) {
      for (let r of t) {
        for (let t of r.keys()) e.delete(t);
        for (let [t, s] of r.entries()) e.append(t, s);
      }
      return e;
    }
  },
  91552,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      formatUrl: function () {
        return o;
      },
      formatWithValidation: function () {
        return d;
      },
      urlObjectKeys: function () {
        return i;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    let a = e.r(44066)._(e.r(85260)),
      l = /https?|ftp|gopher|file/;
    function o(e) {
      let { auth: t, hostname: r } = e,
        s = e.protocol || "",
        n = e.pathname || "",
        o = e.hash || "",
        i = e.query || "",
        d = !1;
      (t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : ""),
        e.host
          ? (d = t + e.host)
          : r &&
            ((d = t + (~r.indexOf(":") ? `[${r}]` : r)),
            e.port && (d += ":" + e.port)),
        i && "object" == typeof i && (i = String(a.urlQueryToSearchParams(i)));
      let c = e.search || (i && `?${i}`) || "";
      return (
        s && !s.endsWith(":") && (s += ":"),
        e.slashes || ((!s || l.test(s)) && !1 !== d)
          ? ((d = "//" + (d || "")), n && "/" !== n[0] && (n = "/" + n))
          : d || (d = ""),
        o && "#" !== o[0] && (o = "#" + o),
        c && "?" !== c[0] && (c = "?" + c),
        (n = n.replace(/[?#]/g, encodeURIComponent)),
        (c = c.replace("#", "%23")),
        `${s}${d}${n}${c}${o}`
      );
    }
    let i = [
      "auth",
      "hash",
      "host",
      "hostname",
      "href",
      "path",
      "pathname",
      "port",
      "protocol",
      "query",
      "search",
      "slashes",
    ];
    function d(e) {
      return o(e);
    }
  },
  60203,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    let s = e.r(80883);
    function n(e, t) {
      let r = (0, s.useRef)(null),
        n = (0, s.useRef)(null);
      return (0, s.useCallback)(
        (s) => {
          if (null === s) {
            let e = r.current;
            e && ((r.current = null), e());
            let t = n.current;
            t && ((n.current = null), t());
          } else e && (r.current = a(e, s)), t && (n.current = a(t, s));
        },
        [e, t]
      );
    }
    function a(e, t) {
      if ("function" != typeof e)
        return (
          (e.current = t),
          () => {
            e.current = null;
          }
        );
      {
        let r = e(t);
        return "function" == typeof r ? r : () => e(null);
      }
    }
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  6898,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      DecodeError: function () {
        return g;
      },
      MiddlewareNotFoundError: function () {
        return N;
      },
      MissingStaticPage: function () {
        return y;
      },
      NormalizeError: function () {
        return b;
      },
      PageNotFoundError: function () {
        return j;
      },
      SP: function () {
        return h;
      },
      ST: function () {
        return p;
      },
      WEB_VITALS: function () {
        return a;
      },
      execOnce: function () {
        return l;
      },
      getDisplayName: function () {
        return u;
      },
      getLocationOrigin: function () {
        return d;
      },
      getURL: function () {
        return c;
      },
      isAbsoluteUrl: function () {
        return i;
      },
      isResSent: function () {
        return x;
      },
      loadGetInitialProps: function () {
        return m;
      },
      normalizeRepeatedSlashes: function () {
        return f;
      },
      stringifyError: function () {
        return v;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    let a = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];
    function l(e) {
      let t,
        r = !1;
      return (...s) => (r || ((r = !0), (t = e(...s))), t);
    }
    let o = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
      i = (e) => o.test(e);
    function d() {
      let { protocol: e, hostname: t, port: r } = window.location;
      return `${e}//${t}${r ? ":" + r : ""}`;
    }
    function c() {
      let { href: e } = window.location,
        t = d();
      return e.substring(t.length);
    }
    function u(e) {
      return "string" == typeof e ? e : e.displayName || e.name || "Unknown";
    }
    function x(e) {
      return e.finished || e.headersSent;
    }
    function f(e) {
      let t = e.split("?");
      return (
        t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") +
        (t[1] ? `?${t.slice(1).join("?")}` : "")
      );
    }
    async function m(e, t) {
      let r = t.res || (t.ctx && t.ctx.res);
      if (!e.getInitialProps)
        return t.ctx && t.Component
          ? { pageProps: await m(t.Component, t.ctx) }
          : {};
      let s = await e.getInitialProps(t);
      if (r && x(r)) return s;
      if (!s)
        throw Object.defineProperty(
          Error(
            `"${u(
              e
            )}.getInitialProps()" should resolve to an object. But found "${s}" instead.`
          ),
          "__NEXT_ERROR_CODE",
          { value: "E394", enumerable: !1, configurable: !0 }
        );
      return s;
    }
    let h = "undefined" != typeof performance,
      p =
        h &&
        ["mark", "measure", "getEntriesByName"].every(
          (e) => "function" == typeof performance[e]
        );
    class g extends Error {}
    class b extends Error {}
    class j extends Error {
      constructor(e) {
        super(),
          (this.code = "ENOENT"),
          (this.name = "PageNotFoundError"),
          (this.message = `Cannot find module for page: ${e}`);
      }
    }
    class y extends Error {
      constructor(e, t) {
        super(),
          (this.message = `Failed to load static file for page: ${e} ${t}`);
      }
    }
    class N extends Error {
      constructor() {
        super(),
          (this.code = "ENOENT"),
          (this.message = "Cannot find the middleware module");
      }
    }
    function v(e) {
      return JSON.stringify({ message: e.message, stack: e.stack });
    }
  },
  73350,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    let s = e.r(6898),
      n = e.r(56075);
    function a(e) {
      if (!(0, s.isAbsoluteUrl)(e)) return !0;
      try {
        let t = (0, s.getLocationOrigin)(),
          r = new URL(e, t);
        return r.origin === t && (0, n.hasBasePath)(r.pathname);
      } catch (e) {
        return !1;
      }
    }
  },
  95136,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "errorOnce", {
        enumerable: !0,
        get: function () {
          return s;
        },
      });
    let s = (e) => {};
  },
  61021,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      default: function () {
        return g;
      },
      useLinkStatus: function () {
        return j;
      },
    };
    for (var n in s) Object.defineProperty(r, n, { enumerable: !0, get: s[n] });
    let a = e.r(44066),
      l = e.r(93046),
      o = a._(e.r(80883)),
      i = e.r(91552),
      d = e.r(89260),
      c = e.r(60203),
      u = e.r(6898),
      x = e.r(63118);
    e.r(60835);
    let f = e.r(68193),
      m = e.r(73350),
      h = e.r(50696);
    function p(e) {
      return "string" == typeof e ? e : (0, i.formatUrl)(e);
    }
    function g(t) {
      var r;
      let s,
        n,
        a,
        [i, g] = (0, o.useOptimistic)(f.IDLE_LINK_STATUS),
        j = (0, o.useRef)(null),
        {
          href: y,
          as: N,
          children: v,
          prefetch: w = null,
          passHref: C,
          replace: k,
          shallow: P,
          scroll: S,
          onClick: _,
          onMouseEnter: O,
          onTouchStart: T,
          legacyBehavior: A = !1,
          onNavigate: E,
          ref: R,
          unstable_dynamicOnHover: D,
          ...L
        } = t;
      (s = v),
        A &&
          ("string" == typeof s || "number" == typeof s) &&
          (s = (0, l.jsx)("a", { children: s }));
      let M = o.default.useContext(d.AppRouterContext),
        F = !1 !== w,
        I =
          !1 !== w
            ? null === (r = w) || "auto" === r
              ? h.FetchStrategy.PPR
              : h.FetchStrategy.Full
            : h.FetchStrategy.PPR,
        { href: U, as: B } = o.default.useMemo(() => {
          let e = p(y);
          return { href: e, as: N ? p(N) : e };
        }, [y, N]);
      if (A) {
        if (s?.$$typeof === Symbol.for("react.lazy"))
          throw Object.defineProperty(
            Error(
              "`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."
            ),
            "__NEXT_ERROR_CODE",
            { value: "E863", enumerable: !1, configurable: !0 }
          );
        n = o.default.Children.only(s);
      }
      let $ = A ? n && "object" == typeof n && n.ref : R,
        z = o.default.useCallback(
          (e) => (
            null !== M &&
              (j.current = (0, f.mountLinkInstance)(e, U, M, I, F, g)),
            () => {
              j.current &&
                ((0, f.unmountLinkForCurrentNavigation)(j.current),
                (j.current = null)),
                (0, f.unmountPrefetchableInstance)(e);
            }
          ),
          [F, U, M, I, g]
        ),
        G = {
          ref: (0, c.useMergedRef)(z, $),
          onClick(t) {
            A || "function" != typeof _ || _(t),
              A &&
                n.props &&
                "function" == typeof n.props.onClick &&
                n.props.onClick(t),
              !M ||
                t.defaultPrevented ||
                (function (t, r, s, n, a, l, i) {
                  if ("undefined" != typeof window) {
                    let d,
                      { nodeName: c } = t.currentTarget;
                    if (
                      ("A" === c.toUpperCase() &&
                        (((d = t.currentTarget.getAttribute("target")) &&
                          "_self" !== d) ||
                          t.metaKey ||
                          t.ctrlKey ||
                          t.shiftKey ||
                          t.altKey ||
                          (t.nativeEvent && 2 === t.nativeEvent.which))) ||
                      t.currentTarget.hasAttribute("download")
                    )
                      return;
                    if (!(0, m.isLocalURL)(r)) {
                      a && (t.preventDefault(), location.replace(r));
                      return;
                    }
                    if ((t.preventDefault(), i)) {
                      let e = !1;
                      if (
                        (i({
                          preventDefault: () => {
                            e = !0;
                          },
                        }),
                        e)
                      )
                        return;
                    }
                    let { dispatchNavigateAction: u } = e.r(56797);
                    o.default.startTransition(() => {
                      u(s || r, a ? "replace" : "push", l ?? !0, n.current);
                    });
                  }
                })(t, U, B, j, k, S, E);
          },
          onMouseEnter(e) {
            A || "function" != typeof O || O(e),
              A &&
                n.props &&
                "function" == typeof n.props.onMouseEnter &&
                n.props.onMouseEnter(e),
              M && F && (0, f.onNavigationIntent)(e.currentTarget, !0 === D);
          },
          onTouchStart: function (e) {
            A || "function" != typeof T || T(e),
              A &&
                n.props &&
                "function" == typeof n.props.onTouchStart &&
                n.props.onTouchStart(e),
              M && F && (0, f.onNavigationIntent)(e.currentTarget, !0 === D);
          },
        };
      return (
        (0, u.isAbsoluteUrl)(B)
          ? (G.href = B)
          : (A && !C && ("a" !== n.type || "href" in n.props)) ||
            (G.href = (0, x.addBasePath)(B)),
        (a = A
          ? o.default.cloneElement(n, G)
          : (0, l.jsx)("a", { ...L, ...G, children: s })),
        (0, l.jsx)(b.Provider, { value: i, children: a })
      );
    }
    e.r(95136);
    let b = (0, o.createContext)(f.IDLE_LINK_STATUS),
      j = () => (0, o.useContext)(b);
    ("function" == typeof r.default ||
      ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  84675,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("ArrowLeft", [
      ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
      ["path", { d: "M19 12H5", key: "x3x0zl" }],
    ]);
    e.s(["ArrowLeft", () => t], 84675);
  },
  17508,
  52910,
  (e) => {
    "use strict";
    var t = e.i(10965);
    let r = (0, t.default)("ChevronRight", [
      ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }],
    ]);
    e.s(["ChevronRight", () => r], 17508);
    let s = (0, t.default)("ChevronLeft", [
      ["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }],
    ]);
    e.s(["ChevronLeft", () => s], 52910);
  },
  88297,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("CircleCheckBig", [
      ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
      ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }],
    ]);
    e.s(["CheckCircle", () => t], 88297);
  },
  13293,
  76841,
  (e) => {
    "use strict";
    var t = e.i(93046);
    let r = (0, e.i(10965).default)("Ghost", [
      ["path", { d: "M9 10h.01", key: "qbtxuw" }],
      ["path", { d: "M15 10h.01", key: "1qmjsl" }],
      [
        "path",
        {
          d: "M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z",
          key: "uwwb07",
        },
      ],
    ]);
    var s = e.i(67881);
    function n() {
      return (0, t.jsx)("header", {
        className:
          "border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50",
        children: (0, t.jsxs)("div", {
          className:
            "container mx-auto px-4 py-4 flex items-center justify-between",
          children: [
            (0, t.jsxs)("div", {
              className: "flex items-center gap-2",
              children: [
                (0, t.jsx)(r, { className: "h-8 w-8 text-primary" }),
                (0, t.jsx)("span", {
                  className: "text-2xl font-bold text-foreground",
                  children: "GHOSTY Services",
                }),
              ],
            }),
            (0, t.jsxs)("nav", {
              className: "hidden md:flex items-center gap-6",
              children: [
                (0, t.jsx)("a", {
                  href: "#products",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Products",
                }),
                (0, t.jsx)("a", {
                  href: "#guides",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Guides",
                }),
                (0, t.jsx)("a", {
                  href: "#support",
                  className:
                    "text-muted-foreground hover:text-foreground transition-colors",
                  children: "Support",
                }),
                (0, t.jsx)(s.Button, {
                  size: "sm",
                  className:
                    "bg-primary hover:bg-primary/90 text-primary-foreground",
                  children: "Get Started",
                }),
              ],
            }),
          ],
        }),
      });
    }
    function a() {
      return (0, t.jsx)("footer", {
        className: "border-t border-border bg-card/50 py-12 px-4",
        children: (0, t.jsxs)("div", {
          className: "container mx-auto",
          children: [
            (0, t.jsxs)("div", {
              className: "grid grid-cols-1 md:grid-cols-4 gap-8 mb-8",
              children: [
                (0, t.jsxs)("div", {
                  className: "space-y-4",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-2",
                      children: [
                        (0, t.jsx)(r, { className: "h-6 w-6 text-primary" }),
                        (0, t.jsx)("span", {
                          className: "text-xl font-bold text-foreground",
                          children: "GHOSTY Services",
                        }),
                      ],
                    }),
                    (0, t.jsx)("p", {
                      className:
                        "text-muted-foreground text-sm leading-relaxed",
                      children:
                        "Your trusted source for gaming guides, tutorials, and professional services.",
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  children: [
                    (0, t.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Products",
                    }),
                    (0, t.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "All Guides",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "FPS Games",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Battle Royale",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Services",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  children: [
                    (0, t.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Support",
                    }),
                    (0, t.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Help Center",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Contact Us",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "FAQ",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Discord",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  children: [
                    (0, t.jsx)("h4", {
                      className: "font-semibold mb-4 text-foreground",
                      children: "Legal",
                    }),
                    (0, t.jsxs)("ul", {
                      className: "space-y-2 text-sm",
                      children: [
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Terms of Service",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Privacy Policy",
                          }),
                        }),
                        (0, t.jsx)("li", {
                          children: (0, t.jsx)("a", {
                            href: "#",
                            className:
                              "text-muted-foreground hover:text-primary transition-colors",
                            children: "Refund Policy",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            (0, t.jsx)("div", {
              className:
                "border-t border-border pt-8 text-center text-sm text-muted-foreground",
              children: (0, t.jsx)("p", {
                children: "© 2025 GHOSTY Services. All rights reserved.",
              }),
            }),
          ],
        }),
      });
    }
    e.s(["Header", () => n], 13293), e.s(["Footer", () => a], 76841);
  },
  42838,
  (e) => {
    "use strict";
    let t = (0, e.i(10965).default)("Shield", [
      [
        "path",
        {
          d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
          key: "oel41y",
        },
      ],
    ]);
    e.s(["Shield", () => t], 42838);
  },
  97788,
  (e) => {
    "use strict";
    var t = e.i(93046),
      r = e.i(80883),
      s = e.i(61021),
      n = e.i(84675),
      a = e.i(13637),
      l = e.i(42838),
      o = e.i(10965);
    let i = (0, o.default)("Upload", [
        [
          "path",
          { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
        ],
        ["polyline", { points: "17 8 12 3 7 8", key: "t8dd8p" }],
        ["line", { x1: "12", x2: "12", y1: "3", y2: "15", key: "widbto" }],
      ]),
      d = (0, o.default)("Play", [
        ["polygon", { points: "6 3 20 12 6 21 6 3", key: "1oa8hb" }],
      ]);
    var c = e.i(17508),
      u = e.i(52910),
      x = e.i(88297),
      f = e.i(67881),
      m = e.i(81947),
      h = e.i(13293),
      p = e.i(76841),
      g = e.i(70065);
    function b() {
      let [e, o] = (0, r.useState)(1),
        b = (e / 4) * 100;
      return (0, t.jsxs)("div", {
        className: "min-h-screen bg-background",
        children: [
          (0, t.jsx)(h.Header, {}),
          (0, t.jsx)("section", {
            className:
              "py-12 px-4 bg-gradient-to-b from-primary/10 to-background border-b border-border",
            children: (0, t.jsxs)("div", {
              className: "container mx-auto max-w-4xl",
              children: [
                (0, t.jsxs)(s.default, {
                  href: "/",
                  className:
                    "inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-6",
                  children: [
                    (0, t.jsx)(n.ArrowLeft, { className: "h-5 w-5" }),
                    (0, t.jsx)("span", {
                      className: "font-semibold",
                      children: "Back to Home",
                    }),
                  ],
                }),
                (0, t.jsx)("h1", {
                  className: "text-5xl font-bold mb-4 text-foreground",
                  children: "Fortnite Cheat Setup Guide",
                }),
                (0, t.jsx)("p", {
                  className: "text-muted-foreground text-xl text-pretty",
                  children:
                    "Complete setup instructions for Fortnite cheat installation and usage",
                }),
              ],
            }),
          }),
          (0, t.jsx)("section", {
            className:
              "sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border py-4 px-4",
            children: (0, t.jsxs)("div", {
              className: "container mx-auto max-w-4xl",
              children: [
                (0, t.jsxs)("div", {
                  className: "flex items-center justify-between mb-3",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "text-sm font-medium text-foreground",
                      children: ["Step ", e, " of ", 4],
                    }),
                    (0, t.jsxs)("div", {
                      className: "text-sm text-muted-foreground",
                      children: [b.toFixed(0), "% Complete"],
                    }),
                  ],
                }),
                (0, t.jsx)("div", {
                  className: "h-2 bg-muted rounded-full overflow-hidden",
                  children: (0, t.jsx)("div", {
                    className:
                      "h-full bg-primary transition-all duration-500 ease-out",
                    style: { width: `${b}%` },
                  }),
                }),
              ],
            }),
          }),
          (0, t.jsxs)("main", {
            className: "container mx-auto px-4 py-12 max-w-4xl min-h-[600px]",
            children: [
              1 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-blue-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-blue-500/30",
                          children: "1",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Disable Antivirus",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children:
                                "Turn off Windows Defender to prevent interference",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsx)(g.Card, {
                      className:
                        "border-blue-500/30 bg-blue-500/5 backdrop-blur",
                      children: (0, t.jsxs)(g.CardContent, {
                        className: "pt-8 space-y-6",
                        children: [
                          (0, t.jsx)("p", {
                            className: "text-muted-foreground text-lg",
                            children:
                              "Disable Windows Defender and other antivirus software to prevent interference with the loader.",
                          }),
                          (0, t.jsx)(m.Alert, {
                            className: "border-blue-500/50 bg-blue-500/10",
                            children: (0, t.jsxs)(m.AlertDescription, {
                              className: "text-foreground",
                              children: [
                                (0, t.jsx)("p", {
                                  className: "font-semibold mb-2",
                                  children: "Tip:",
                                }),
                                (0, t.jsx)("p", {
                                  children:
                                    "Please refer to the Valorant Manual for detailed Windows Defender disabling instructions using dControl.",
                                }),
                              ],
                            }),
                          }),
                          (0, t.jsx)("div", {
                            className: "bg-secondary/50 rounded-lg p-6",
                            children: (0, t.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, t.jsx)(l.Shield, {
                                  className:
                                    "h-8 w-8 text-blue-500 mt-1 shrink-0",
                                }),
                                (0, t.jsxs)("div", {
                                  className: "flex-1",
                                  children: [
                                    (0, t.jsx)("h3", {
                                      className:
                                        "text-xl font-semibold text-foreground mb-3",
                                      children: "Download dControl:",
                                    }),
                                    (0, t.jsxs)("p", {
                                      className: "text-muted-foreground mb-4",
                                      children: [
                                        "Password:",
                                        " ",
                                        (0, t.jsx)("span", {
                                          className:
                                            "font-mono bg-background px-3 py-1 rounded font-semibold text-foreground",
                                          children: "sordum",
                                        }),
                                      ],
                                    }),
                                    (0, t.jsx)(f.Button, {
                                      asChild: !0,
                                      className:
                                        "w-full sm:w-auto h-12 text-base",
                                      children: (0, t.jsxs)("a", {
                                        href: "https://content.gitbook.com/content/GX215IYet7df7lTywp3p/blobs/8VIaLdTwubOA0G2iVJAR/DControl.rar",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: [
                                          (0, t.jsx)(a.Download, {
                                            className: "mr-2 h-5 w-5",
                                          }),
                                          "Download dControl",
                                        ],
                                      }),
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          }),
                        ],
                      }),
                    }),
                  ],
                }),
              2 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-purple-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-purple-500/30",
                          children: "2",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Install Dependencies",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children:
                                "Required software for the cheat to function",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsx)(g.Card, {
                      className:
                        "border-purple-500/30 bg-purple-500/5 backdrop-blur",
                      children: (0, t.jsxs)(g.CardContent, {
                        className: "pt-8 space-y-6",
                        children: [
                          (0, t.jsx)("p", {
                            className: "text-muted-foreground text-lg mb-6",
                            children:
                              "Install required Visual C++ Redistributables and DirectX.",
                          }),
                          (0, t.jsxs)("div", {
                            className: "space-y-4",
                            children: [
                              (0, t.jsx)("div", {
                                className: "bg-secondary/50 rounded-lg p-6",
                                children: (0, t.jsxs)("div", {
                                  className:
                                    "flex items-start justify-between gap-4",
                                  children: [
                                    (0, t.jsxs)("div", {
                                      className: "flex-1",
                                      children: [
                                        (0, t.jsx)("h3", {
                                          className:
                                            "text-xl font-semibold text-foreground mb-3",
                                          children:
                                            "Visual C++ Redistributables",
                                        }),
                                        (0, t.jsx)("p", {
                                          className: "text-muted-foreground",
                                          children:
                                            "All-in-One runtime package",
                                        }),
                                      ],
                                    }),
                                    (0, t.jsx)(f.Button, {
                                      asChild: !0,
                                      className:
                                        "bg-purple-500 hover:bg-purple-600 h-12 text-base shrink-0",
                                      children: (0, t.jsxs)("a", {
                                        href: "https://www.techpowerup.com/download/visual-c-redistributable-runtime-package-all-in-one/",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: [
                                          (0, t.jsx)(a.Download, {
                                            className: "mr-2 h-5 w-5",
                                          }),
                                          "Download",
                                        ],
                                      }),
                                    }),
                                  ],
                                }),
                              }),
                              (0, t.jsx)("div", {
                                className: "bg-secondary/50 rounded-lg p-6",
                                children: (0, t.jsxs)("div", {
                                  className:
                                    "flex items-start justify-between gap-4",
                                  children: [
                                    (0, t.jsxs)("div", {
                                      className: "flex-1",
                                      children: [
                                        (0, t.jsx)("h3", {
                                          className:
                                            "text-xl font-semibold text-foreground mb-3",
                                          children: "DirectX Runtime",
                                        }),
                                        (0, t.jsx)("p", {
                                          className: "text-muted-foreground",
                                          children:
                                            "Required for graphics rendering",
                                        }),
                                      ],
                                    }),
                                    (0, t.jsx)(f.Button, {
                                      asChild: !0,
                                      className:
                                        "bg-purple-500 hover:bg-purple-600 h-12 text-base shrink-0",
                                      children: (0, t.jsxs)("a", {
                                        href: "https://www.microsoft.com/en-us/download/details.aspx?id=35",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: [
                                          (0, t.jsx)(a.Download, {
                                            className: "mr-2 h-5 w-5",
                                          }),
                                          "Download",
                                        ],
                                      }),
                                    }),
                                  ],
                                }),
                              }),
                            ],
                          }),
                          (0, t.jsx)(m.Alert, {
                            className: "border-purple-500/50 bg-purple-500/10",
                            children: (0, t.jsx)(m.AlertDescription, {
                              className: "text-foreground",
                              children:
                                "For detailed installation instructions, refer to the Valorant Manual.",
                            }),
                          }),
                        ],
                      }),
                    }),
                  ],
                }),
              3 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-primary flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-primary/30",
                          children: "3",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Install Loader",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children: "Download the Fortnite loader",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsx)(g.Card, {
                      className: "border-primary/30 bg-primary/5 backdrop-blur",
                      children: (0, t.jsx)(g.CardContent, {
                        className: "pt-8",
                        children: (0, t.jsxs)("div", {
                          className: "flex items-start gap-4",
                          children: [
                            (0, t.jsx)(i, {
                              className: "h-8 w-8 text-primary mt-1 shrink-0",
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex-1",
                              children: [
                                (0, t.jsx)("h3", {
                                  className:
                                    "text-2xl font-semibold text-foreground mb-4",
                                  children: "Loader Status:",
                                }),
                                (0, t.jsx)("p", {
                                  className: "text-muted-foreground text-lg",
                                  children: "New loader Today (Wednesday)",
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    }),
                  ],
                }),
              4 === e &&
                (0, t.jsxs)("div", {
                  className: "animate-in fade-in duration-500",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center gap-4 mb-8",
                      children: [
                        (0, t.jsx)("div", {
                          className:
                            "w-20 h-20 rounded-2xl bg-green-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-green-500/30",
                          children: "4",
                        }),
                        (0, t.jsxs)("div", {
                          children: [
                            (0, t.jsx)("h2", {
                              className:
                                "text-5xl font-bold text-foreground mb-2",
                              children: "Usage Instructions",
                            }),
                            (0, t.jsx)("p", {
                              className: "text-muted-foreground text-xl",
                              children: "How to inject and use the cheat",
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, t.jsxs)("div", {
                      className: "space-y-6",
                      children: [
                        (0, t.jsx)(g.Card, {
                          className:
                            "border-green-500/30 bg-green-500/5 backdrop-blur",
                          children: (0, t.jsxs)(g.CardContent, {
                            className: "pt-8",
                            children: [
                              (0, t.jsxs)("div", {
                                className: "flex items-start gap-4 mb-6",
                                children: [
                                  (0, t.jsx)(d, {
                                    className:
                                      "h-8 w-8 text-green-500 mt-1 shrink-0",
                                  }),
                                  (0, t.jsxs)("div", {
                                    className: "flex-1",
                                    children: [
                                      (0, t.jsx)("h3", {
                                        className:
                                          "text-2xl font-semibold text-foreground mb-4",
                                        children: "Follow these steps:",
                                      }),
                                      (0, t.jsx)("p", {
                                        className:
                                          "text-muted-foreground text-lg mb-6",
                                        children:
                                          "Follow these steps to inject and use the cheat.",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, t.jsx)("div", {
                                className: "bg-secondary/50 rounded-lg p-6",
                                children: (0, t.jsxs)("ol", {
                                  className: "space-y-4",
                                  children: [
                                    (0, t.jsxs)("li", {
                                      className: "flex items-start gap-4",
                                      children: [
                                        (0, t.jsx)("span", {
                                          className:
                                            "flex-shrink-0 w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-500 text-lg font-semibold",
                                          children: "1",
                                        }),
                                        (0, t.jsx)("span", {
                                          className:
                                            "text-muted-foreground text-lg pt-1",
                                          children: "Open the loader",
                                        }),
                                      ],
                                    }),
                                    (0, t.jsxs)("li", {
                                      className: "flex items-start gap-4",
                                      children: [
                                        (0, t.jsx)("span", {
                                          className:
                                            "flex-shrink-0 w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-500 text-lg font-semibold",
                                          children: "2",
                                        }),
                                        (0, t.jsx)("span", {
                                          className:
                                            "text-muted-foreground text-lg pt-1",
                                          children: 'Press "Inject"',
                                        }),
                                      ],
                                    }),
                                    (0, t.jsxs)("li", {
                                      className: "flex items-start gap-4",
                                      children: [
                                        (0, t.jsx)("span", {
                                          className:
                                            "flex-shrink-0 w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-500 text-lg font-semibold",
                                          children: "3",
                                        }),
                                        (0, t.jsx)("span", {
                                          className:
                                            "text-muted-foreground text-lg pt-1",
                                          children: 'Press "OK" on the pop-up',
                                        }),
                                      ],
                                    }),
                                    (0, t.jsxs)("li", {
                                      className: "flex items-start gap-4",
                                      children: [
                                        (0, t.jsx)("span", {
                                          className:
                                            "flex-shrink-0 w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-500 text-lg font-semibold",
                                          children: "4",
                                        }),
                                        (0, t.jsx)("span", {
                                          className:
                                            "text-muted-foreground text-lg pt-1",
                                          children: "Open Fortnite",
                                        }),
                                      ],
                                    }),
                                    (0, t.jsxs)("li", {
                                      className: "flex items-start gap-4",
                                      children: [
                                        (0, t.jsx)("span", {
                                          className:
                                            "flex-shrink-0 w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-500 text-lg font-semibold",
                                          children: "5",
                                        }),
                                        (0, t.jsx)("span", {
                                          className:
                                            "text-muted-foreground text-lg pt-1",
                                          children:
                                            "Press Insert to open the menu",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              }),
                            ],
                          }),
                        }),
                        (0, t.jsx)(m.Alert, {
                          children: (0, t.jsx)(m.AlertDescription, {
                            className: "text-muted-foreground text-base",
                            children:
                              "Make sure to follow all steps in order. If you encounter any issues, please contact support on our Discord server.",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
            ],
          }),
          (0, t.jsx)("section", {
            className:
              "sticky bottom-0 bg-background/95 backdrop-blur border-t border-border py-6 px-4",
            children: (0, t.jsx)("div", {
              className: "container mx-auto max-w-4xl",
              children: (0, t.jsxs)("div", {
                className: "flex items-center justify-between gap-4",
                children: [
                  (0, t.jsxs)(f.Button, {
                    variant: "outline",
                    size: "lg",
                    onClick: () => {
                      e > 1 &&
                        (o(e - 1),
                        window.scrollTo({ top: 0, behavior: "smooth" }));
                    },
                    disabled: 1 === e,
                    className: "h-14 px-8 text-base bg-transparent",
                    children: [
                      (0, t.jsx)(u.ChevronLeft, { className: "mr-2 h-5 w-5" }),
                      "Back",
                    ],
                  }),
                  (0, t.jsxs)("div", {
                    className: "text-center",
                    children: [
                      (0, t.jsx)("p", {
                        className: "text-sm text-muted-foreground mb-1",
                        children: "Step Progress",
                      }),
                      (0, t.jsxs)("p", {
                        className: "text-lg font-semibold text-foreground",
                        children: [e, " / ", 4],
                      }),
                    ],
                  }),
                  (0, t.jsx)(f.Button, {
                    size: "lg",
                    onClick: () => {
                      e < 4 &&
                        (o(e + 1),
                        window.scrollTo({ top: 0, behavior: "smooth" }));
                    },
                    disabled: 4 === e,
                    className:
                      "h-14 px-8 text-base bg-primary hover:bg-primary/90",
                    children:
                      4 === e
                        ? (0, t.jsxs)(t.Fragment, {
                            children: [
                              (0, t.jsx)(x.CheckCircle, {
                                className: "mr-2 h-5 w-5",
                              }),
                              "Complete",
                            ],
                          })
                        : (0, t.jsxs)(t.Fragment, {
                            children: [
                              "Continue",
                              (0, t.jsx)(c.ChevronRight, {
                                className: "ml-2 h-5 w-5",
                              }),
                            ],
                          }),
                  }),
                ],
              }),
            }),
          }),
          (0, t.jsx)(p.Footer, {}),
        ],
      });
    }
    e.s(["default", () => b], 97788);
  },
]);
