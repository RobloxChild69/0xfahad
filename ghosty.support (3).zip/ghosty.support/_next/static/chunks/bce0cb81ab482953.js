(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  10865,
  (e) => {
    "use strict";
    var s = e.i(93046),
      t = e.i(80883),
      l = e.i(61021),
      r = e.i(84675),
      a = e.i(13637),
      n = e.i(64877),
      i = e.i(35301),
      d = e.i(10712),
      c = e.i(17508),
      o = e.i(52910),
      x = e.i(48054),
      h = e.i(67881),
      m = e.i(81947);
    function f() {
      let [e, f] = (0, t.useState)("selection"),
        [j, p] = (0, t.useState)(0),
        u = 10 * ("tpmOn" === e || "tpmOff" === e),
        g = () => {
          j < u - 1 &&
            (p(j + 1), window.scrollTo({ top: 0, behavior: "smooth" }));
        },
        b = () => {
          j > 0 && (p(j - 1), window.scrollTo({ top: 0, behavior: "smooth" }));
        },
        N = (e) => {
          f(e), p(0), window.scrollTo({ top: 0, behavior: "smooth" });
        };
      return (0, s.jsxs)("div", {
        className: "min-h-screen bg-background",
        children: [
          (0, s.jsx)("header", {
            className:
              "sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60",
            children: (0, s.jsx)("div", {
              className: "container flex h-16 items-center px-4",
              children: (0, s.jsxs)(l.default, {
                href: "/guides/hwid-unban",
                className:
                  "flex items-center gap-2 text-foreground hover:text-primary transition-colors",
                children: [
                  (0, s.jsx)(r.ArrowLeft, { className: "h-5 w-5" }),
                  (0, s.jsx)("span", {
                    className: "font-semibold",
                    children: "Back to Selection",
                  }),
                ],
              }),
            }),
          }),
          "selection" === e &&
            (0, s.jsxs)(s.Fragment, {
              children: [
                (0, s.jsx)("section", {
                  className:
                    "relative py-20 px-4 bg-gradient-to-b from-blue-500/20 to-background",
                  children: (0, s.jsxs)("div", {
                    className: "container mx-auto max-w-4xl text-center",
                    children: [
                      (0, s.jsx)("h1", {
                        className: "text-5xl font-bold mb-6 text-balance",
                        children: "Valorant HWID Spoof Guide",
                      }),
                      (0, s.jsx)("p", {
                        className: "text-xl text-muted-foreground text-pretty",
                        children: "Choose your spoofing method",
                      }),
                    ],
                  }),
                }),
                (0, s.jsx)("section", {
                  className: "py-12 px-4",
                  children: (0, s.jsxs)("div", {
                    className:
                      "container mx-auto max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-6",
                    children: [
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border-2 border-red-500/50 rounded-lg p-8 space-y-6 hover:border-red-500 transition-colors",
                        children: [
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-2xl font-bold text-red-500",
                                children: "TPM ON Spoof",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-muted-foreground",
                                children:
                                  "TPM ON - SecureBoot ON - Core Isolation ON",
                              }),
                            ],
                          }),
                          (0, s.jsxs)("ul", {
                            className: "space-y-3 text-sm",
                            children: [
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className:
                                      "h-5 w-5 text-green-500 shrink-0 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Windows reinstall (Ghost Spectre)",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className:
                                      "h-5 w-5 text-green-500 shrink-0 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "Disable Windows Defender",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className:
                                      "h-5 w-5 text-green-500 shrink-0 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "BIOS flash",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className:
                                      "h-5 w-5 text-green-500 shrink-0 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "MAC and device spoofing",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className:
                                      "h-5 w-5 text-green-500 shrink-0 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "PERM spoof",
                                  }),
                                ],
                              }),
                            ],
                          }),
                          (0, s.jsxs)(h.Button, {
                            onClick: () => N("tpmOn"),
                            className: "w-full bg-red-500 hover:bg-red-600",
                            children: [
                              "Start TPM ON Guide",
                              (0, s.jsx)(c.ChevronRight, {
                                className: "ml-2 h-5 w-5",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className:
                          "bg-card border-2 border-orange-500/50 rounded-lg p-8 space-y-6 hover:border-orange-500 transition-colors",
                        children: [
                          (0, s.jsxs)("div", {
                            className: "space-y-2",
                            children: [
                              (0, s.jsx)("h2", {
                                className: "text-2xl font-bold text-orange-500",
                                children: "TPM OFF Spoof",
                              }),
                              (0, s.jsx)("p", {
                                className: "text-muted-foreground",
                                children:
                                  "TPM OFF - SecureBoot ON - Core Isolation ON",
                              }),
                            ],
                          }),
                          (0, s.jsxs)("ul", {
                            className: "space-y-3 text-sm",
                            children: [
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className:
                                      "h-5 w-5 text-green-500 shrink-0 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children:
                                      "Windows reinstall (Ghost Spectre)",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className:
                                      "h-5 w-5 text-green-500 shrink-0 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "Disable Windows Defender",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className:
                                      "h-5 w-5 text-green-500 shrink-0 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "BIOS flash",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className:
                                      "h-5 w-5 text-green-500 shrink-0 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "MAC and device spoofing",
                                  }),
                                ],
                              }),
                              (0, s.jsxs)("li", {
                                className: "flex items-start gap-2",
                                children: [
                                  (0, s.jsx)(i.CheckCircle2, {
                                    className:
                                      "h-5 w-5 text-green-500 shrink-0 mt-0.5",
                                  }),
                                  (0, s.jsx)("span", {
                                    children: "VAC 9005 bypass",
                                  }),
                                ],
                              }),
                            ],
                          }),
                          (0, s.jsxs)(h.Button, {
                            onClick: () => N("tpmOff"),
                            className:
                              "w-full bg-orange-500 hover:bg-orange-600",
                            children: [
                              "Start TPM OFF Guide",
                              (0, s.jsx)(c.ChevronRight, {
                                className: "ml-2 h-5 w-5",
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                }),
              ],
            }),
          "tpmOn" === e &&
            (0, s.jsxs)(s.Fragment, {
              children: [
                (0, s.jsx)("section", {
                  className:
                    "relative py-20 px-4 bg-gradient-to-b from-red-500/20 to-background",
                  children: (0, s.jsxs)("div", {
                    className: "container mx-auto max-w-4xl text-center",
                    children: [
                      (0, s.jsx)("h1", {
                        className: "text-5xl font-bold mb-6 text-balance",
                        children: "TPM ON Spoof Guide",
                      }),
                      (0, s.jsx)("p", {
                        className: "text-xl text-muted-foreground text-pretty",
                        children: "TPM ON - SecureBoot ON - Core Isolation ON",
                      }),
                    ],
                  }),
                }),
                (0, s.jsx)("section", {
                  className:
                    "py-8 px-4 bg-card/50 border-y border-border sticky top-16 z-40 backdrop-blur",
                  children: (0, s.jsxs)("div", {
                    className: "container mx-auto max-w-4xl",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-center justify-between mb-4",
                        children: [
                          (0, s.jsxs)("p", {
                            className: "text-sm text-muted-foreground",
                            children: ["Step ", j, " of ", u],
                          }),
                          (0, s.jsxs)("p", {
                            className: "text-sm text-muted-foreground",
                            children: [Math.round((j / u) * 100), "% Complete"],
                          }),
                        ],
                      }),
                      (0, s.jsx)("div", {
                        className:
                          "w-full bg-muted rounded-full h-3 overflow-hidden",
                        children: (0, s.jsx)("div", {
                          className:
                            "h-full bg-red-500 transition-all duration-300",
                          style: { width: `${(j / u) * 100}%` },
                        }),
                      }),
                    ],
                  }),
                }),
                (0, s.jsx)("section", {
                  className: "py-12 px-4 min-h-[60vh]",
                  children: (0, s.jsxs)("div", {
                    className: "container mx-auto max-w-4xl",
                    children: [
                      0 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: (0, s.jsx)(x.Package, {
                                    className: "h-8 w-8",
                                  }),
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Download Required Tools",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children: "Get all tools before starting",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-red-500/10 border-2 border-red-500/30 rounded-lg p-8 space-y-6 text-center",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "text-2xl font-bold text-red-600",
                                  children: "Spoofing Tools Pack",
                                }),
                                (0, s.jsx)("p", {
                                  className: "text-muted-foreground text-lg",
                                  children:
                                    "Contains Ghost Spectre, Ghosty-Spoofer, and all tools",
                                }),
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full sm:w-auto bg-red-500 hover:bg-red-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://gofile.io/d/KCaxBx",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Tools Pack",
                                    ],
                                  }),
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-red-500/10 border-2 border-red-500/30 rounded-lg p-8 space-y-6 text-center",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "text-2xl font-bold text-red-600",
                                  children: "Ghost Spectre 22H2 ISO",
                                }),
                                (0, s.jsx)("p", {
                                  className: "text-muted-foreground text-lg",
                                  children: "Windows reinstall image",
                                }),
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full sm:w-auto bg-red-500 hover:bg-red-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://pixeldrain.com/u/Dkzi9jZL",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Ghost Spectre",
                                    ],
                                  }),
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-red-500/10 border-2 border-red-500/30 rounded-lg p-8 space-y-6 text-center",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "text-2xl font-bold text-red-600",
                                  children: "Valorant Loader",
                                }),
                                (0, s.jsx)("p", {
                                  className: "text-muted-foreground text-lg",
                                  children: "Required for spoofing",
                                }),
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full sm:w-auto bg-red-500 hover:bg-red-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://workupload.com/file/gYmSJzyqxbE",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Loader",
                                    ],
                                  }),
                                }),
                                (0, s.jsx)("p", {
                                  className:
                                    "text-sm text-muted-foreground font-semibold",
                                  children: "Password: 123",
                                }),
                              ],
                            }),
                          ],
                        }),
                      1 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: "1",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children:
                                        "Reinstall Windows (Ghost Spectre 22H2)",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children: "Clean Windows installation",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className:
                                "border-yellow-500/50 bg-yellow-500/10",
                              children: [
                                (0, s.jsx)(n.AlertTriangle, {
                                  className: "h-5 w-5 text-yellow-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className: "text-base font-semibold",
                                  children:
                                    "WARNING: This will ERASE ALL DATA! Backup important files first!",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "font-semibold text-lg",
                                  children: "How to Reinstall Windows:",
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Extract Ghost Spectre 22H2 ISO from tools pack",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Create bootable USB with Rufus (download from rufus.ie)",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Boot from USB and perform clean Windows installation",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Install all chipset drivers from motherboard manufacturer",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "5",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Install GPU drivers (NVIDIA, AMD, or Intel)",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      2 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: "2",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Disable Windows Defender",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Prevent interference with spoofing tools",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className:
                                "border-yellow-500/50 bg-yellow-500/10",
                              children: [
                                (0, s.jsx)(n.AlertTriangle, {
                                  className: "h-5 w-5 text-yellow-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className: "text-base font-semibold",
                                  children:
                                    "Disable antivirus BEFORE running spoofer!",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full bg-red-500 hover:bg-red-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://github.com/ionuttbara/Defender-Control/releases",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Defender Control",
                                    ],
                                  }),
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm mt-4",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Extract and run Defender Control as Administrator",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            'Click the "Disable" button',
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Restart your PC when prompted",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      3 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: "3",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Flash BIOS",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Update BIOS to change hardware identifiers",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className:
                                "border-yellow-500/50 bg-yellow-500/10",
                              children: [
                                (0, s.jsx)(n.AlertTriangle, {
                                  className: "h-5 w-5 text-yellow-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className: "text-base font-semibold",
                                  children:
                                    "CRITICAL: Do NOT power off during BIOS flash! Ensure stable power supply!",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "font-semibold text-lg",
                                  children: "BIOS Flashing Steps:",
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Restart and enter BIOS (usually Delete, F2, or F12 key)",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Download latest BIOS for your motherboard model from manufacturer website",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Follow your motherboard's BIOS flash procedure",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Wait for flash to complete and system to reboot automatically",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      4 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: "4",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Save Original Serials",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Document your current hardware identifiers",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className: "border-blue-500/50 bg-blue-500/10",
                              children: [
                                (0, s.jsx)(d.Info, {
                                  className: "h-5 w-5 text-blue-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className: "text-base",
                                  children:
                                    "Save these to compare after spoofing to verify it worked!",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "font-semibold text-lg mb-4",
                                  children: "Download Serial Checker:",
                                }),
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full bg-red-500 hover:bg-red-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://gofile.io/d/KCaxBx",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Serial Checker",
                                    ],
                                  }),
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm mt-6",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Run Serial Checker from the tools pack",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Screenshot or write down all serial numbers",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Note: HDD Serial, SSD Serial, MAC Address, Hardware IDs",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Save these in a safe place for comparison",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      5 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: "5",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Clear TPM",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children: "Reset TPM module for spoofing",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsx)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: (0, s.jsxs)("ol", {
                                className: "space-y-3 text-sm",
                                children: [
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "1",
                                      }),
                                      (0, s.jsxs)("span", {
                                        children: [
                                          "Press ",
                                          (0, s.jsx)("strong", {
                                            children: "Windows + R",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "2",
                                      }),
                                      (0, s.jsxs)("span", {
                                        children: [
                                          "Type ",
                                          (0, s.jsx)("strong", {
                                            children: "tpm.msc",
                                          }),
                                          " and press Enter",
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "3",
                                      }),
                                      (0, s.jsxs)("span", {
                                        children: [
                                          "Click ",
                                          (0, s.jsx)("strong", {
                                            children: "Clear TPM...",
                                          }),
                                          " button",
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "4",
                                      }),
                                      (0, s.jsxs)("span", {
                                        children: [
                                          "Press the ",
                                          (0, s.jsx)("strong", {
                                            children: "Restart",
                                          }),
                                          " button and wait for PC to restart",
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                          ],
                        }),
                      6 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: "5",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Use MAC Spoof",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children: "Change network MAC address",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsx)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: (0, s.jsxs)("ol", {
                                className: "space-y-3 text-sm",
                                children: [
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "1",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Open Ghosty-Spoofer as Administrator",
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "2",
                                      }),
                                      (0, s.jsxs)("span", {
                                        children: [
                                          "Click ",
                                          (0, s.jsx)("strong", {
                                            children: "MAC Spoof",
                                          }),
                                          " button",
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "3",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Wait for completion and beep sound",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                          ],
                        }),
                      7 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: "7",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Use Driverless TPM Spoof",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Spoof device driver without physical TPM changes",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsx)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: (0, s.jsxs)("ol", {
                                className: "space-y-3 text-sm",
                                children: [
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "1",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Open Ghosty-Spoofer as Administrator",
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "2",
                                      }),
                                      (0, s.jsxs)("span", {
                                        children: [
                                          "Click ",
                                          (0, s.jsx)("strong", {
                                            children: "Driverless TPM Spoof",
                                          }),
                                          " button",
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "3",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Wait for completion and beep sound",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                          ],
                        }),
                      8 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: "8",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Use PERM Spoof",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Permanent hardware identifier spoof",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Open Ghosty-Spoofer as Administrator",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsxs)("span", {
                                          children: [
                                            "Click ",
                                            (0, s.jsx)("strong", {
                                              children: "PERM Spoof",
                                            }),
                                            " button",
                                          ],
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Wait for process to complete",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Your PC will automatically restart",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                (0, s.jsxs)(m.Alert, {
                                  className:
                                    "border-yellow-500/50 bg-yellow-500/10 mt-6",
                                  children: [
                                    (0, s.jsx)(n.AlertTriangle, {
                                      className: "h-5 w-5 text-yellow-600",
                                    }),
                                    (0, s.jsx)(m.AlertDescription, {
                                      className: "text-base font-semibold",
                                      children:
                                        "After restart: SecureBoot ON - Core Isolation ON - TPM ON (normally from start)",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      9 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: "7",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Check New Serials",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Verify spoofing was successful",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className: "border-green-500/50 bg-green-500/10",
                              children: [
                                (0, s.jsx)(i.CheckCircle2, {
                                  className: "h-5 w-5 text-green-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className:
                                    "text-base font-semibold text-green-600",
                                  children:
                                    "Compare new serials with saved originals - they should ALL be DIFFERENT!",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "font-semibold text-lg mb-4",
                                  children: "Download Serial Checker:",
                                }),
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full bg-red-500 hover:bg-red-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://gofile.io/d/KCaxBx",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Serial Checker",
                                    ],
                                  }),
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm mt-6",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children: "Run Serial Checker again",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Compare with your saved original serials",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "All values should be completely different",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "If any match = spoof failed, contact support",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      9 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-red-500 text-white font-bold text-2xl",
                                  children: "10",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Install & Test Valorant",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children: "Create new account and test",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className: "border-green-500/50 bg-green-500/10",
                              children: [
                                (0, s.jsx)(i.CheckCircle2, {
                                  className: "h-5 w-5 text-green-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className:
                                    "text-base font-semibold text-green-600",
                                  children:
                                    "You're ready! Create new account and install Valorant!",
                                }),
                              ],
                            }),
                            (0, s.jsx)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: (0, s.jsxs)("ol", {
                                className: "space-y-3 text-sm",
                                children: [
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "1",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Create a new Riot Games account (use new email)",
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "2",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Install Valorant from scratch",
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500 text-white text-sm font-semibold",
                                        children: "3",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Launch and enjoy! You should be good to go!",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                          ],
                        }),
                    ],
                  }),
                }),
                (0, s.jsx)("section", {
                  className:
                    "py-8 px-4 bg-card/50 border-t border-border sticky bottom-0",
                  children: (0, s.jsxs)("div", {
                    className:
                      "container mx-auto max-w-4xl flex gap-4 justify-between",
                    children: [
                      (0, s.jsxs)(h.Button, {
                        onClick: b,
                        disabled: 0 === j,
                        variant: "outline",
                        className: "gap-2",
                        children: [
                          (0, s.jsx)(o.ChevronLeft, { className: "h-5 w-5" }),
                          "Previous",
                        ],
                      }),
                      (0, s.jsxs)(h.Button, {
                        onClick: () => N("selection"),
                        variant: "outline",
                        className: "gap-2",
                        children: [
                          (0, s.jsx)(r.ArrowLeft, { className: "h-5 w-5" }),
                          "Back to Selection",
                        ],
                      }),
                      (0, s.jsxs)(h.Button, {
                        onClick: g,
                        disabled: j >= u - 1,
                        className: "gap-2 bg-red-500 hover:bg-red-600",
                        children: [
                          "Next",
                          (0, s.jsx)(c.ChevronRight, { className: "h-5 w-5" }),
                        ],
                      }),
                    ],
                  }),
                }),
              ],
            }),
          "tpmOff" === e &&
            (0, s.jsxs)(s.Fragment, {
              children: [
                (0, s.jsx)("section", {
                  className:
                    "relative py-20 px-4 bg-gradient-to-b from-orange-500/20 to-background",
                  children: (0, s.jsxs)("div", {
                    className: "container mx-auto max-w-4xl text-center",
                    children: [
                      (0, s.jsx)("h1", {
                        className: "text-5xl font-bold mb-6 text-balance",
                        children: "TPM OFF Spoof Guide",
                      }),
                      (0, s.jsx)("p", {
                        className: "text-xl text-muted-foreground text-pretty",
                        children: "TPM OFF - SecureBoot ON - Core Isolation ON",
                      }),
                    ],
                  }),
                }),
                (0, s.jsx)("section", {
                  className:
                    "py-8 px-4 bg-card/50 border-y border-border sticky top-16 z-40 backdrop-blur",
                  children: (0, s.jsxs)("div", {
                    className: "container mx-auto max-w-4xl",
                    children: [
                      (0, s.jsxs)("div", {
                        className: "flex items-center justify-between mb-4",
                        children: [
                          (0, s.jsxs)("p", {
                            className: "text-sm text-muted-foreground",
                            children: ["Step ", j, " of ", u],
                          }),
                          (0, s.jsxs)("p", {
                            className: "text-sm text-muted-foreground",
                            children: [Math.round((j / u) * 100), "% Complete"],
                          }),
                        ],
                      }),
                      (0, s.jsx)("div", {
                        className:
                          "w-full bg-muted rounded-full h-3 overflow-hidden",
                        children: (0, s.jsx)("div", {
                          className:
                            "h-full bg-orange-500 transition-all duration-300",
                          style: { width: `${(j / u) * 100}%` },
                        }),
                      }),
                    ],
                  }),
                }),
                (0, s.jsx)("section", {
                  className: "py-12 px-4 min-h-[60vh]",
                  children: (0, s.jsxs)("div", {
                    className: "container mx-auto max-w-4xl",
                    children: [
                      0 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                                  children: (0, s.jsx)(x.Package, {
                                    className: "h-8 w-8",
                                  }),
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Download Required Tools",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children: "Get all tools before starting",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-orange-500/10 border-2 border-orange-500/30 rounded-lg p-8 space-y-6 text-center",
                              children: [
                                (0, s.jsx)("h3", {
                                  className:
                                    "text-2xl font-bold text-orange-600",
                                  children: "Spoofing Tools Pack",
                                }),
                                (0, s.jsx)("p", {
                                  className: "text-muted-foreground text-lg",
                                  children:
                                    "Contains Ghost Spectre, Ghosty-Spoofer, and all tools",
                                }),
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full sm:w-auto bg-orange-500 hover:bg-orange-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://gofile.io/d/KCaxBx",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Tools Pack",
                                    ],
                                  }),
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-orange-500/10 border-2 border-orange-500/30 rounded-lg p-8 space-y-6 text-center",
                              children: [
                                (0, s.jsx)("h3", {
                                  className:
                                    "text-2xl font-bold text-orange-600",
                                  children: "Ghost Spectre 22H2 ISO",
                                }),
                                (0, s.jsx)("p", {
                                  className: "text-muted-foreground text-lg",
                                  children: "Windows reinstall image",
                                }),
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full sm:w-auto bg-orange-500 hover:bg-orange-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://pixeldrain.com/u/Dkzi9jZL",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Ghost Spectre",
                                    ],
                                  }),
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-orange-500/10 border-2 border-orange-500/30 rounded-lg p-8 space-y-6 text-center",
                              children: [
                                (0, s.jsx)("h3", {
                                  className:
                                    "text-2xl font-bold text-orange-600",
                                  children: "Valorant Loader",
                                }),
                                (0, s.jsx)("p", {
                                  className: "text-muted-foreground text-lg",
                                  children: "Required for spoofing",
                                }),
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full sm:w-auto bg-orange-500 hover:bg-orange-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://workupload.com/file/gYmSJzyqxbE",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Loader",
                                    ],
                                  }),
                                }),
                                (0, s.jsx)("p", {
                                  className:
                                    "text-sm text-muted-foreground font-semibold",
                                  children: "Password: 123",
                                }),
                              ],
                            }),
                          ],
                        }),
                      1 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                                  children: "1",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children:
                                        "Reinstall Windows (Ghost Spectre 22H2)",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children: "Clean Windows installation",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className:
                                "border-yellow-500/50 bg-yellow-500/10",
                              children: [
                                (0, s.jsx)(n.AlertTriangle, {
                                  className: "h-5 w-5 text-yellow-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className: "text-base font-semibold",
                                  children:
                                    "WARNING: This will ERASE ALL DATA! Backup important files first!",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "font-semibold text-lg",
                                  children: "How to Reinstall Windows:",
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Extract Ghost Spectre 22H2 ISO from tools pack",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Create bootable USB with Rufus (download from rufus.ie)",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Boot from USB and perform clean Windows installation",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Install all chipset drivers from motherboard manufacturer",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "5",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Install GPU drivers (NVIDIA, AMD, or Intel)",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      2 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                                  children: "2",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Disable Windows Defender",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Prevent interference with spoofing tools",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className:
                                "border-yellow-500/50 bg-yellow-500/10",
                              children: [
                                (0, s.jsx)(n.AlertTriangle, {
                                  className: "h-5 w-5 text-yellow-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className: "text-base font-semibold",
                                  children:
                                    "Disable antivirus BEFORE running spoofer!",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full bg-orange-500 hover:bg-orange-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://github.com/ionuttbara/Defender-Control/releases",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Defender Control",
                                    ],
                                  }),
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm mt-4",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Extract and run Defender Control as Administrator",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            'Click the "Disable" button',
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Restart your PC when prompted",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      3 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                                  children: "3",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Flash BIOS",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Update BIOS to change hardware identifiers",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className:
                                "border-yellow-500/50 bg-yellow-500/10",
                              children: [
                                (0, s.jsx)(n.AlertTriangle, {
                                  className: "h-5 w-5 text-yellow-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className: "text-base font-semibold",
                                  children:
                                    "CRITICAL: Do NOT power off during BIOS flash! Ensure stable power supply!",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "font-semibold text-lg",
                                  children: "BIOS Flashing Steps:",
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Restart and enter BIOS (usually Delete, F2, or F12 key)",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Download latest BIOS for your motherboard model from manufacturer website",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Follow your motherboard's BIOS flash procedure",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Wait for flash to complete and system to reboot automatically",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      4 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                                  children: "4",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Save Original Serials",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Document your current hardware identifiers",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className: "border-blue-500/50 bg-blue-500/10",
                              children: [
                                (0, s.jsx)(d.Info, {
                                  className: "h-5 w-5 text-blue-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className: "text-base",
                                  children:
                                    "Save these to compare after spoofing to verify it worked!",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "font-semibold text-lg mb-4",
                                  children: "Download Serial Checker:",
                                }),
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full bg-orange-500 hover:bg-orange-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://gofile.io/d/KCaxBx",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Serial Checker",
                                    ],
                                  }),
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm mt-6",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Run Serial Checker from the tools pack",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Screenshot or write down all serial numbers",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Note: HDD Serial, SSD Serial, MAC Address, Hardware IDs",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Save these in a safe place for comparison",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      5 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                                  children: "5",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Use MAC Spoof",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children: "Change network MAC address",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsx)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: (0, s.jsxs)("ol", {
                                className: "space-y-3 text-sm",
                                children: [
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                        children: "1",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Open Ghosty-Spoofer as Administrator",
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                        children: "2",
                                      }),
                                      (0, s.jsxs)("span", {
                                        children: [
                                          "Click ",
                                          (0, s.jsx)("strong", {
                                            children: "MAC Spoof",
                                          }),
                                          " button",
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                        children: "3",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Wait for completion and beep sound",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                          ],
                        }),
                      6 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                                  children: "6",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Use PERM Spoof",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Permanent hardware identifier spoof",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsx)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: (0, s.jsxs)("ol", {
                                className: "space-y-3 text-sm",
                                children: [
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                        children: "1",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Open Ghosty-Spoofer as Administrator",
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                        children: "2",
                                      }),
                                      (0, s.jsxs)("span", {
                                        children: [
                                          "Click ",
                                          (0, s.jsx)("strong", {
                                            children: "PERM Spoof",
                                          }),
                                          " button",
                                        ],
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                        children: "3",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Wait for process to complete",
                                      }),
                                    ],
                                  }),
                                  (0, s.jsxs)("li", {
                                    className: "flex items-start gap-3",
                                    children: [
                                      (0, s.jsx)("span", {
                                        className:
                                          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                        children: "4",
                                      }),
                                      (0, s.jsx)("span", {
                                        children:
                                          "Your PC will automatically restart",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                          ],
                        }),
                      7 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                                  children: "7",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Check New Serials",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Verify spoofing was successful",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className: "border-green-500/50 bg-green-500/10",
                              children: [
                                (0, s.jsx)(i.CheckCircle2, {
                                  className: "h-5 w-5 text-green-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className:
                                    "text-base font-semibold text-green-600",
                                  children:
                                    "Compare new serials with saved originals - they should ALL be DIFFERENT!",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "font-semibold text-lg mb-4",
                                  children: "Download Serial Checker:",
                                }),
                                (0, s.jsx)(h.Button, {
                                  size: "lg",
                                  className:
                                    "w-full bg-orange-500 hover:bg-orange-600 text-white",
                                  asChild: !0,
                                  children: (0, s.jsxs)("a", {
                                    href: "https://gofile.io/d/KCaxBx",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: [
                                      (0, s.jsx)(a.Download, {
                                        className: "mr-2 h-5 w-5",
                                      }),
                                      "Download Serial Checker",
                                    ],
                                  }),
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm mt-6",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children: "Run Serial Checker again",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Compare with your saved original serials",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "All values should be completely different",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "If any match = spoof failed, contact support",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      8 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                                  children: "8",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "BIOS Settings",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Configure security settings for TPM OFF",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsxs)("div", {
                                  className: "space-y-4",
                                  children: [
                                    (0, s.jsxs)("div", {
                                      className:
                                        "flex items-center justify-between p-4 bg-orange-500/10 rounded border border-orange-500/30",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className: "font-semibold",
                                          children: "TPM",
                                        }),
                                        (0, s.jsx)("span", {
                                          className:
                                            "text-orange-600 font-bold",
                                          children: "OFF",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("div", {
                                      className:
                                        "flex items-center justify-between p-4 bg-orange-500/10 rounded border border-orange-500/30",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className: "font-semibold",
                                          children: "Secure Boot",
                                        }),
                                        (0, s.jsx)("span", {
                                          className:
                                            "text-orange-600 font-bold",
                                          children: "ON",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("div", {
                                      className:
                                        "flex items-center justify-between p-4 bg-orange-500/10 rounded border border-orange-500/30",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className: "font-semibold",
                                          children: "Core Isolation",
                                        }),
                                        (0, s.jsx)("span", {
                                          className:
                                            "text-orange-600 font-bold",
                                          children: "ON",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm mt-6",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Restart and enter BIOS (usually Delete, F2, or F12 key)",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Find Security/Advanced settings section",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Set TPM to OFF (or Disable TPM)",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children: "Set Secure Boot to ON",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "5",
                                        }),
                                        (0, s.jsx)("span", {
                                          children: "Set Core Isolation to ON",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "6",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Save changes and exit BIOS",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                      9 === j &&
                        (0, s.jsxs)("div", {
                          className:
                            "space-y-6 animate-in fade-in duration-500",
                          children: [
                            (0, s.jsxs)("div", {
                              className: "flex items-start gap-4",
                              children: [
                                (0, s.jsx)("div", {
                                  className:
                                    "flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white font-bold text-2xl",
                                  children: "9",
                                }),
                                (0, s.jsxs)("div", {
                                  className: "space-y-2",
                                  children: [
                                    (0, s.jsx)("h2", {
                                      className: "text-3xl font-bold",
                                      children: "Install & Launch Valorant",
                                    }),
                                    (0, s.jsx)("p", {
                                      className:
                                        "text-lg text-muted-foreground",
                                      children:
                                        "Final step with TPM Bypass Setup",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            (0, s.jsxs)(m.Alert, {
                              className: "border-blue-500/50 bg-blue-500/10",
                              children: [
                                (0, s.jsx)(d.Info, {
                                  className: "h-5 w-5 text-blue-600",
                                }),
                                (0, s.jsx)(m.AlertDescription, {
                                  className: "text-base",
                                  children:
                                    "TPM Bypass Setup for TPM OFF - follow steps below if needed",
                                }),
                              ],
                            }),
                            (0, s.jsxs)("div", {
                              className:
                                "bg-card border border-border rounded-lg p-6 space-y-4",
                              children: [
                                (0, s.jsx)("h3", {
                                  className: "font-semibold text-lg",
                                  children: "Step by Step:",
                                }),
                                (0, s.jsxs)("ol", {
                                  className: "space-y-3 text-sm",
                                  children: [
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "1",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Create new Riot Games account (new email)",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "2",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Install Valorant from scratch",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "3",
                                        }),
                                        (0, s.jsx)("span", {
                                          children: "Open the game",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-3",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "4",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "If TPM Bypass is needed, follow these steps:",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-6 ml-4",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "a",
                                        }),
                                        (0, s.jsx)("span", {
                                          children: "Close the game",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-6 ml-4",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "b",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Run TPM Bypass Setup tool from tools pack as Administrator",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-6 ml-4",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "c",
                                        }),
                                        (0, s.jsx)("span", {
                                          children: "Wait for it to complete",
                                        }),
                                      ],
                                    }),
                                    (0, s.jsxs)("li", {
                                      className: "flex items-start gap-6 ml-4",
                                      children: [
                                        (0, s.jsx)("span", {
                                          className:
                                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-500 text-white text-sm font-semibold",
                                          children: "d",
                                        }),
                                        (0, s.jsx)("span", {
                                          children:
                                            "Relaunch Valorant - you're good to go!",
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                    ],
                  }),
                }),
                "selection" !== e &&
                  (0, s.jsx)("section", {
                    className:
                      "py-8 px-4 bg-card/50 border-t border-border sticky bottom-0",
                    children: (0, s.jsxs)("div", {
                      className:
                        "container mx-auto max-w-4xl flex gap-4 justify-between",
                      children: [
                        (0, s.jsxs)(h.Button, {
                          onClick: b,
                          disabled: 0 === j,
                          variant: "outline",
                          className: "gap-2",
                          children: [
                            (0, s.jsx)(o.ChevronLeft, { className: "h-5 w-5" }),
                            "Previous",
                          ],
                        }),
                        (0, s.jsxs)(h.Button, {
                          onClick: g,
                          disabled: j >= u,
                          className: "gap-2 bg-orange-500 hover:bg-orange-600",
                          children: [
                            "Next",
                            (0, s.jsx)(c.ChevronRight, {
                              className: "h-5 w-5",
                            }),
                          ],
                        }),
                      ],
                    }),
                  }),
              ],
            }),
        ],
      });
    }
    e.s(["default", () => f]);
  },
]);
